# iri_ros_how_to

## Description

* IRI ROS layer description (iri_core) TO_DO

## Installation

### From debs

* TO_DO

### From source

* You need an active ROS workspace. See [ROS create_a_workspace](http://wiki.ros.org/catkin/Tutorials/create_a_workspace) tutorial.

* Option 1. Individual repository
    * Find the IRI ROS repositories in: https://gitlab.iri.upc.edu/labrobotica/ros
    * Clone the repository in your ROS workspace, for example:
        ```
        roscd; cd ../src;
        git clone https://gitlab.iri.upc.edu/labrobotica/ros/iri_core/iri_base_algorithm.git
        ```
* Option 2. Using a rosinstall file
    * See an example rosinstall file here: [iri_core.rosinstall](rosinstall/iri_core.rosinstall)
    * Use [wstool](http://wiki.ros.org/wstool) to load it into your workspace

* Install workspace dependencies using [rosdep](http://wiki.ros.org/rosdep)

    ```
    roscd; cd ..
    rosdep install -i -r --from-paths src
    ```

* Compile your workspace:

    ```bash
    roscd; cd ..;
    catkin_make
    ```

## Tutorials

* [Official ROS Wiki](http://wiki.ros.org/)
   *  [ROS tutorials](http://wiki.ros.org/ROS/Tutorials)
* IRI ROS Scripts: easy creation of IRI ROS packages and addition of topics, services and actions to them.
   * [iri_ros_scripts](https://gitlab.iri.upc.edu/labrobotica/ros/iri_core/iri_ros_scripts)
* IRI ROS Beginner tutorials: IRI version of ROS beginner tutorials (topics, services and actions) using IRI ROS Scripts.
   * [IRI ROS topic](https://wiki.iri.upc.edu/index.php/ROS_topic_tutorial): TO_DO: move to this repository from wiki
   * [IRI ROS service](https://wiki.iri.upc.edu/index.php/ROS_service_tutorial): TO_DO: move to this repository from wiki
   * [IRI ROS action](https://wiki.iri.upc.edu/index.php/ROS_action_tutorial): TO_DO: move to this repository from wiki
* [Helloworld](doc/helloworld.md): TO_DO
