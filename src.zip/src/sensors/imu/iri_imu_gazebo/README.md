# Description

This ROS package encapsulates the IMU sensor from the [Hector gazebo plugins package](http://wiki.ros.org/hector_gazebo_plugins) in a xacro macro to simplify its integration. 

# Dependencies

This node has the following ROS dependencies:

  * [Hector gazebo plugins package](http://wiki.ros.org/hector_gazebo_plugins)

This dependencies can be installed with the following command:

```
sudo apt-get install ros-kinetic-hector-gazebo-plugins
```

This node has the following ROS IRI dependencies:

  * [IRI Microstrain IMU description](https://gitlab.iri.upc.edu/labrobotica/ros/sensors/imu/iri_microstrain_imu_description).


# Install

This package can be cloned to an active workspace with the following command:

```
roscd
cd ../src
git clone https://gitlab.iri.upc.edu/labrobotica/ros/sensors/imu/iri_imu_gazebo.git 
```

# How to use it

This IMU gazebo model is automatically included when an IMU sensor in included in a xacro or urdf file. This plugin can be fully configured by a YAML file which is provided as a parameter to the xacro macro.

A separate YAML file is provided for each IMU sensor. At the moment the supported sensors are:

 * Microstrain 3dm-gx3-25 

