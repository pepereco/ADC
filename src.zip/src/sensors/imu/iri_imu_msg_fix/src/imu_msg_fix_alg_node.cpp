#include "imu_msg_fix_alg_node.h"

ImuMsgFixAlgNode::ImuMsgFixAlgNode(void) :
  algorithm_base::IriBaseAlgorithm<ImuMsgFixAlgorithm>()
{
  //init class attributes if necessary
  //this->loop_rate_ = 2;//in [Hz]

  // [init publishers]
  this->imu_out_publisher_ = this->public_node_handle_.advertise<sensor_msgs::Imu>("imu_out", 1);
  
  // [init subscribers]
  this->imu_in_subscriber_ = this->public_node_handle_.subscribe("imu_in", 1, &ImuMsgFixAlgNode::imu_in_callback, this);
  pthread_mutex_init(&this->imu_in_mutex_,NULL);
  
  // [init services]
  
  // [init clients]
  
  // [init action servers]
  
  // [init action clients]
}

ImuMsgFixAlgNode::~ImuMsgFixAlgNode(void)
{
  // [free dynamic memory]
  pthread_mutex_destroy(&this->imu_in_mutex_);
}

void ImuMsgFixAlgNode::mainNodeThread(void)
{
  // [fill msg structures]
  // Initialize the topic message structure
  //this->pose_PoseStamped_msg_.data = my_var;

  // Initialize the topic message structure
  //this->imu_out_Imu_msg_.data = my_var;

  
  // [fill srv structure and make request to the server]
  
  // [fill action structure and make request to the action server]

  // [publish messages]
  // Uncomment the following line to publish the topic message
  //this->pose_publisher_.publish(this->pose_PoseStamped_msg_);

  // Uncomment the following line to publish the topic message
  //this->imu_out_publisher_.publish(this->imu_out_Imu_msg_);

}

/*  [subscriber callbacks] */
void ImuMsgFixAlgNode::imu_in_callback(const sensor_msgs::Imu::ConstPtr& msg)
{
  //ROS_INFO("ImuMsgFixAlgNode::imu_in_callback: New Message Received");

  //use appropiate mutex to shared variables if necessary
  //this->alg_.lock();
  //this->imu_in_mutex_enter();
  std::string frame;
  if(this->config_.fix_frame_id)
    frame=this->config_.frame_id;
  else
  {
    frame = msg->header.frame_id;
    if(frame[0]=='/')
      frame.erase (0,1);
  }
  
  if(this->config_.imu_reference==1)
  {
    if(this->config_.fix_cov)
    {
      this->imu_out_Imu_msg_.orientation_covariance[0]=this->config_.cov_orientation;
      this->imu_out_Imu_msg_.orientation_covariance[4]=this->config_.cov_orientation;
      this->imu_out_Imu_msg_.orientation_covariance[8]=this->config_.cov_orientation;
    
      this->imu_out_Imu_msg_.angular_velocity_covariance[0]=this->config_.cov_vel;
      this->imu_out_Imu_msg_.angular_velocity_covariance[4]=this->config_.cov_vel;
      this->imu_out_Imu_msg_.angular_velocity_covariance[8]=this->config_.cov_vel;
    
      this->imu_out_Imu_msg_.linear_acceleration_covariance[0]=this->config_.cov_acc;
      this->imu_out_Imu_msg_.linear_acceleration_covariance[4]=this->config_.cov_acc;
      this->imu_out_Imu_msg_.linear_acceleration_covariance[8]=this->config_.cov_acc;
    }
    else 
    {
      this->imu_out_Imu_msg_.orientation_covariance[0]=msg->orientation_covariance[4];
      this->imu_out_Imu_msg_.orientation_covariance[1]=msg->orientation_covariance[3];
      this->imu_out_Imu_msg_.orientation_covariance[4]=msg->orientation_covariance[0];
      this->imu_out_Imu_msg_.orientation_covariance[3]=msg->orientation_covariance[1];
      this->imu_out_Imu_msg_.orientation_covariance[8]=msg->orientation_covariance[8];
    
      this->imu_out_Imu_msg_.angular_velocity_covariance[0]=msg->angular_velocity_covariance[4];
      this->imu_out_Imu_msg_.angular_velocity_covariance[1]=msg->angular_velocity_covariance[3];
      this->imu_out_Imu_msg_.angular_velocity_covariance[4]=msg->angular_velocity_covariance[0];
      this->imu_out_Imu_msg_.angular_velocity_covariance[3]=msg->angular_velocity_covariance[1];
      this->imu_out_Imu_msg_.angular_velocity_covariance[8]=msg->angular_velocity_covariance[8];
    
      this->imu_out_Imu_msg_.linear_acceleration_covariance[0]=msg->linear_acceleration_covariance[4];
      this->imu_out_Imu_msg_.linear_acceleration_covariance[1]=msg->linear_acceleration_covariance[3];
      this->imu_out_Imu_msg_.linear_acceleration_covariance[4]=msg->linear_acceleration_covariance[0];
      this->imu_out_Imu_msg_.linear_acceleration_covariance[3]=msg->linear_acceleration_covariance[1];
      this->imu_out_Imu_msg_.linear_acceleration_covariance[8]=msg->linear_acceleration_covariance[8];
    }
    this->imu_out_Imu_msg_.orientation.x=msg->orientation.y;
    this->imu_out_Imu_msg_.orientation.y=msg->orientation.x;
    this->imu_out_Imu_msg_.orientation.z=-msg->orientation.z;
    this->imu_out_Imu_msg_.orientation.w=-msg->orientation.w;

    this->imu_out_Imu_msg_.angular_velocity.x=msg->angular_velocity.y;
    this->imu_out_Imu_msg_.angular_velocity.y=msg->angular_velocity.x;
    this->imu_out_Imu_msg_.angular_velocity.z=-msg->angular_velocity.z;

    this->imu_out_Imu_msg_.linear_acceleration.x=msg->linear_acceleration.y;
    this->imu_out_Imu_msg_.linear_acceleration.y=msg->linear_acceleration.x;
    this->imu_out_Imu_msg_.linear_acceleration.z=-msg->linear_acceleration.z;
  }
  else
  {
    if(this->config_.fix_cov)
    {
      this->imu_out_Imu_msg_.orientation_covariance[0]=this->config_.cov_orientation;
      this->imu_out_Imu_msg_.orientation_covariance[4]=this->config_.cov_orientation;
      this->imu_out_Imu_msg_.orientation_covariance[8]=this->config_.cov_orientation;
    
      this->imu_out_Imu_msg_.angular_velocity_covariance[0]=this->config_.cov_vel;
      this->imu_out_Imu_msg_.angular_velocity_covariance[4]=this->config_.cov_vel;
      this->imu_out_Imu_msg_.angular_velocity_covariance[8]=this->config_.cov_vel;
    
      this->imu_out_Imu_msg_.linear_acceleration_covariance[0]=this->config_.cov_acc;
      this->imu_out_Imu_msg_.linear_acceleration_covariance[4]=this->config_.cov_acc;
      this->imu_out_Imu_msg_.linear_acceleration_covariance[8]=this->config_.cov_acc;
    }
    else 
    {
      this->imu_out_Imu_msg_.orientation_covariance=msg->orientation_covariance;
      this->imu_out_Imu_msg_.angular_velocity_covariance=msg->angular_velocity_covariance;
      this->imu_out_Imu_msg_.linear_acceleration_covariance=msg->linear_acceleration_covariance;
    }
    this->imu_out_Imu_msg_.orientation=msg->orientation;
    this->imu_out_Imu_msg_.angular_velocity=msg->angular_velocity;
    this->imu_out_Imu_msg_.linear_acceleration=msg->linear_acceleration;
  }

  this->imu_out_Imu_msg_.header.frame_id = frame;
  this->imu_out_Imu_msg_.header.stamp = msg->header.stamp;
  this->imu_out_publisher_.publish(this->imu_out_Imu_msg_);
  
//   this->pose_PoseStamped_msg_.header = msg->header;
//   this->pose_PoseStamped_msg_.header.frame_id = "car/odom";
//   this->pose_PoseStamped_msg_.pose.orientation = msg->orientation;
//   this->pose_publisher_.publish(this->pose_PoseStamped_msg_);

  //std::cout << msg->data << std::endl;
  //unlock previously blocked shared variables
  //this->alg_.unlock();
  //this->imu_in_mutex_exit();
}

void ImuMsgFixAlgNode::imu_in_mutex_enter(void)
{
  pthread_mutex_lock(&this->imu_in_mutex_);
}

void ImuMsgFixAlgNode::imu_in_mutex_exit(void)
{
  pthread_mutex_unlock(&this->imu_in_mutex_);
}


/*  [service callbacks] */

/*  [action callbacks] */

/*  [action requests] */

void ImuMsgFixAlgNode::node_config_update(Config &config, uint32_t level)
{
  this->alg_.lock();
  this->config_=config;
  this->alg_.unlock();
}

void ImuMsgFixAlgNode::addNodeDiagnostics(void)
{
}

/* main function */
int main(int argc,char *argv[])
{
  return algorithm_base::main<ImuMsgFixAlgNode>(argc, argv, "imu_msg_fix_alg_node");
}
