# Description

This ROS package encapsulates the camera sensor from the [ROS standard plugins](http://wiki.ros.org/gazebo_plugins) in a xacro macro to simplify its integration. Two versions are available, with and without wideangle lenses.

# Dependencies

This node has the following ROS dependencies:

  * [ROS standard plugins](http://wiki.ros.org/gazebo_plugins)

This dependencies can be installed with the following command:

```
sudo apt-get install ros-kinetic-gazebo-plugins
```

This node has the following ROS IRI dependencies:

  * [IRI UVC camera description](https://gitlab.iri.upc.edu/labrobotica/ros/sensors/usb_cameras/iri_uvc_camera_description).


# Install

This package can be cloned to an active workspace with the following command:

```
roscd
cd ../src
git clone https://gitlab.iri.upc.edu/labrobotica/ros/sensors/mono_cameras/iri_camera_gazebo.git
```

# How to use it

This camera gazebo model is automatically included when a camera sensor in included in a xacro or urdf file. This plugin can be fully configured by a YAML file which is provided as a parameter to the xacro macro.

A separate YAML file is provided for each IMU sensor. 

