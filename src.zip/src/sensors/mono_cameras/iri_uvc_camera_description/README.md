# Description

This ROS package contains physical descriptions of UVC compatible cameras. 

For each sensor, the following files are provided:

 * Two mesh files: one with high resolution for visual purposes only and one with low resolution for collision detection and for systems with low graphics.

 * Xacro macro to be included in higher level urdf or xacro files.

 * An example xacro file to be used as an example of use of the macro.

# Dependencies

This node has the following dependencies:

  * [iri_camera_gazebo](https://gitlab.iri.upc.edu/labrobotica/ros/sensors/imu/iri_camera_gazebo) (for simulation only)

# Install

This package can be cloned to an active workspace with the following command:

```
roscd
cd ../src
git clone https://gitlab.iri.upc.edu/labrobotica/ros/sensors/usb_cameras/iri_uvc_camera_description.git 
```

# How to use it

The *uvc_camera_example.xacro* file shows an example of how to include the xacro macro in another xacro file.

The xacro macro has the following parameters:

 * **name:** name of the sensor used to specify the frames and joints to allow multiples instances.

 * **parent:** name of the parent frame of the IMU sensor. 

 * **resolution:** Specify the type of mesh to use for visualization. It can be either *high_res* or *low_res*.

 * **model:** Specify the model of the camera used if a specific mesh exists for it. Otherwise use the value *default*.

 * **origin:** pose of the sensor with respect of the parent frame.

 * **sim_config:** path and filename of the configuration file for the gazebo plugin.


