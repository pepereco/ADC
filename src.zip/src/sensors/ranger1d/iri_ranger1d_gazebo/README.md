# Description

This ROS package encapsulates the standard Ranger 1D sensor from ROS in a xacro macro to simplify its integration. 

# Dependencies

This node has the following ROS IRI dependencies:

  * [IRI Lidar Lite description](https://gitlab.iri.upc.edu/labrobotica/ros/sensors/ranger1d/iri_lidar_lite_description).


# Install

This package can be cloned to an active workspace with the following command:

```
roscd
cd ../src
git clone https://gitlab.iri.upc.edu/labrobotica/ros/sensors/ranger1d/iri_ranger1d_gazebo.git 
```

# How to use it

This Ranger 1D gazebo model is automatically included when an 1D ranger sensor in included in a xacro or urdf file. This plugin can be fully configured by a YAML file which is provided as a parameter to the xacro macro.

A separate YAML file is provided for each IMU sensor. At the moment the supported sensors are:

 * Lidar Lite

