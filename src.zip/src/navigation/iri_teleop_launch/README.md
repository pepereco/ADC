# Description

Launch and configuration files for several teleoperation packages

# Dependencies


# Install

This package, as well as all IRI dependencies, can be installed by cloning the
repository inside the active workspace:

```
roscd
cd ../src
git clone https://gitlab.iri.upc.edu/labrobotica/ros/navigation/iri_teleop_launch
```

However, this package is normally used as part of a wider installation (i.e. a
robot, an experiment or a demosntration) which will normally include a complete
rosinstall file to be used with the [wstool](http://wiki.ros.org/wstool) tool.

# How to use it

 * joystick_teleop.launch: example using a joystick
 * keyboard_teleop.launch: example using the keyboard
 * rqt_teleop.launch: example using a the rqt robot steering gui
 
 See its arguments for more detail on configuration possibilities.