# PS3joy bluetooth pairing

Information extracted from this [askubuntu.com/question](https://askubuntu.com/questions/913599/how-to-connect-dualshock-3-controller-ps3-sixaxis-gamepad-on-ubuntu-16-04)

Follow these instructions to be able to pair your PS3 joystick pad to your computer using bluetooth.

You will need:
* A computer with
    * Internet connection
    * Free usb port
    * Bluetooth
* A PS3 joypad controller
* A USB cable (A-mini)

## Procedure

* Install dependencies,

    `sudo apt-get install dialog build-essential pyqt4-dev-tools libusb-dev libbluetooth-dev python-dbus -y`

* Download sixpair, as it's not available as deb package in Ubuntu 16.04.

    `wget https://github.com/RetroPie/sixad/archive/master.zip -O sixad-master.zip`

* Unzip, compile and install it,

    `unzip sixad-master.zip`

    `cd sixad-master`

    `make`

    `sudo make install`

* Plug your PS3 joy pad controller to your computer with the USB cable, and run:

    `sudo sixpair`

* You should see the bluetooth MAC address being assigned to the PS3 joy pad.

    ```
    Current Bluetooth master: XX:XX:XX:XX:XX:XX
    Setting master bd_addr to XX:XX:XX:XX:XX:XX
    ```

* Unplug the PS3 joypad from the USB

* Run sixad, manually once: (you can turn it off with CTRL+C)

    `sudo sixad -s`
    * If you want to stop it, do CTRL+C
    * You can make it autostart on boot:

        `sudo sixad --boot-yes`

* Press your PS3 joypad PS button, after 2-3 seconds you'll feel the controller vibrate when it successfully connects.

* It should appear as a device like /dev/input/js#

* You can test it with:

    `jstest /dev/input/js0`