/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2008, 2013, Willow Garage, Inc.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Author: Eitan Marder-Eppstein
 *         David V. Lu!!
 *********************************************************************/
#include <iri_opendrive_global_planner/opendrive_planner.h>
#include <pluginlib/class_list_macros.h>
#include <costmap_2d/cost_values.h>
#include <costmap_2d/costmap_2d.h>
#include <tf2/utils.h>
#include <limits>

#include "exceptions.h"

//register this planner as a BaseOpendriveGlobalPlanner plugin
PLUGINLIB_EXPORT_CLASS(iri_opendrive_global_planner::OpendriveGlobalPlanner, nav_core::BaseGlobalPlanner)

namespace iri_opendrive_global_planner {

OpendriveGlobalPlanner::OpendriveGlobalPlanner() :
  costmap_(NULL), initialized_(false), tf2_listener(tf2_buffer) {
  this->angle_tol=DEFAULT_ANGLE_THRESHOLD;
  this->dist_tol=DEFAULT_DIST_THRESHOLD;
  this->multi_hyp=false;
}

OpendriveGlobalPlanner::OpendriveGlobalPlanner(std::string name, costmap_2d::Costmap2D* costmap, std::string frame_id) :
  OpendriveGlobalPlanner() 
{
  //initialize the planner
  initialize(name, costmap, frame_id);
}

OpendriveGlobalPlanner::~OpendriveGlobalPlanner() 
{
  if (dsrv_)
    delete dsrv_;
}

void OpendriveGlobalPlanner::initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros) 
{
  initialize(name, costmap_ros->getCostmap(), costmap_ros->getGlobalFrameID());
}

void OpendriveGlobalPlanner::initialize(std::string name, costmap_2d::Costmap2D* costmap, std::string frame_id) 
{
  if (!initialized_) 
  {
    ros::NodeHandle private_nh("~/" + name);
    costmap_ = costmap;
    frame_id_ = frame_id;

    try{
      std::string opendrive_file;
      double resolution,scale_factor,min_road_length;
      int cost_type;

      private_nh.param("resolution", resolution,0.0);
      this->roadmap.set_resolution(resolution);
      private_nh.param("scale_factor", scale_factor,0.0);
      this->roadmap.set_scale_factor(scale_factor);
      private_nh.param("min_road_length", min_road_length,0.0);
      this->roadmap.set_min_road_length(min_road_length);
      private_nh.param("opendrive_file", opendrive_file,std::string(""));
      if(opendrive_file!="")
      {
        this->roadmap.load(opendrive_file);
        this->create_opendrive_map(opendrive_file,resolution,scale_factor,min_road_length);
      }
      private_nh.param("opendrive_frame", this->opendrive_frame_id_,std::string(""));
      private_nh.param("angle_tol", this->angle_tol,DEFAULT_ANGLE_THRESHOLD);
      private_nh.param("dist_tol", this->dist_tol,DEFAULT_DIST_THRESHOLD);
      private_nh.param("multi_hyp", this->multi_hyp,false);
      private_nh.param("cost_type",cost_type,(int)COST_DIST);
      this->roadmap.set_cost_type((cost_t)cost_type);
    }catch(CException &e){
      ROS_ERROR_STREAM(e.what());
    }

    plan_pub_ = private_nh.advertise<nav_msgs::Path>("plan", 1);
    make_plan_srv_ = private_nh.advertiseService("make_plan", &OpendriveGlobalPlanner::makePlanService, this);

    this->opendrive_map_pub_ = private_nh.advertise<nav_msgs::OccupancyGrid>("opendrive_map", 1,boost::bind(&OpendriveGlobalPlanner::map_connect_callback, this, _1));

    this->opendrive_map_service=private_nh.advertiseService("get_opendrive_map", &OpendriveGlobalPlanner::get_opendrive_map,this);

    dsrv_ = new dynamic_reconfigure::Server<iri_opendrive_global_planner::OpendriveGlobalPlannerConfig>(ros::NodeHandle("~/" + name));
    dynamic_reconfigure::Server<iri_opendrive_global_planner::OpendriveGlobalPlannerConfig>::CallbackType cb = boost::bind(&OpendriveGlobalPlanner::reconfigureCB, this, _1, _2);
    dsrv_->setCallback(cb);

    initialized_ = true;
  } else
    ROS_WARN("This planner has already been initialized, you can't call it twice, doing nothing");
}

void OpendriveGlobalPlanner::map_connect_callback(const ros::SingleSubscriberPublisher &subs)
{
  subs.publish(this->full_path_);
}

void OpendriveGlobalPlanner::create_opendrive_map(std::string &filename,double resolution,double scale_factor,double min_road_length)
{
  std::vector<double> x,partial_x,y,partial_y;
  double max_x=std::numeric_limits<double>::min(),min_x=std::numeric_limits<double>::max(),max_y=std::numeric_limits<double>::min(),min_y=std::numeric_limits<double>::max();
  COpendriveRoad road;

  road.load(filename);
  road.set_resolution(resolution);
  road.set_scale_factor(scale_factor);
  road.set_min_road_length(min_road_length);
  this->full_path_.header.frame_id = this->opendrive_frame_id_;
  this->full_path_.header.stamp = ros::Time::now();
  this->full_path_.info.map_load_time = ros::Time::now();
  this->full_path_.info.resolution = resolution;
  for(unsigned int i=0;i<road.get_num_nodes();i++)
  {
    const COpendriveRoadNode &node=road.get_node(i);
    for(unsigned int j=0;j<node.get_num_links();j++)
    {
      const COpendriveLink &link=node.get_link(j);
      link.get_trajectory(partial_x,partial_y);
      x.insert(x.end(),partial_x.begin(),partial_x.end());
      y.insert(y.end(),partial_y.begin(),partial_y.end());
      for(unsigned int k=0;k<partial_x.size();k++)
      {
        if(partial_x[k]>max_x)
          max_x=partial_x[k];
        else if(partial_x[k]<min_x)
          min_x=partial_x[k];
        if(partial_y[k]>max_y)
          max_y=partial_y[k];
        else if(partial_y[k]<min_y)
          min_y=partial_y[k];
      }
    }
  }
  this->full_path_.info.width=(max_x-min_x)/resolution;
  this->full_path_.info.height=(max_y-min_y)/resolution;
  this->full_path_.info.origin.position.x=min_x;
  this->full_path_.info.origin.position.y=min_y;
  this->full_path_.info.origin.position.z=0.0;
  this->full_path_.info.origin.orientation.x=0.0;
  this->full_path_.info.origin.orientation.y=0.0;
  this->full_path_.info.origin.orientation.z=0.0;
  this->full_path_.info.origin.orientation.w=1.0;
  this->full_path_.data.resize(this->full_path_.info.width*this->full_path_.info.height,255);
  for(unsigned int i=0;i<x.size();i++)
    this->full_path_.data[this->full_path_.info.width*((unsigned int)((y[i]-min_y)/resolution))+((unsigned int)((x[i]-min_x)/resolution))]=0;
}

bool OpendriveGlobalPlanner::get_opendrive_map(iri_adc_msgs::get_opendrive_map::Request  &req,iri_adc_msgs::get_opendrive_map::Response &res)
{
  res.opendrive_map=this->full_path_;

  return true;
}

void OpendriveGlobalPlanner::reconfigureCB(iri_opendrive_global_planner::OpendriveGlobalPlannerConfig& new_config, uint32_t level) 
{
  try{
    this->roadmap.set_resolution(new_config.resolution);
    this->roadmap.set_scale_factor(new_config.scale_factor);
    this->roadmap.set_min_road_length(new_config.min_road_length);
    this->opendrive_frame_id_=new_config.opendrive_frame;
    this->angle_tol=new_config.angle_tol;
    this->dist_tol=new_config.dist_tol;
    this->multi_hyp=new_config.multi_hyp;
    if(new_config.opendrive_file!=this->config.opendrive_file || new_config.scale_factor!=this->config.scale_factor || new_config.min_road_length!=this->config.min_road_length)
    {
      this->roadmap.load(new_config.opendrive_file);
      this->create_opendrive_map(new_config.opendrive_file,new_config.resolution,new_config.scale_factor,new_config.min_road_length);
    } 
    this->roadmap.set_cost_type((cost_t)new_config.cost_type);
    this->config=new_config;
  }catch(CException &e){
    ROS_ERROR_STREAM(e.what());
  }
}

void OpendriveGlobalPlanner::clearRobotCell(const geometry_msgs::PoseStamped& global_pose, unsigned int mx, unsigned int my) 
{
  if (!initialized_) 
  {
    ROS_ERROR("This planner has not been initialized yet, but it is being used, please call initialize() before use");
    return;
  }

  //set the associated costs in the cost map to be free
  costmap_->setCost(mx, my, costmap_2d::FREE_SPACE);
}

bool OpendriveGlobalPlanner::makePlanService(nav_msgs::GetPlan::Request& req, nav_msgs::GetPlan::Response& resp) 
{
  makePlan(req.start, req.goal, resp.plan.poses);

  resp.plan.header.stamp = ros::Time::now();
  resp.plan.header.frame_id = frame_id_;

  return true;
}

void OpendriveGlobalPlanner::mapToWorld(double mx, double my, double& wx, double& wy) 
{
  wx = costmap_->getOriginX() + mx * costmap_->getResolution();
  wy = costmap_->getOriginY() + my * costmap_->getResolution();
}

bool OpendriveGlobalPlanner::worldToMap(double wx, double wy, double& mx, double& my) 
{
  double origin_x = costmap_->getOriginX(), origin_y = costmap_->getOriginY();
  double resolution = costmap_->getResolution();

  if (wx < origin_x || wy < origin_y)
    return false;

  mx = (wx - origin_x) / resolution;
  my = (wy - origin_y) / resolution;

  if (mx < costmap_->getSizeInCellsX() && my < costmap_->getSizeInCellsY())
    return true;

  return false;
}

bool OpendriveGlobalPlanner::makePlan(const geometry_msgs::PoseStamped& start, const geometry_msgs::PoseStamped& goal,std::vector<geometry_msgs::PoseStamped>& plan) 
{
  return makePlan(start, goal, 0.0, plan);
}

bool OpendriveGlobalPlanner::makePlan(const geometry_msgs::PoseStamped& start, const geometry_msgs::PoseStamped& goal,double tolerance, std::vector<geometry_msgs::PoseStamped>& plan) 
{
  double yaw,best_cost;
  unsigned int best_path_index;
  std::vector<unsigned int> best_path;
  std::vector<double> x,y,heading;
  std::vector< std::vector<unsigned int> > paths;
  std::vector<double> costs;
  std::vector<TMapPose> start_candidates,end_candidates;
  geometry_msgs::PoseStamped start_out,goal_out,point;
  std::string target_frame;
  std::string source_frame;
  ros::Time time;
  ros::Duration timeout;
  geometry_msgs::TransformStamped transform;

  boost::mutex::scoped_lock lock(mutex_);
  if (!initialized_) {
    ROS_ERROR("This planner has not been initialized yet, but it is being used, please call initialize() before use");
    return false;
  }

  //clear the plan, just in case
  plan.clear();

  ros::NodeHandle n;
  std::string global_frame = frame_id_;

  //until tf can handle transforming things that are way in the past... we'll require the goal to be in our global frame
  if (goal.header.frame_id != global_frame) 
  {
    ROS_ERROR("The goal pose passed to this planner must be in the %s frame.  It is instead in the %s frame.", global_frame.c_str(), goal.header.frame_id.c_str());
    return false;
  }

  if (start.header.frame_id != global_frame) 
  {
    ROS_ERROR("The start pose passed to this planner must be in the %s frame.  It is instead in the %s frame.", global_frame.c_str(), start.header.frame_id.c_str());
    return false;
  }

  /* transform start and end positions to map opendrive */
  try{
    target_frame = this->opendrive_frame_id_;
    source_frame = start.header.frame_id;
    time = ros::Time(0);
    timeout = ros::Duration(0.1);
    if(this->tf2_buffer.canTransform(target_frame, source_frame, time, timeout))
    {
      transform = this->tf2_buffer.lookupTransform(target_frame, source_frame, time);
      tf2::doTransform(start,start_out, transform);
    }else{
      ROS_WARN("No transform found for start point from '%s' to '%s'", source_frame.c_str(), target_frame.c_str());
    }
    source_frame = goal.header.frame_id;
    if(this->tf2_buffer.canTransform(target_frame, source_frame, time, timeout))
    {
      transform = this->tf2_buffer.lookupTransform(target_frame, source_frame, time);
      tf2::doTransform(goal,goal_out, transform);
    }else{
      ROS_WARN("No transform found for end point from '%s' to '%s'", source_frame.c_str(), target_frame.c_str());
    }
  }catch (tf2::TransformException &ex){
    ROS_ERROR("TF2 Exception: %s",ex.what()); 
  }

  try{
    ROS_WARN("Make Plan");
    yaw=tf2::getYaw(start_out.pose.orientation);
    this->roadmap.set_start_pose(start_out.pose.position.x,start_out.pose.position.y,yaw,this->dist_tol,this->angle_tol);
    this->roadmap.get_start_pose_candidates(start_candidates);
    std::cout << "Start pose candidates: " << std::endl;
    for(unsigned int i=0;i<start_candidates.size();i++)
    {
      std::cout << i << ". x: " << start_candidates[i].pose.x << ", y:" << start_candidates[i].pose.y << ", heading: " << start_candidates[i].pose.heading << std::endl;
      std::cout << "   distance from desired pose: " << start_candidates[i].dist << std::endl;
    }
    yaw=tf2::getYaw(goal_out.pose.orientation);
    this->roadmap.set_end_pose(goal_out.pose.position.x,goal_out.pose.position.y,yaw,this->dist_tol,this->angle_tol);
    this->roadmap.get_end_pose_candidates(end_candidates);
    std::cout << "End pose candidates: " << std::endl;
    for(unsigned int i=0;i<end_candidates.size();i++)
    {
      std::cout << i << ". x: " << end_candidates[i].pose.x << ", y:" << end_candidates[i].pose.y << ", heading: " << end_candidates[i].pose.heading << std::endl;
      std::cout << "   distance from desired pose: " << end_candidates[i].dist << std::endl;
    }
    this->roadmap.find_shortest_path(this->multi_hyp);
    this->roadmap.get_paths(costs,paths);
    for(unsigned int i=0;i<paths.size();i++)
    {
      std::cout << "path " << i << ":" << std::endl;
      for(unsigned int j=0;j<paths[i].size();j++)
        std::cout << paths[i][j] << ",";
      std::cout << std::endl;
    }
    best_path_index=this->roadmap.get_best_path(best_cost,best_path);
    if(best_path_index==-1)
      return false;
    std::cout << "best path index: " << best_path_index << std::endl;
    for(unsigned int i=0;i<best_path.size();i++)
      std::cout << best_path[i] << ",";
    std::cout << std::endl;
    this->roadmap.get_trajectory(best_path_index,x,y,heading);
    plan.resize(x.size());
    try{
      target_frame = this->frame_id_;
      source_frame = this->opendrive_frame_id_;
      time = ros::Time(0);
      timeout = ros::Duration(0.1);
      if(this->tf2_buffer.canTransform(target_frame, source_frame, time, timeout))
      {
        transform = this->tf2_buffer.lookupTransform(target_frame, source_frame, time);
        point.header.frame_id=this->frame_id_;
        point.header.stamp=time;
        for(unsigned int i=0;i<x.size();i++)
        {
          point.pose.position.x=x[i];
          point.pose.position.y=y[i];
          point.pose.position.z=0.0;
          tf2::Quaternion orientation;
          orientation.setRPY(0.0,0.0,heading[i]);
          point.pose.orientation=tf2::toMsg(orientation);
          tf2::doTransform(point,plan[i],transform);
          plan[i].header.frame_id=this->frame_id_;
          plan[i].header.stamp=time;
        }
      }else{
        ROS_WARN("No transform found for path points from '%s' to '%s'", source_frame.c_str(), target_frame.c_str());
      }
    }catch (tf2::TransformException &ex){
      ROS_ERROR("TF2 Exception: %s",ex.what()); 
    }

  }catch(CException &e){
    ROS_ERROR_STREAM(e.what());
    return false;
  }
  //make sure to resize the underlying array that Navfn uses

  //publish the plan for visualization purposes
  publishPlan(plan);
  return !plan.empty();
}

void OpendriveGlobalPlanner::publishPlan(const std::vector<geometry_msgs::PoseStamped>& path) 
{
  if (!initialized_) 
  {
    ROS_ERROR("This planner has not been initialized yet, but it is being used, please call initialize() before use");
    return;
  }

  //create a message for the plan
  nav_msgs::Path gui_path;
  gui_path.poses.resize(path.size());

  gui_path.header.frame_id = frame_id_;
  gui_path.header.stamp = ros::Time::now();

  // Extract the plan in world co-ordinates, we assume the path is all in the same frame
  for (unsigned int i = 0; i < path.size(); i++) 
  {
    gui_path.poses[i] = path[i];
  }

  plan_pub_.publish(gui_path);
}

} //end namespace iri_opendrive_global_planner
