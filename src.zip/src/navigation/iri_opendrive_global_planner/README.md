# Description

This package is a move base global planner plugin that uses the Opendrive road description format to generate a path.

This plugin uses the [iri_opendrive_road_map](https://gitlab.iri.upc.edu/mobile_robotics/adc/libraries/opendrive_road_map) library to load the Opendrive description file and process it to find the shortest path. Check the documentation of this library for further information.

## ROS interface

This plugin has no topic, services or actions.

# How to use it

## Installation

This package is part of the navigation framework for the model car. Follow the instructions in the [iri_model_car_how_to](https://gitlab.iri.upc.edu/mobile_robotics/adc/simulator/iri_model_car_how_to) to set it up.

## Configuration

This move base global planner plugin can be configured using YAML file.

- **opendrive_file** (String; default: "") Name and full of the desired Opendrive file.
- **angle_tol ** (Double; default: 0.5" min: 0.1 max: 1.5707) Angle tolerance to find start and end positions on the road map.
- **dist_tol** (Double; default: 3.0" min: 0.5 max: 10.0) Distance tolerance to find start and end positions on the road map.
- **multi_hyp** (Boolean; default: False) Use multi hypothesis path search. If this option is set to true, instead of using only the closest candidate for the start and end position, the plugin will use a set of candidates which are closer thatn the *dist_tol* parameters, and try to find a path using all possible combinations. Then the best path will be used.
- **resolution** (Double; default: 0.1 min: 0.01 max: 1.0) Resolution of the generated path.
- **scale_factor** (Double; default: 1.0 min: 0.01 max: 10.0) Scale factor applied to the input road description.
- **min_road_length** (Double; default: 0.1 min, 0.01 max: 1.0) Minimum road length to take it into account.
- **cost_type** (Integer; default: 0 min: 0 max: 1) The type of cost that will be used to find the best path. The only two possible values are distance, that is the shortest one, (0) and time, that is the fastest one (1).

# Disclaimer

Copyright (C) Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
Mantainer IRI labrobotics (labrobotica@iri.upc.edu)

This package is distributed in the hope that it will be useful, but without any warranty. It is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. should the program prove defective, the GMR group does not assume the cost of any necessary servicing, repair  or correction.

In no event unless required by applicable law the author will be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs), even if the author has been advised of the possibility of such damages.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>


