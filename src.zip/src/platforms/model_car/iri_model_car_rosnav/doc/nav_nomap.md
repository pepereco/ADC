# Navigation without a map

Use ROS move_base node to make the platform move without a built map.

* Run the simulation of the model car in a world with some objects:
    ```bash
    roslaunch iri_model_car_gazebo sim.launch world:=objects
    ```
* Run the navigation algorithms:
    ```bash
    roslaunch iri_model_car_rosnav nav_no_map.launch
    ```
* Run rviz
    ```bash
    rviz -d `rospack find iri_model_car_rosnav`/rviz/model_car_nav_no_map.launch
    ```
* On Rviz 
    * use the '2d Nav Goal' tool (shortcut 'g') and click-drag somewhere inside the global costmap to send a goal
    * The global planner will compute the path to reach the goal (blue line)
    * The model car will start following the path until reaching the goal.
