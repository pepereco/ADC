# Navigation in a map

Use ROS move_base node to make the platform move in a built map.

* Run the simulation of the model car in a world with some objects:
    ```bash
    roslaunch iri_model_car_gazebo sim.launch standalone:=false world:=objects
    ```
* Run the navigation algorithms. Here we are loading an already build map of the world `objects`.
    ```bash
    roslaunch iri_model_car_rosnav nav_map.launch map_path:=`rospack find iri_model_car_rosnav`/maps map_name:=objects
    ```
* Run rviz
    ```bash
    rviz -d `rospack find iri_model_car_rosnav`/rviz/model_car_nav_map.launch
    ```
* On Rviz 
    * use the '2d Nav Goal' tool (shortcut 'g') and click-drag somewhere inside the map to send a goal
    * The global planner will compute the path to reach the goal (blue line)
    * The model car will start following this path until reachin the goal.
