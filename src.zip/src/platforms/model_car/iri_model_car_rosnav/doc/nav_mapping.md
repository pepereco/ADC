# Creating a map

Use SLAM/Gmapping to create an occupancy grid map.

* Run the simulation of the model car in a world with some objects:
    ```bash
    roslaunch iri_model_car_gazebo sim.launch standalone:=false world:=objects
    ```
* Run the mapping algorithms:
    ```bash
    roslaunch iri_model_car_rosnav nav_mapping.launch
    ```
* Run rviz
    ```bash
    rviz -d `rospack find iri_model_car_rosnav`/rviz/model_car_nav_gmapping.launch
    ```
* Move the model car around with teleoperation node or sending navigation goals.
    * `roslaunch iri_model_car_launch teleop_rqt.launch`
    * On Rviz use the '2d Nav Goal' tool (shortcut 'g') and click-drag somewhere to send a goal

* Map will be updated and showed in rviz as an image with:
    * Free space as white cells
    * Obstacles as black cells
    * Unknown space as grey cells

* When done building the map, save it somewhere giving it a name:
    ```
    roscd iri_model_car_rosnav/maps
    rosrun map_server map_saver map:=model_car/map -f my_map_name
    ```
* Two files, my_map_name.pgm with the image and my_map_name.yaml with some parameters will be saved.
