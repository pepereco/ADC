# Description

This package contains navigation related parameter and launch files particular to the ADD robot. 

# Dependencies

This node has the following dependencies:

 * [iri_rosnav](https://gitlab.iri.upc.edu/labrobotica/ros/navigation/iri_rosnav)

# Install

This package, as well as all IRI dependencies, can be installed by cloning the
repository inside the active workspace:

```
roscd
cd ../src
git clone  
```

However, this package is normally used as part of a wider installation (i.e. a
robot, an experiment or a demosntration) which will normally include a complete
rosinstall file to be used with the [wstool](http://wiki.ros.org/wstool) tool.

# How to use it

 * [Navigation without a map](doc/nav_no_map.md):  example using a navigation without a map, using the global costmap.
 * [Navigation making a map](doc/nav_mapping.md):  example using navigation with gmapping SLAM to make a new map.
 * [Navigation with a map](doc/nav_map.md): example using a navigation with a map and AMCL localization.
