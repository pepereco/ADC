# MODEL_CAR_HOW_TO

The iri_model_car packages provides the necessary tools to use a 1:8 scale car-like vehicle both in a simulated environment using Gazebo and in the real world. The simulation model offers a realistic model of the actual car, with the same control and sensor ROS interfaces.

The real model car is shown in the next image.

<img src="doc/images/real_car.png" alt="Picture of the real model car" width="992" height="744">

The sensors available on the platform are listed next. Find more details here: [Hardware Description](https://drive.google.com/file/d/1Oa_7VohhWLnLy7CKg7BqL18wdta3doqX/view?usp=sharing).

* Frontal [RP Lidar A2](https://www.slamtec.com/en/Lidar/A2) sensor.
* Frontal camera [Basler daA1280-54uc](https://www.baslerweb.com/en/products/cameras/area-scan-cameras/dart/daa1280-54uc-s-mount/) with a resolution of 1280x960 pixels at 45 FPS.
* Rear camera [Delock 96368](https://www.delock.com/produkte/729_Cameras/96368/technische_details.html) with a resolution of 1024x768 pixel at 30 FPS.
* [MPU9250](https://invensense.tdk.com/products/motion-tracking/9-axis/mpu-9250/) IMU sensor.
* 5 HC-SR04 ultrasonic sensor (2 at each side and 3 on the rear).

## Installation

Download the following rosinstall files:

* [iri_core.rosinstall](https://gitlab.iri.upc.edu/labrobotica/ros/iri_ros_how_to/-/raw/melodic_migration/rosinstall/iri_core.rosinstall)
* [iri_model_car_common.rosinstall](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/simulator/iri_model_car_how_to/-/raw/master/rosinstall/iri_model_car_common.rosinstall)

To use the simulated model, download also the following rosinstall file:

* [iri_model_car_simulator.rosinstall](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/simulator/iri_model_car_how_to/-/raw/master/rosinstall/iri_model_car_simulator.rosinstall)

To use the real model car, download also the following rosinstall file:

* [iri_model_car.rosinstall](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/simulator/iri_model_car_how_to/-/raw/master/rosinstall/iri_model_car.rosinstall)

and merge them into your workspace with the steps in this [wstool tutorial](http://wiki.ros.org/wstool#Merge_in_Additional_rosinstall_Files).

Install all ROS dependencies with the following commands:

```
roscd
cd ..
rosdep install -i -r --from-paths src
```

Compile all the ROS packages with the following command:

```
catkin_make
```

## Simulated robot
To use the simulated robot follow this: [simulated_model_car](doc/simulated_model_car.md).

## Real robot
To use the real robot, follow this: [real_model_car](doc/real_model_car.md).

## Tutorials

Next there is a set of tutorials that introduce some important topics:

* [General operation](doc/operation.md): introduction to the basic operation of the model car, and also a description of the available sensor topics and how to monitor them.
* [Teleoperation](doc/teleoperation.md): introduction on how to tele-operate the model car.
* [Generate a new map](doc/mapping.md): introduction on how to create a new map of an environment.
* [Localization](doc/localization.md): introduction to some tools used to improve the localization of the model car, both local (from the *odom* to the *base_footprint* frame) and global (from the *map* to the *odom* frame).
* [Navigation](doc/navigation.md): introduction to the navigation stack used for the model car.

## Disclaimer

Copyright (C) Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
Mantainer IRI labrobotics (labrobotica@iri.upc.edu)

This package is distributed in the hope that it will be useful, but without any warranty. It is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. should the program prove defective, the GMR group does not assume the cost of any necessary servicing, repair  or correction.

In no event unless required by applicable law the author will be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs), even if the author has been advised of the possibility of such damages.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>

