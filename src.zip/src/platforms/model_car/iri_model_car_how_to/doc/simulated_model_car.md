# Simulated model car

The simulation model of the model car is implemented as a plugin for the Gazebo Simulator, and provides the same control and sensor interfaces as the real robot. The next image shows an image of the model car in simulation.

<img src="images/sim_model_car.png" alt="Gazebo simulation model of the model car" width="812" height="524">

As you can see in the previous image, the simulation model is quite different from the real model car, however, the way to control it, the position of the sensors and their main features are exactly the same.

The ROS packages associated with the simulated model are:

* [iri_model_car_gazebo](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/simulator/iri_model_car_gazebo): main launch and configuration files for the simulation.
* [iri_model_car_controller](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/simulator/iri_model_car_controller): gazebo plugin to control the simulated car.

## Usage

To spawn a single car in an empty simulation world, execute the following command:

```
roslaunch iri_model_car_gazebo sim.launch
```

Launch the RVIZ application to show the output of all sensors with the following command:
```
rosrun rviz rviz -d `rospack find iri_model_car_launch`/rviz/model_car.rviz
```

It is possible to spawn as many cars as needed. See the [iri_model_car_gazebo](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/simulator/iri_model_car_gazebo) documentation for more details.

## Changing the simulated world

By default, an empty world is used in simulation. An other world with some random obstacles is also provided for testing purposes. To start the simulation with this world, execute the following command:

```
roslaunch iri_model_car_gazebo sim.launch world:=objects
```

Note that the objects on this world will not appear on the RVIZ application, however, their effect can be noticed on the sensors data.

Other worlds can be created to suit particular needs. To create new simulation worlds, follow the instructions in [here](http://gazebosim.org/tutorials?tut=build_world).

## configuration

The parameters of the simulated model, such as the steering angle limits, linear speed limits or the topic names, can be modified using a YAML configuration file. See the [iri_model_car_controller](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/simulator/iri_model_car_controller) for more information. 

The parameters of the simulated sensors can also be modified using a set of YAML configuration files (one for each sensor). See the [iri_model_car_gazebo](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/simulator/iri_model_car_gazebo) for more details.

In both cases it is recommended to create new configuration files, using the existing ones as a template, and set their location in the launch file. The default configuration files are located in the *config* folder of the two previous ROS packages.
