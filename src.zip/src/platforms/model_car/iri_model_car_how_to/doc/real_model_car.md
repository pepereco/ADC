# Real model car

Here the basic procedures to set up the real model car are presented. Before using the real model car, take a look at the [hardware description manual](https://drive.google.com/file/d/1Oa_7VohhWLnLy7CKg7BqL18wdta3doqX/view?usp=sharing) to get familiar with all its parts and basic procedures.

The ROS packages associated with the real model car are:

* [iri_model_car_battery_driver](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_battery_driver): driver node for the battery monitoring.
* [iri_model_car_ultrasounds_driver](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_ultrasounds_driver): driver node for publishing range distance from the ultrasound sensors.
* [iri_model_car_egomotion_driver](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_egomotion_driver): driver node for publishing IMU and wheel encoder sensor data.
* [iri_model_car_actuators_driver](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_actuators_driver): driver node for sending speed and steering angle commands to the platform.
* [iri_model_car_bringup](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_bringup): basic launch and configuration files to bring up the basic operation of the model car.

## Batteries

Two batteries are needed for the real model car:

* A **motors battery** for the traction motor and the steering servo (see section 1.7.2 of the [hardware description manual](https://drive.google.com/file/d/1Oa_7VohhWLnLy7CKg7BqL18wdta3doqX/view?usp=sharing) for more details).
* A **payload battery** for the on-board computer, the sensors and other on-board devices (see section 1.7.3 of the [hardware description manual](https://drive.google.com/file/d/1Oa_7VohhWLnLy7CKg7BqL18wdta3doqX/view?usp=sharing) for more details).

The payload battery has a T-Plug to XT60 connector adapter (shown in the next image) that must be always attached to the battery, because it is necessary to connect it to both the car and the charger.

<img src="images/T_to_XT60_adapter.png" alt="Payload battery adapter" width="220" height="104">

To charge the batteries, follow the instructions in section 1.7.5 of the [hardware description manual](https://drive.google.com/file/d/1Oa_7VohhWLnLy7CKg7BqL18wdta3doqX/view?usp=sharing). When configuring the charger, pay attention to the following considerations:

* Both batteries are *LiPo*
* Always use the balance-charge mode.
* Configure the correct number of elements in series (**2S** for the motors battery and **6S** for the payload battery).
* Configure the correct capacity (**5400 mAh** for the motors battery and **5200 mAh** for the payload battery).
* Never use a charge current bigger than the capacity of the battery (**5.4 A** for the motors battery and **5.2 A** for the payload battery).

A single battery charger is provided to charge both batteries. It is recommended to save each configuration on one of the available configuration memories to easily switch between them. See the [charger manual](https://drive.google.com/file/d/1d0BsH7HHUVvoKv3n10_9eOuW2798cGz3/view?usp=sharing) for details on the configuration process.

## Power up

To power up the model car, follow the instructions in chapter 2 of the [hardware description manual](https://drive.google.com/file/d/1Oa_7VohhWLnLy7CKg7BqL18wdta3doqX/view?usp=sharing).

For development purposes, it is recommended to:

* Use the external power supply to power the computer and all the other components of the platform, and connect the motors battery to power the traction motor and the steering servo when necessary.
* Place the car on top of the provided platform to avoid accidental movements that may result in damage to the model car.

For testing purposes, it is recommended to:

* Place and connect both batteries and remove the external power supply.
* Unplug any devices that may be attached to the model car (display, keyboard, mouse, ethernet cable, etc.).

A few seconds after the button labeled *PC* on the left side of the car has been pressed, the computer and all the other elements will be up and running. By default no ROS nodes are launched at start up.

## Connect

Several options exist to connect to the model car. 

See these [communication](communication.md) instructions for more details.

To connect to the model car from an external computer, execute the following command:

```
ssh adc@<ip address of the model car>
```

This command will prompt for the *adc* user password. To avoid having to input the password every time, follow these steps:

* Generate the public and private ssh-keys in the local machine. When asked for a keyphrase just type enter.

```
ssh-keygen -t rsa -b 4096 -C "username"
```

* Copy the public they to the remote machine with ssh-copy-id and that would be all: 

```
ssh-copy-id adc@<ip address of the model car>
```

## Bring up

By default no ROS nodes are launched at start up. To launch the basic ROS driver and tools nodes, execute the following command:
```
roslaunch iri_model_car_bringup bringup.launch
```

Although all ROS nodes should execute on the on-board computer, for development purposes it is recommended to test new ROS nodes on an external computer before deploying them into the on-board computer. To do so, follow the instructions in this [tutorial](http://wiki.ros.org/ROS/Tutorials/MultipleMachines), paying special attention to the [network setup](http://wiki.ros.org/ROS/NetworkSetup).

In summary, it's necessary to export the following variables **on each terminal of the car**:
```bash
export ROS_IP=<ip adress of the model car>
export ROS_MASTER_URI=http://<ip adress of the model car>:11311
```
and **on each terminal of the development computer**:
```bash
export ROS_IP=<ip adress of the development computer>
export ROS_MASTER_URI=http://<ip adress of the model car>:11311
```

To **make these exports automatics when opening a new terminal** add these lines at the end of each **~/.bashrc**. Notice that **it will only work if the car and the development computer have always the same ip address**. For changes to take effect is necessary the source the bashrc:
```bash
source ~/.bashrc
```

When working with several computers in a single ROS networks, it is very important that all computers are time synchronized. The model car has been configured to work as a time reference when there is no Internet connection. To synchronize an external computer there are two options:

* Using ntpdate:
```bash
sudo apt update && sudo apt upgrade
sudo apt install ntpdate
sudo ntpdate -u <ip address of the model car>
```

* Using ntp: In this case it's necessary to stop the ntp service:
```bash
sudo apt update && sudo apt upgrade
sudo apt install ntp
sudo service ntp stop
sudo timeout 10 ntpd -gq <ip address of the model car>
```

## Calibration

See [calibration](./calibration.md) to take a look on the different procedures to calibrate:
* The IMU sensor.
* Both front and rear cameras.
* The speed parameters.
* The steering parameters.

## Power down

Before powering down the model car, make sure all process are terminated and to shut down the on-board computer with the following command:
```
sudo halt -p
```

When the GPU and CPU fans have stopped, it is save to:

* Switch off the *PC* and *motor* buttons
* Wait until the Arduino and on-board PCB boards LED's turn off. If after a few minutes, the LED's are still one, you can safely proceed to the next step.
* Disconnect the power and monitor connectors of both batteries.

