# Communication

There exist several ways to connect to the on-board computer of the model car.

## Onboard communication

The simplest one is to directly work on the on-board computer. To do so:

* Connect an HDMI display to the HDMI connector on the GPU. The display should be connected to the GPU before power up, because otherwise it will not be automatically detected.
* Connect a mouse and a keyboard to any available USB port.

This option is not recommended except in cases when it is impossible to connect using any other means, to perform the initial configuration or to test the correct operation of the model car.

## Network communication

The recommended way to connect to the on-board computer on the model car is through a network. By default the Ethernet interface is configured to use DHCP (expects an external device to provide it with an IP address) and the wireless connection is disabled.

Only the Ethernet connector on the left side of the model car (the closest one to the power on button) should be used.

There exist multiple ways to do that. In this section we will describe two of them: using an external wireless router (which is the recommended one) and using a point to point connection. Other options are possible but they are neither described here nor supported.

The desired setup should provide the following features:

* Internet access to install new software and update existing one on the on-board computer
* Provide wired connection to the on-board computer. This type of connection is recommended for development purposes because it provides the maximum bandwidth and allows to monitor all the sensors and other platform information in real time.
* Provide wireless connection to the on-board computer. This type of connection is recommended for testing purposes because it allows the model car to move freely without any cables attachment to it. However, in this case the available bandwidth may be severely reduced, and it is recommended to reduce the number of information monitored from an external computer
* Provide a fixed network configuration where all the computers have always the same IP addresses.

For each options the pros and cons are also discussed.

### **Router** (**RECOMMENDED**)

From our point of view this is the most flexible way to connect to the model car. This configuration allows multiple users to connect to the model car on-board computer at the same time, and also use the same setup for both development and testing purposes. However, it requires an external wireless router that has to be properly configured. There exist a great diversity of wireless routers in the market, and the configuration of each one may be different. Here we present the general setup without any particular details:

* Configure the wireless router in *access point* configuration.
* Setup a Wireless network with an SSID and password.
* Enable the DHCP server to provide IP addresses to all connected devices (both wired and wireless).
* If possible, assign a fixed IP address to all connected devices (both wired and wireless).
* Connect the WAN port or a USB device (cell phone, 3G/4G/5G dongle) to provide Internet access (if possible).

The internet connection may be erratic if the model car is connected through wireless and wired connections to the external router at the same time.

### **Point to point Ethernet connection**

Another option is to create a direct link between the on-board computer and a single external computer. To setup this configuration. follow the next steps:

* Connect an Ethernet cable between an external computer and the Ethernet port in the left side of the model_car (the closest one to the power on button).
* On the external computer:
    * Run the following command on a terminal:
```
nm-connection-editor
```
    * Click the `+` button on the lower left corner of the window.
    * Choose *Ethernet*, click the `Create...` button.
    * Give it a Connection name, for example, shared_eth.
    * In the IPv4 Settings tab, choose Method: *Shared to other computers*.
    * Click the `Save` button.
    * Close the Network Connections window.
    * Activate the new created connection by executing the following command:
```bash
sudo nmcli con up id shared_eth
```
    * To find out the IP address assigned to the model car, execute the following command:
```bash
sudo arp-scan -l
```

This configuration only allows a single computer to be connected to the model car at any time, however, it is much simpler to setup and does not require any additional devices. In this case, the wireless interface can be used to provide Internet access to the model car.

