# Localization

In ROS, the position of the model car with respect to global frame (*map* in general) is fully defined by two transformations in the [TF framework](http://wiki.ros.org/tf):

* The transformation between the *odom* and *base_footprint* frames which we call local localization. In ROS this transformation is normally published by the ROS node that computes the odometry information.
* The transformation between the *map* and *odom* frames which we call global localization. In ROS this transformation can be published by the [AMCL](http://wiki.ros.org/amcl) package.

For the model car, the [robot_localization](http://docs.ros.org/en/melodic/api/robot_localization/html/index.html) package is used to fuse multiple sensor data together to improve the local and global pose estimation. This package uses an Extended Kalman Filter that accepts an arbitrary number of inputs of one of the following ROS standard messages:

* Odometry
* IMU
* PoseWithCovarianceStamped
* TwistWithCovarianceStamped

It is very important that each of the inputs provide a valid and realistic covariance information as it is used to choose which measurements will be taken more into account in the process.

## Local localization

For the model car, the following information from the wheel encoder and the IMU sensors is used to generate the local pose estimation:

* Wheel encoder: linear velocity in the x and y axes and the angular velocity in the z axis.
* IMU: the heading, the angular velocity in the z axis and the linear acceleration on the x and y axis.

The next image shows the basic operation of the local localization process for the model car.

<img src="images/local_loc_diagram.png" alt="Basic operation of the local localization for the model car" width="962" height="152">

The configuration of the local robot_localization node is located in the *config* folder in the [iri_model_car_launch](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_launch) package. For the model car, the fusion of the wheel encoder and the IMU is done by default, and it is launched with the other basic ROS nodes.

To see the difference between the raw and fused odometries, **make sure that either the simulated or real robot are up and running** and execute the following command to display RVIZ. This command needs a display connected. If this command is executed on a terminal on a different computer make sure that is connected and [configured to see the model_car ROS network](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up):

```
rosrun rviz rviz -d `rospack find iri_model_car_launch`/rviz/model_car.rviz
```

And, on another terminal, the next one to launch the teleoperation tool. This command needs a display connected. If this command is executed on a terminal on a different computer make sure that is connected and [configured to see the model_car ROS network](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up):

```
roslaunch iri_model_car_launch teleop_rqt.launch
```

Move the car around and observe how the red arrow (raw encoder odometry) moves away from the yellow arrow (fused odometry). In simulation it is possible to compare both odometries with the ground truth, shown as a blue arrow.

The next images show the difference between the three odometry arrows in RVIZ.

<img src="images/local_loc.png" alt="Screenshot to show the difference between the raw and fused odometries in RVIZ" width="1090" height="783">


## Global localization

In general, a good source for absolute localization data used to improve the global localization is the Global Navigation Satellite System (GNSS) data, however, the model car will normally operate indoors, so it is not possible to use GNSS data. In this case, the following information from the wheel encoder sensors and the AMCL data is used to generate the global pose estimation:

* Wheel encoder odometry: linear velocity in the x and y axes and the angular velocity in the z axis.
* AMCL: position in the x and y coordinates and heading

The next image shows the basic operation of the global localization process for the model car.

<img src="images/global_loc_diagram.png" alt="Basic operation of the global localization for the model car" width="966" height="260">

As shown in the previous image, an other instance of robot_localization for local localization will be always running as well, providing the estimation between *odom* and *base_footprint* frames.

The configuration of the global robot_localization node is located in the *params* folder in the [iri_model_car_rosnav](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_rosnav) package. For the model car, the global localization fusion is automatically used with the navigation framework. For more details take a look at the [Navigation](doc/navigation.md) tutorial.

It is important to note that to use the AMCL node, a map of the environment is needed. To generate a map, follow the instructions in the [Mapping](doc/mapping.md) tutorial.

To test the correct operation of the global localization, follow the instructions for the map based navigation in the [Navigation](doc/navigation.md) tutorial, and then:

* On rviz, use the “2D Pose Estimate” tool button (or keyboard ‘p’ key) and then click and drag somewhere near the robot pose but slightly different. This sets a new localization pose, and now the scan points won’t match the map.
* Move the car around by using the teleoperation tool. This command needs a display connected. If this command is executed on a terminal on a different computer make sure that is connected and [configured to see the model_car ROS network](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up):

```
roslaunch iri_model_car_launch teleop_rqt.launch
```

* Alternatively, you can also send navigation goals by using the “2D Nav Goal” tool button (or keyboard ‘g’ key) and then click and drag somewhere in the map. Keep in mind that the ackermann configuration of the model car makes it difficult to correct large pose estimation errors, because the robot can not turn on itself and needs a lot of maneuvers to correct relatively small orientation errors.
