# Generate a new map

In this tutorial we will cover how to create a new map using the model car. These maps will be used to autonomously navigate the robot, although it is also possible to navigate without a map as explained in the [Navigation](navigation.md) tutorial.

In ROS, maps are represented by grids (known as costmaps) of a given resolution, in which each cell can be either:

* White cells: free space
* Black cells: obstacles
* Grey cells: unknown space

To generate this map, the [gmapping](http://wiki.ros.org/gmapping) ROS package is used. This tool requires:

* A 2D laser scan, in this case the one provided by the frontal RP LIDAR
* The actual pose estimation of the model car in the environment through the TF

and uses a SLAM algorithm to fill the map grid, improving the estimation as the same spaces are revisited by the robot. Check the documentation of [gmapping](https://openslam-org.github.io/gmapping.html) tool for a more detailed explanation of how it works.

One important parameter that needs to be set before starting the mapping process is the resolution of the desired map. The resolution can be set as an input argument in the launch file. By default this resolution is set to 0.05 m, which is enough for a robot of this size, but it can be changed. The resolution may have an impact on the performance of the navigation and localization, but it is very important for the SBPL global planner because its motion primitives must have the same resolution (See the [Navigation](tutorial) for more details).

**Make sure that either the simulated or real robot are up and running**. In simulation make sure the desired world to map has been specified (in this case the *objects* world will be used). Then execute the following commands. If this command is executed on a terminal on a different computer make sure that is connected and [configured to see the model_car ROS network](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up):

```
roslaunch iri_model_car_rosnav nav_mapping.launch
```

This command will execute all the necessary ROS nodes and configure the navigation stack to create the map, and then be able to save it when done.

Execute the following command to display the map in RVIZ as it is being created. This command needs a display connected. If this command is executed on a terminal on a different computer make sure that is connected and [configured to see the model_car ROS network](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up):

```
rosrun rviz rviz -d `rospack find iri_model_car_rosnav`/rviz/model_car_gmapping.rviz
```

Then, it is necessary to move the model car. It is possible to move it by sending navigation goals, but since at the beginning the most of the map is unknown, it is better to use the teleoperation introduced [here](teleoperation.md). To launch the teleoperation GUI, execute the following command. This command needs a display connected. If this command is executed on a terminal on a different computer make sure that is connected and [configured to see the model_car ROS network](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up):

```
roslaunch iri_model_car_launch teleop_rqt.launch
```

As you move the car around, you will see how the map is updated. At some moments the model car may have a large localization error. In these cases, continue moving the car towards an area already explored to try to correct it. If the localization problem is not solved and the SLAM algorithm starts placing obstacles where it should not, it is better to start over the process.

The next image shows an intermediate step of the mapping process.

<img src="images/mapping.png" alt="Screenshot of the mapping process in RVIZ" width="751" height="674">

When you are satisfied with the result, it is time to save the map. To do so, execute the following command. If this command is executed on a terminal on a different computer make sure that is connected and [configured to see the model_car ROS network](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up):

```
rosrun map_server map_saver -f `rospack find iri_model_car_rosnav`/maps/<map name> map:=/model_car/map
```

This command will generate two file:

* An image (in PGM format) where each pixel represents one of the cells of the map
* A YAML file with metadata about the map.
