# Tele-operating the model car

In this tutorial we will give an introduction on how to tele-operate the model car. We will use the [RQT_robot_steering](http://wiki.ros.org/rqt_robot_steering) ROS package.

The default namespaces used throughout this tutorial start */model_car*, which is the default name assigned to the robot. If this name is changed (using the *name* argument in the launch command), all the topic names and configuration files should be changed accordingly.

**Make sure that either the simulated or real robot are up and running** and execute the following command. This command needs a display connected. If this command is executed on a terminal on a different computer make sure that is connected and [configured to see the model_car ROS network](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up):

```
roslaunch iri_model_car_launch teleop_rqt.launch
```

This command will open a GUI already set up to control the model car (shown in the next image).

<img src="images/teleop.png" alt="Screenshot of the tele-operation tool GUI" width="350" height="406">

Use the two sliders to move the car around the environment. The vertical slide controls the linear speed and the horizontal one controls the angular speed. The limits of both speeds are set in a configuration file. To set one of the speeds to 0, use the button labeled "0" at the center of each slider.

The only configurable parameters of the RQT_robot_steering node are the maximum and minimum linear and angular speeds, and they are set in the *config/teleop_config.yaml* configuration file in the [iri_adc_model_car_launch](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_launch) package. These parameters only depend on the platform, However, it is recommended to copy this file into the local working ROS package.
