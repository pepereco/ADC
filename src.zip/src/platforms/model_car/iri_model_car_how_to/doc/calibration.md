# Calibration

Several elements on the model car must be calibrated before start working.

## IMU calibration

The IMU sensor data is handled by the Arduino board and sent to the computer, but the gyroscope offset is not canceled. To cancel (or reduce) the offset of the gyroscope, and therefore improve the estimation of the actual pose of the model car, follow the next steps:

* Place the model car on a flat and stable surface, and prevent it from moving.

* Open a **terminal on the car** and launch the model_car with:

    ```bash
    roslaunch iri_model_car_bringup bringup.launch
    ```

* Call the *gyro_cal* service of the *iri_model_car_egomotion_driver* ROS node to start the calibration process. Take care not to move the car while the calibration process is running, otherwise the calibration will not be good. Open a **new terminal on the car** and execute:

    ```bash
    rosservice call /adc_car/iri_model_car_egomotion_driver/cal_gyro {}
    ```

* The calibration process is done in parallel with the normal operation of the driver (+10sec). When it is done the following message will appear on the terminal where the bringup was launched:

    ```
    Gyroscope successfully calibrated
    ```
The number of samples used to calibrate the sensor are defined in the *iri_model_car_egomotion_driver* configuration file. See the [iri_model_car_egomotion_driver](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_egomotion_driver) documentation for more details.

The result of the gyroscope calibration is not stored anywhere, and it should be calibrated every time the platform in brought up.

## Camera calibration

### Extrinsic parameters

The position of the camera in the model car has already been measured and it is specified in the [urdf](http://wiki.ros.org/urdf). 

See [iri_model_car_description/urdf/include/sensors.xacro](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_description/-/blob/master/urdf/include/sensors.xacro)

### Intrinsic parameters

We will use the ROS package [camera_calibration](http://wiki.ros.org/camera_calibration) to calibrate the intrinsic parameters of the cameras.

Follow this tutorial [MonocularCalibration](http://wiki.ros.org/camera_calibration/Tutorials/MonocularCalibration).

**Note**: if you don't have a physical checkerboard panel, for now you can show one on a computer screen. Remember you will need to count the number of interior vertices (#x#) and measure the square size in meters.

Before starting the calibration process, only for the Basler camera (the one in the front), make sure the image is focused. To do so:

* Open a **terminal on the car** and launch the model_car with:

    ```bash
    roslaunch iri_model_car_bringup bringup.launch
    ```

* Launch the basic RVIZ configuration on a new terminal to see the front camera image. This can be done on the car if a display is connected. If not, remember to follow the steps on [bringup for a correct ROS network setup](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up) and launch it on a terminal on the development computer:

    ```bash
    rviz -d `rospack find iri_model_car_launch`/rviz/model_car.rviz
    ```

* If the image is blurry, adjust the optics to sharpen it:
    - Use your fingers and be very careful to not damage the lens.
    - There is a ring at the bottom of the lens thread, which locks the lens rotation. Unlock it by slightly rotating the ring, until the lens is freed.
    - Rotate the lens until the image looks sharp enough.
    - Again, rotate the lock ring in the opposite direction until the lens gets locked.

The calibration procedure for the model_car is:

1. If not already done, launch its bringup.launch **on a terminal on the car**

    ```bash
    roslaunch iri_model_car_bringup bringup.launch
    ```

2. Then, on a new terminal from the model_car computer if you have a display connected, or from an external laptop connected and [configured to see the model_car ROS network](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/real_model_car.md#bring-up), launch the calibration node, specifying `#x#` and `size_in_m`, which will open the calibration gui. 
- For the front camera (basler) 

    ```bash
    rosrun camera_calibration cameracalibrator.py --size #x# --square size_in_m image:=/model_car/sensors/basler_camera/image_raw
    ```

- For the rear camera (delock)
    ```bash
    rosrun camera_calibration cameracalibrator.py --size #x# --square size_in_m image:=/model_car/sensors/delock_camera/image_raw
    ```

4. Move the checkerboard (or model_car) around until all parameter bars become green (x,y,size,skew) and the `Calibration` button is enabled.

5. Click the `Calibration` button, and wait until it's done (may take a while depending on the computer and number of samples used). Once done, you will see the results on the terminal and the corrected image on screen.

6. Click the `Save` button to save the calibration data. As seen in the terminal, it will be saved in `/tmp/calibrationdata.tar.gz`

7. Now you can extract the result file. If you are already in the model_car computer, you can do it directly in `iri_model_car_bringup/calibration`, otherwise you'll need to copy it there. To copy the calibration file to the model car home directory use the following command **in a terminal on the development computer**:

    ```bash
    scp /tmp/calibrationdata.tar.gz ost.txt adc@<ip address of the car>:
    ```
    After the copy is completed, execute the following commands **in a terminal on the car**:

    ```bash
    roscd iri_model_car_bringup/calibration
    tar -xf /tmp/calibrationdata.tar.gz ost.txt
    mv ost.txt ost.ini
    rosrun camera_calibration_parsers convert ost.ini my_new_camera_info.yaml
    ```

8. Use the new calibration file:
- For the front camera (basler), to make the bringup.launch load the camera driver with the new camera info data, you can either rename the file to the original one (`iri_model_car_bringup/calibration/basler_1280x960.yaml`) or change the loaded value, specified in `iri_model_car_bringup/config/basler_camera_config.yaml` as `camera_info_url`.

- For the rear camera (delock), to make the bringup.launch load the camera driver with the new camera info data, you can either rename the file to the original one (`iri_model_car_bringup/calibration/delock_1280x960.yaml`) or change its launch argument (`delock_calib_file`).

## Speed Control

#### Description

The next image shows all elements involved in the speed control loop of the model car.

<img src="images/speed_control.png" alt="Diagram of the speed control loop" width="1045" height="539">

These elements are:

1. A brushless motor (Hacker SKALAR 10) without any sensor.

2. A Brushless motor controller (Robitronic Speedstar) which accepts a radio control PWM signal. The RC PWM signal is a regular PWM signal with a fixed period of 20 ms (50 Hz) and a minimum pulse width of 1ms and a maximum one of 2 ms.

3. An Arduino board that accepts commands from a computer using a USB connection and generates the RC PWM signal. The commands received from the computer are adimensional and in the range from 0 (being the minimum speed) to 180 (being the maximum speed), with 90 being the 0 speed command. Additionally the Arduino also accepts the input from a potentiometer to calibrate the actual 0 speed command (the width of the RC PWM pulse).

4. The *iri_model_car_actuator_driver* handles all the USB communications. It accepts an adimensional control signal in the range from -100 (being the minimum speed) to 100 (being the maximum speed) and generates the commands accepted by the Arduino board.

5. The *iri_model_car_control* generates the control signals given the desired forward speed in m/s and the actual speed of the model car estimated by the model car odometry. This ROS node maps the desired physical speed to the [-100,100] range expected by the actuators driver using a PID controller that can be tuned (see [motion tunning](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/operation.md#motion-tuning) for more details).

6. Two wheel encoders are placed in the left and right rear wheels of the car. These encoders have a resolution of 30 pulses per revolution.

7. An other Arduino board reads the pulses from both encoders and sends the information to a computer using a USB connection. Additionally, this Arduino board also reads the inertial information from an IMU sensor.

8. The *iri_model_car_odometry* uses the wheel encoder data to estimate both the current position and orientation, and the linear and angular velocities of the model car. This information is published and used by the *iri_model_car_control* node to close the speed control loop. Due to the low resolution of the encoders, this node has an internal low pass filter to smooth the estimattion at low speeds that can be tuned (see [motion tunning](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/operation.md#motion-tuning) for more details).

#### Calibration

Several elements in this diagram can be calibrated or tuned:

To calibrate the zero speed command using the potentiometer, follow this steps:

* Locate the speed potentiometer in the front board, on its lower left corner, labeled as `Poti.Speed`. 

* Place the model car on the raising platform, to avoid it from moving.

* Open **a terminal on the car** and launch the model_car with:

    ```bash
    roslaunch iri_model_car_bringup bringup.launch
    ```

* Move the potentiometer in one direction until the wheels start moving. Look at the potentiometer small arrow position.

* Move the potentiometer in the other direction until the wheels start moving in the opposite direction. Look at the potentiometer small arrow position.

* Move the potentiometer to a middle position between the ones achieved in the two previous steps. 

* On **another terminal on the car**, launch a teleoperation node, for example, with the keyboard, and test it works both forwards and backwards. 

    ```bash
    roslaunch iri_teleop_launch keyboard_teleop.launch ns:=model_car
    ```

The brushless motor controller (2) can be also calibrated using the procedure explained in section 3 of the [hardware description manual](https://drive.google.com/file/d/1Oa_7VohhWLnLy7CKg7BqL18wdta3doqX/view). However it is already calibrated and it is not recommended to do it.

The PID in the *iri_model_car_control* node and the low pass filter in the *iri_model_car_odometry* node can be tuned by the user. See [motion tunning](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/blob/master/doc/operation.md#motion-tuning) for more details.

## Steering control

#### Description

The next image shows all elements involved in the steering angle control of the model car.

<img src="images/steer_angle_control.png" alt="Diagram of the steer angle control" width="1029" height="337">

These elements are:

1. A servo motor (ACS1615SG) controlled by a RC PWM signal.

2. An Arduino board that accepts commands from a computer using a USB connection and generates the RC PWM signal. The commands received from the computer are adimensional and in the range from 0 (being the minimum steering angle) to 180 (being the maximum steering angle), with 90 being the 0 steer angle command. Additionally the Arduino also accepts the input from a potentiometer to calibrate the actual 0 steer angle command (the width of the RC PWM pulse).

3. The *iri_model_car_actuator_driver* handles all the USB communications. It accepts an adimensional control signal in the range from -100 (being the minimum steer angle) to 100 (being the maximum steer angle) and generates the commands accepted by the Arduino board.

4. The *iri_model_car_control* generates the control signals given the desired angular speed in rad/s and forward speed in m/s. In this case there is no actual feedback information about the current steering angle, so this node only converts input data into an steering angle and then maps it to the [-100,100] range expected by the actuators driver.

#### Calibration

Several elements in this diagram can be calibrated or tuned:

**A) Zero steering angle:**

To calibrate the zero steering angle command using the potentiometer, follow this steps:

* Locate the steer potentiometer in the front board, on its lower left corner, labeled as `Poti.Steer`.

* Place the model car on the raising platform, to avoid it from moving. Pay attention to the platform position respect to the direction wheels, so they don't collision when steering. 

* Open **a terminal on the car** and launch the model_car with:

    ```bash
    roslaunch iri_model_car_bringup bringup.launch
    ```

* Move the potentiometer in both directions and see how the front wheels steering angle changes. Adjust it until the wheels are as straight and parallel as possible.

After the zero steering angle is calibrated, it is important to pay attention to the mapping between the desired steering angle and the actual control value [-100,100] sent to the *iri_model_car_actuator_driver* ROS node.

Both the angular and forward speeds define the turn radius of the model car, and this turn radius, together with the kinematic constraints of the model car, sets the steering angle of both left and right front wheels. However, the steering angle command sent to the Arduino board controls the angle of the steering servo, but it does not coincide with the actual steering angle of the model car. Furthermore, the left and right behavior is not symmetric. The next image shows a generic mapping between steering angle and steering commands.

<img src="images/steer_mapping.png" alt="Generic mapping between steering angle and steering commands" width="683" height="442">

First of all, the whole possible range of motion of the steering servo [0,180] or [-100,100] does not translate to actual movement of the steering wheels (see the two red circle points in the previous image). To find out the actual valid range of motion, once the zero steering angle has been calibrated, follow the next steps: (if the zero steering angle calibration changes this process will have to be repeated).

**B) Get max and min command values and calculate the max and min steering angle:**

The objetive of this procedure is to know the steering command limits. These limits will be the smaller (in absolute value) steering command that performs the curvature with the minor radius. With this radius, the max and min steering angle can be calculated:

* Place the model car on the floor. Place some marks (with electrical tape for example) to know the starting car position (red mark in the next image). Also mark a perpendicular line to the car on the turn direction (black line in the next image).

<img src="images/turn_radius_exp.png" alt="Experiment to find out the maximum and minimum steering angles">

* Make sure that **model_car bringup** is not running.

* Open **a terminal on the car** and use the following command to send motion commands to the model car (both commands are in the range of [-100,100]). Speed commands under 6-8 will not actually move the model car, and above 20 will move it too fast. Because the car is mostly going to move forward, use just positive values. Place a mark (blue mark in the previous image) when the car crosses the perpendicular line to measure the turning diameter:

    ```bash
    model_car_actuators_test <speed command> <steer command>
    ```

* Send different increasing (in absolute value) steering commands until finding wich one correspond with the steering limit. That means, the highest steering command (in absolute value) that produces a noticeable change in the turn radius of the car (see the two red circle points in the steer mapping image). These positive and negative limits define the maximum range of valid commands that can be sent to the platform. Changes in the speed command have a slight effect on the actual turn radius so it is recommended to test different speed values inside the valid range to get an averaged value.

* Measure the radius of the circumference described by the model car, from the midpoint between the two rear wheels. The distance between the external side of the wheels is 30cm. 

* Use the following formula to get the steering angle where *D* is the axel distance (36,62cm) and *R* is the radius of the circumference described:

<img src="images/steering_angle.png" alt="Steering angle formula">

Once calculated, the following parameters from [iri_model_car_control](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_control) and [iri_model_car_odometry](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_odometry) can be modified:
* max_steer_angle
* min_steer_angle
* max_steer_control
* min_steer_control

**C) EXTRA: Improve the iri_model_car_control steering commands' mapping:**

Using differents steering commands between the limits will make the car describe different turnning circumferences. You can measure the different radius for each steering command. With this data you can define a better mapping (not linear for example) between turning angles and steering commands. Follow the previous procedure with different steering commands to calculate that.

