# Car computer
## Description
The system is an Ubuntu 18.04 with:
* A default user `adc` with password `adc2021` and root permissions.
* All the necessary drivers for the car components.
* ROS Melodic: There are two wokspaces created on the home directory: 
  * **model_car_ws** where there are all the basic nodes to start up the car. This wokspace is intended to be updated and upgraded by IRI development team. This workspace is not intended to be modified by the user.
  * **user_ws** intended to be used by the user to create his own packages. If there is a package with the same name on both workspaces the one on this workspace will be used; So any desired modification on a basic driver node should be done here on a copy of the original package. There is an example package *iri_adc_launch* where there are some examples on how to start up the car with a different configuration. Any modification on the car drivers parameters should be done on this package.
* NVIDIA drivers 460, CUDA toolkit 10.0 and CUDNN 7.6.0: This is the necessary installation to be able to use tensorflow 2.0 with GPU enabled. It's not mandatory to use this configuration, it's just a default installation.
* Some useful programs like:
  * vim: A program to edit files from a terminal.
  * byobu: To open multiples terminals on the remote machine, in this case the car, with just an ssh connection. In case of a lost connection, runninng another time byobu will open the terminals already opened.
  * v4l-utils: Useful to know on which formats, frame rates and resolutions the camera will work.
* A default NTP configuration te act as a time server.

## Installation using an ISO image and clonezilla

**1. Create a Clonezilla live USB:**

Follow the instructions on this [Clonezilla tutorial](https://clonezilla.org/liveusb.php#linux-method-a).

**2. Create a USB pendrive with the car image:**

There are two options:

**a) Save our iri default car image on an USB pendrive**

[Download our car image](https://drive.google.com/file/d/1LsPkqCzm6apt3jd0ZbWV-oHrow_dFYGW/view?usp=sharing) and plug an USB pendrive of at least 8GB. Check where is mounted with **Disks**: Press Windows key and type disks to launch it. Select the target pendrive and read from **Device** field where is mounted. It should be something similar to */dev/sdc1*, in this case the pendrive will be mounted on */dev/sdc*. Execute the following command to copy the image on the USB pendrive:
```bash
sudo dd if=<adc_img_path> of=<mounted_pendrive>
```
An example command will be:
```bash
sudo dd if=~/Downloads/adc_img.iso of=/dev/sdc
```
It will take a long time (+60 min) without any message on screen. Be patient and wait.

**b) Save the car disk image on an USB pendrive:**

Plug the Clonezilla live USB to the car. Reboot the computer, press **F12** to enter the boot menu and select the clonezilla usb to boot the car. Follow the steps on this [Clonezilla tutorial](https://clonezilla.org/show-live-doc-content.php?topic=clonezilla-live/doc/01_Save_disk_image) to save the image on another USB pendrive.

**3. Restore car disk image:**

Plug the Clonezilla live USB to the car. Reboot the computer, press **F12** to enter the boot menu and select the clonezilla usb to boot the car. Follow the steps on this [Clonezilla tutorial](https://clonezilla.org/show-live-doc-content.php?topic=clonezilla-live/doc/02_Restore_disk_image) to restore the car image.

## Manual installation

<details><summary>Click here to expand manual installation instructions</summary>
<p>


**1. Install Ubuntu:**

Download [Ubuntu 18.04 image](https://releases.ubuntu.com/18.04/) and [create a bootable USB](https://ubuntu.com/tutorials/create-a-usb-stick-on-ubuntu#1-overview) with the image. Use the USB to install Ubuntu 18.04 on the car. Use as **user name adc** and as **computer name modelcar**.

**2. Update Ubuntu:**

```bash
sudo apt update && sudo apt upgrade -y && sudo apt dist-upgrade
```

Install some basic programs:
```bash
sudo apt install -y apt-utils vim wget ca-certificates xsdcxx openssh-client openssh-server byobu v4l-utils ntp
```

Some useful personalizations:
* Unlimited terminal scrolling: Open a terminal. On *Edit -> preferences -> scrolling*, unset limit scrollback to.
* Av. pag and Re. pag to search command history: Edit */etc/inputrc*:
```bash
sudo vim /etc/inputrc
```
Uncomment the following lines:
```
"\e[5~": history-search-backward
"\e[6~": history-search-forward
```
* Change color name on terminal: Edit *~/.bashrc*:
```bash
vim ~/.bashrc
```
Uncomment the following line:
```
force_color_prompt=yes
```
Modify the following line changing [\033[01;**32**m\] to [\033[01;**31**m\]:
```
PS1='${debian_chroot:+($debian_chroot)}\[\033[01;31m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '
```

**3. Install Nvidia Drivers with CUDA:**

**3.1 Install Nvidia Drivers 460:**

Open *Software & Updates*, go to *additional drivers* tab and select **Using NVIDIA driver metapackage from nvidia-driver-460 (propietary)**. Click on *apply changes* and restart your computer.

**3.2 Install CUDA toolkit 10.0:**

[Download Cuda toolkit 10.0](https://developer.nvidia.com/cuda-10.0-download-archive) selecting *linux -> x86_64 -> Ubuntu -> 18.04 -> runfile(local) -> Base installer -> Download [2.0 GB]*. 

Install it and follow the command line promps:

```bash
sudo sh ~/Downloads/cuda_10.0.130_410.48_linux.run
```
* Press space until all the license agreement has been displayed. **Accept** it.
* Choose **(n)o** when asked to Install NVIDIA Accelerated Graphics Driver for Linux-x86_64 410.48
* Install CUDA 10.0 toolkit, at default location, with the symbolic link and with Samples at default location.
* Ignore the incomplete installation warning message.

Add CUDA to *PATH* and *LD_LIBRARY_PATH*
```bash
echo "PATH=$PATH:/usr/local/cuda-10.0/bin" >> $HOME/.bashrc
echo "LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda-10.0/lib64" >> $HOME/.bashrc
source ~/.bashrc
```

Check that cuda is working. The result of both test must be **PASS**:
```bash
 cd ~/NVIDIA_CUDA-10.0_Samples/1_Utilities/deviceQuery
 make
 ./deviceQuery
 ``` 
 ```bash
 cd ~/NVIDIA_CUDA-10.0_Samples/1_Utilities/bandwidthTest/
 make
 ./bandwidthTest
```

**3.3 Install CUDNN 7.6.0:**

* Register at Nvidia and join the Nvidia Developer Program: [https://developer.nvidia.com/developer-program](https://developer.nvidia.com/developer-program)
* Download CUDNN files
    * Login to be able to access [CUDNN download page](https://developer.nvidia.com/cudnn)
    * Go to `Archived cuDNN Releases` for previous releases.
    * Find version `cuDNN v7.6.0 (May 20, 2019), for CUDA 10.0`
    * Download the 3 deb files for Ubuntu 18.04
        * cuDNN Runtime Library for Ubuntu18.04 (Deb) [158.7 MB]
        * cuDNN Developer Library for Ubuntu18.04 (Deb) [145.4 MB]
        * cuDNN Code Samples and User Guide for Ubuntu18.04 (Deb) [5.3 MB]
* Install them:
    ```bash
    cd ~/Downloads
    sudo dpkg -i libcudnn7_7.6.0.64-1+cuda10.0_amd64.deb
    sudo dpkg -i libcudnn7-dev_7.6.0.64-1+cuda10.0_amd64.deb
    sudo dpkg -i libcudnn7-doc_7.6.0.64-1+cuda10.0_amd64.deb
    ```

**4. Install ROS Melodic:**

Follow the instructions on this [ROS tutorial](http://wiki.ros.org/melodic/Installation/Ubuntu) to install **ros-melodic-desktop-full**. Make sure to follow step 1.5 and 1.6.

**4.1 (Optional) How to fix error when fetching libgazebo9**

It is posible that, when installing ros-melodic-desktop-full, the following error can appear:

```
E: Failed to fetch <libgazebo9_url>  Connection failed [IP: <ip_number>]
```

To solve it, copy the url and paste it on your browser. After a while, you can download the .deb file required. Download it and copy it on **/var/cache/apt/archives**. After that you con re run the installation.

**4.2 Install some useful ROS packages**
```bash
sudo apt install -y ros-melodic-ar-track-alvar
```

**5. Install IRI Software**

**5.1 Add IRI repository and install IRI dependency libraries:**
```bash
sudo sh -c 'echo "deb [arch=amd64] https://labrepo.iri.upc.edu/packages $(lsb_release -cs) main" > /etc/apt/sources.list.d/labrobotica_repo.list'
wget -q -O - https://labrepo.iri.upc.edu/labrobotica_repo.gpg.key | sudo apt-key add -
sudo apt update 
sudo apt install -y iri-opendrive-road-map-dev iri-autonomous-driving-tools-dev iri-model-car-drivers-dev
```
**5.2 Create a ROS workspace, download IRI packages, install dependencies and install IRI packages:**
```bash
cd
mkdir -p model_car_ws/src
mkdir -p model_car_ws/rosinstall
cd model_car_ws/rosinstall
wget -q https://gitlab.iri.upc.edu/labrobotica/ros/iri_ros_how_to/-/raw/melodic_migration/rosinstall/iri_core.rosinstall
wget -q https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/raw/master/rosinstall/iri_model_car_common.rosinstall
wget -q https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to/-/raw/master/rosinstall/iri_model_car.rosinstall
cd ../src
wstool init
wstool merge -y -r ../rosinstall/iri_core.rosinstall
wstool merge -y -r ../rosinstall/iri_model_car_common.rosinstall
wstool merge -y -r ../rosinstall/iri_model_car.rosinstall
wstool update -j 10
rosdep install -q -y -i -r --from-paths .
source /opt/ros/melodic/setup.bash
cd ..
catkin_make
```
**5.3 Add workspace source to *~/.bashrc*:**
```bash
echo "source ~/model_car_ws/devel/setup.bash" >> $HOME/.bashrc
source ~/.bashrc
```

**6. Install Pylon basler camera software**

These steps are a mix from [this pdf](https://www.baslerweb.com/fp-1591878203/media/downloads/documents/application_notes/AW00149103000_Interfacing_Basler_Cameras_with_ROS~1.pdf) and [this installation instructions](https://github.com/basler/pylon-ros-camera#for-the-impatient)

**6.1 Install pylon 6.1.1**

Donwload from [basler donwload page](https://www.baslerweb.com/en/sales-support/downloads/software-downloads/#version=6.1.1) pylon 6.1.1 Camera Software Suite for Linux.

Install it:
```bash
sudo dpkg -i <pylon_deb_file>
```

Set PYLON_ROOT enviroment variable:
```bash
source /opt/pylon/bin/pylon-setup-env.sh /opt/pylon
source ~/.bashrc
```

It is necessary a **logout** for changes to take effect.

**6.2 Install pylon-ROS-camera**
```bash
cd ~/model_car_ws/src/
mkdir external
cd external/
git clone https://github.com/basler/pylon-ros-camera
git clone https://github.com/dragandbot/dragandbot_common.git
sudo sh -c 'echo "yaml https://raw.githubusercontent.com/basler/pylon-ros-camera/master/pylon_camera/rosdep/pylon_sdk.yaml" > /etc/ros/rosdep/sources.list.d/30-pylon_camera.list' && rosdep update && sudo rosdep install --from-paths . --ignore-src --rosdistro=$ROS_DISTRO -y
cd ~/model_car_ws/
catkin_make
```

**6.3 Configure basler camera**
```bash
rosrun pylon_camera write_device_user_id_to_camera basler
```

**7. Add rear camera udev rule**

Create a new udev rule *99-uvc.rules* on */etc/udev/rules.d/*
```bash
sudo vim /etc/udev/rules.d/99-uvc.rules
```

Paste the following lines:
```
# UVC cameras
#SUBSYSTEMS=="usb", ENV{DEVTYPE}=="usb_device", ATTRS{idVendor}=="046d", ATTRS{idProduct}=="0825", MODE="0666"
#For all Logitech cameras
SUBSYSTEMS=="usb", ATTRS{idVendor}=="046d", MODE="0666"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="090c", ATTRS{idProduct}=="f37d", MODE="0666", GROUP="plugdev"
```
**Unplug and plug the camera** for changes to take efect.

**8. Create a user workspace with a default iri_adc_launch package**
```bash
cd
mkdir -p user_ws/src/adc
cd user_ws/src/adc
git clone https://gitlab.iri.upc.edu/mobile_robotics/adc/adc_2021/iri_adc_launch.git
cd ~/user_ws
source /opt/ros/melodic/setup.bash
source ~/model_car_ws/devel/setup.bash
catkin_make
echo "source ~/user_ws/devel/setup.bash" >> $HOME/.bashrc
source ~/.bashrc
```

**9. Setup NTP server**

Edit */etc/ntp.conf* and paste at the end of the file the following lines:
```
# Allow LAN machines to synchronize with this ntp server
restrict 192.168.1.0 mask 255.255.255.0 nomodify notrap

server 127.127.1.0
fudge 127.127.1.0 stratum 10
```

</p>
</details>

# Development computer

Follow the steps on [Enviorment Setup -> Manual installation](https://gitlab.iri.upc.edu/mobile_robotics/adc/adc_2021/iri_adc_simulation_workshop/-/blob/master/doc/setup.md#or-manual-installation) to setup a development computer capable to compile and test your ROS nodes on the simulator.

It also can be useful to configurate this computer as a time client of the car. To configure it, first install ntp:
```bash
sudo apt update && sudo apt upgrade -y && sudo apt dist-upgrade
sudo apt install ntp
```
Then add the car as a time server and comment ubuntu default time servers: Edit */etc/ntp.conf* and modify the lines with the default Ubuntu time server as here:
```
# Use servers from the NTP Pool Project. Approved by Ubuntu Technical Board
# on 2011-02-08 (LP: #104525). See http://www.pool.ntp.org/join.html for
# more information.
server <ip address of the model car> iburst
# pool 0.ubuntu.pool.ntp.org iburst
# pool 1.ubuntu.pool.ntp.org iburst
# pool 2.ubuntu.pool.ntp.org iburst
# pool 3.ubuntu.pool.ntp.org iburst
```

# Check that all is ok

On a fisrt terminal:
```bash
roslaunch iri_adc_launch adc_bringup.launch
```
On other terminal:
```bash
rosrun rviz rviz -d `rospack find iri_adc_launch`/rviz/adc_car.rviz
```
On other terminal:
```bash
roslaunch iri_adc_launch adc_teleop_rqt.launch
```
