# Description

This ROS package contains the simulation worlds and the main launch and configuration files for the simulated model car.

The [iri_model_car_control](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_control) ROS package is used to generate the speed and steering commands, and the [iri_model_car_odometry](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_odometry) ROS package is used to generate the odometry information, as it is done with the real robot. See the documentation on these packages for more details.

# Dependencies

This node has the following dependencies:

* [iri_model_car_controller](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/simualtor/iri_model_car_controller): gazebo plugin to control the simulated car.
* [iri_model_car_description](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_description): physical description of the model car.
* [iri_model_car_control](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_control): ROS package to generate the speed and steering motion commands from the standard ROS Twist message.
* [iri_model_car_odometry](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_odometry): ROS package to convert the encoder information to a ROS odometry message
* [iri_model_car_msgs](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_msgs): Set of specific ROS messages for the model car.

# How to use it

## Installation

This package is part of the simulation framework for the model car. Follow the instructions in the [iri_model_car_how_to](https://gitlab.iri.upc.edu/mobile_robotics/adc/simulator/iri_model_car_how_to) to set it up.

## Launch
This package provides two launch file: *spawn_car.launch* and *world.launch*.

The *world.launch* launches the gazebo simulator with a given world description. The parameters provided by this launch file are:

* **world** (default=empty): the name of the world to be used in the Gazebo simulation. No world is provided by default. Instead take a look at the [road_description](https://gitlab.iri.upc.edu/mobile_robotics/adc/adc_2021/iri_road_description) and [sign_description](https://gitlab.iri.upc.edu/mobile_robotics/adc/adc_2021/iri_sign_description) packages.
* **gui** (default=tue): sets whether the Gazebo client must be launched or not.

To include the world into an other launch file, include the following lines:
```
  <include file="$(find iri_model_car_gazebo)/launch/world.launch">
    <arg name="world" value="$(arg world)"/>
    <arg name="gui"   value="$(arg gazebo_gui)"/>
  </include>
```

The *spawn_car.launch* spawns the car model into the gazebo simulation. The parameters provided by this launch file are:

* **name** (default=model_car): name of the car used as a namespace to include everything inside it.
* **sim_config_path** (default=iri_model_car_gazebo/config): path where the simulation sensor configuration files for all sensors are located.
* **car_controller_config_file** (default=iri_model_car_controller/config/control.yaml): file with the gazebo controller configuration. See this [section](#configuration) for more information on the configuration file.
* **x** (default=0.0): initial x position (in meters) of the car in the simulated environment with respect to the world frame.
* **y** (default=0.0): initial y position (in meters) of the car in the simulated environment with respect to the world frame.
* **yaw** (default=0.0): initial heading (in radians) of the car in the simulated environment with respect to the world frame. 

To spawn a car into gazebo in an other launch file, include the following lines:
```
  <include file="$(find iri_model_car_gazebo)/launch/spawn_car.launch">
    <arg name="name"                       value="$(arg name)"/>
    <arg name="sim_config_path"            value="$(arg sim_config_path)"/>
    <arg name="car_controller_config_file" value="$(arg car_controller_config_file)"/>
    <arg name="x"                          value="$(arg car_x)"/>
    <arg name="y"                          value="$(arg car_y)"/>
    <arg name="yaw"                        value="$(arg car_yaw)"/>
  </include>
```

Two example launch files are provided for simplicity to launch both files at the same time for a single car (*sim.launch*) and for two cars (*sim_2_cars.launch*). Launch the RVIZ application to show the output of all sensors with the following command:

```
rosrun rviz rviz -d `rospack find iri_model_car_launch`/rviz/model_car.rviz
```

or

```
rosrun rviz rviz -d `rospack find iri_model_car_gazebo`/rviz/sim_2_cars.rviz
```

## Configuration

Each of the sensors available on the model car has a simulation configuration file associated to them. These files allow the user to easily set all the gazebo plug-in parameters associated to the sensor without having to modify the actual robot description file. Some of the parameters that can be set include:

* Sensor publication rate
* Size of the published images (for camera sensors)
* Name and namespace of the output topics

A set of default configuration files is provided in this package (*config* folder), but the user is encouraged to create a new set of configuration files for each new application where the model car simulation model is used, using the ones provided as a template.

# Disclaimer

Copyright (C) Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
Mantainer IRI labrobotics (labrobotica@iri.upc.edu)

This package is distributed in the hope that it will be useful, but without any warranty. It is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. should the program prove defective, the GMR group does not assume the cost of any necessary servicing, repair  or correction.

In no event unless required by applicable law the author will be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs), even if the author has been advised of the possibility of such damages.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>

