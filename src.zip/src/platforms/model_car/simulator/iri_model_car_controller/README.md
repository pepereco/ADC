# Description

This package is a Gazebo plugin to control the model car in simulation and provides the same interface as the real model car.

This controller is intended to be used with models with four independent traction joints (drive_rear_left_joint, drive_rear_right_joint, drive_front_left_joint and drive_front_right_joint) and two independent steering joints (steer_left_joint and steer_right_joint). The actual speed or position of each joint is internally computed to make it behave like a real car.

It has been designed to be used with the [iri_model_car_description](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_description), however it may be used with other car description packages that comply with the joint definition, because the physical parameters of the car can be configured. See the [configuration](#configuration) section for more information.

## ROS interface

### Published topics

* **~/encoders** (iri_model_car_msgs/encoders.msg): Information from the simulated left and right encoders.

### Subscribed topics

* **~/control** (ackermann_msgs/AckermannDrive.msg): desired steering and translational speed values. The only parameters used at the moment are the steering angle and the speed. Both these values are defined in the range [-100,100] and have no physical magnitude.

# How to use it

## Installation

This package is part of the simulation framework for the model car. Follow the instructions in the [iri_model_car_how_to](https://gitlab.iri.upc.edu/mobile_robotics/adc/simulator/iri_model_car_how_to) to set it up.

## Launch

This package file include a launch file named *control.launch* which is intended to be included from other launch file that require the model car gazebo plugin. This launch file has two parameters:

* **name** (default=model_car): name of the car used as a namespace to include everything inside it.
* **car_controller_config_file** (default=iri_model_car_controller/config/control.yaml): file with the gazebo controller configuration. See this [section](#configuration) for more information on the configuration file.

To include the iri_model_car_description into an other launch file, include the following lines:
```
  <include file="$(find iri_model_car_controller)/launch/control.launch">
    <arg name="name"  value="$(arg name)"/>
    <arg name="car_controller_config_file" value="$(arg car_controller_config_file)"/>
  </include>
```

## Configuration

The model car Gazebo controller plugin can be configured using YAML file. A default file is provided in this package (*config/control.yaml*), however a new file can be provided to adapt the plugin to the user requirements.

Most of the parameters in this configuration file are directly related to the physical description of the car and must be set coincide with it. The default configuration provided in this package is set to work with the [iri_model_car_description](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_description). The parameters that can be modified to adapt the plugin to other car description packages are:

- **steer_left_joint** (String; default: base_link_2_steer_left_joint) Name of the left steering joint in the URDF model.
- **steer_right_joint** (String; default: base_link_2_steer_right_joint) Name of the right steering joint in the URDF model.
- **drive_rear_left_joint** (String; default: base_link_2_rear_left_wheel_joint) Name of the rear left driving joint in the URDF model.
- **drive_rear_right_joint** (String; default: base_link_2_rear_right_wheel_joint) Name of the rear right driving joint in the URDF model.
- **drive_front_left_joint** (String; default: steer_left_2_front_left_wheel_joint) Name of the front left driving joint in the URDF model.
- **drive_front_right_joint** (String; default: steer_right_2_front_right_wheel_joint) Name of the front right driving joint in the URDF model.
- **axel_distance** (Double; default: 0.3662) Distance between axels in meters.
- **wheel_distance** (Double; default: 0.216) Distance between wheels in meters.
- **wheel_diameter** (Double; default: 0.100) Diameter of the wheel in meters.
- **encoder_ticks** (Int; default: 60) Number of encoder ticks per revolution.
- **encoder_rate** (Double; default: 40) Desired encoder output rate in Hz.
- **min_steer_angle** (Double; default: -0.4) Minimum physical steering angle in radians.
- **max_steer_angle** (Double; default: 0.4) Maximum physical steering angle in radians.
- **min_speed** (Double; default: -1.5) Minimum forward speed in m/s.
- **max_speed** (Double; default: 1.5) Maximum forward speed in m/s.

Some other parameters can be set by the user, whatever the car description package used, to adapt the plugin to the ROS environment:

- **control_topic** (String; default: /car1/control) Name of the control input topic.
- **encoders_topic** (String; default: /car/encoders) Name of the encoder output topic.

# Disclaimer

Copyright (C) Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
Mantainer IRI labrobotics (labrobotica@iri.upc.edu)

This package is distributed in the hope that it will be useful, but without any warranty. It is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. should the program prove defective, the GMR group does not assume the cost of any necessary servicing, repair  or correction.

In no event unless required by applicable law the author will be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs), even if the author has been advised of the possibility of such damages.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>


