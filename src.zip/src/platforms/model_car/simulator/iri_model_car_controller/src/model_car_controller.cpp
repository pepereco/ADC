#include "model_car_controller.h"
#include <limits>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <tf/tf.h>

namespace iri_model_car_controller
{
  namespace internal
  {
    boost::shared_ptr<urdf::Model> getUrdf(const ros::NodeHandle& nh, const std::string& param_name)
    {
      boost::shared_ptr<urdf::Model> urdf(new urdf::Model);

      std::string urdf_str;
      // Check for robot_description in proper namespace
      if(nh.getParam(param_name, urdf_str))
      {
        if(!urdf->initString(urdf_str))
        {
          ROS_ERROR_STREAM("Failed to parse URDF contained in '" << param_name << "' parameter (namespace: " <<
          nh.getNamespace() << ").");
          return boost::shared_ptr<urdf::Model>();
        }
      }
      // Check for robot_description in root
      else if (!urdf->initParam("robot_description"))
      {
        ROS_ERROR_STREAM("Failed to parse URDF contained in '" << param_name << "' parameter");
        return boost::shared_ptr<urdf::Model>();
      }
      return urdf;
    }

    typedef std::shared_ptr<const urdf::Joint> UrdfJointConstPtr;
    std::vector<UrdfJointConstPtr> getUrdfJoints(const urdf::Model& urdf, const std::vector<std::string>& joint_names)
    {
      std::vector<UrdfJointConstPtr> out;
      for (unsigned int i = 0; i < joint_names.size(); ++i)
      {
        UrdfJointConstPtr urdf_joint = urdf.getJoint(joint_names[i]);
        if (urdf_joint)
          out.push_back(urdf_joint);
        else
        {
          ROS_ERROR_STREAM("Could not find joint '" << joint_names[i] << "' in URDF model.");
          return std::vector<UrdfJointConstPtr>();
        }
      }
      return out;
    }

    std::string getNamespace(const ros::NodeHandle& nh)
    {
      const std::string complete_ns = nh.getNamespace();
      std::size_t id   = complete_ns.find_last_of("/");
      return complete_ns.substr(id + 1);
    }

  } // namespace

  inline void ModelCarController::starting(const ros::Time& time)
  {
    // Reset PIDs, zero effort commands
    for (unsigned int i = 0; i < this->pids_.size(); ++i)
    {
      this->pids_[i]->reset();
      this->joints_[i].setCommand(0.0);
    }
    this->front_left_cmd=0;
    this->front_right_cmd=0;
    this->rear_left_cmd=0;
    this->rear_right_cmd=0;

    ::srand(::time(NULL));
  }

  inline void ModelCarController::stopping(const ros::Time& time)
  {
  }

  ModelCarController::ModelCarController()
  {
  }

  bool ModelCarController::init(hardware_interface::EffortJointInterface* hw,ros::NodeHandle&   root_nh,ros::NodeHandle&   controller_nh)
  {
    std::string joint_name;
    double encoder_rate;

    // Cache controller node handle
    this->controller_nh_ = controller_nh;
    // Controller name
    this->name_ = internal::getNamespace(this->controller_nh_);

    // get the joint names
    this->joint_names_.clear();
    joint_name="";
    controller_nh_.getParam("steer_left_joint", joint_name);
    if(joint_name=="")
    {
      ROS_ERROR_STREAM_NAMED(name_, "steer_left_joint not defined");
      return false;
    }
    else
      this->joint_names_.push_back(joint_name);
    joint_name="";
    controller_nh_.getParam("steer_right_joint", joint_name);
    if(joint_name=="")
    {
      ROS_ERROR_STREAM_NAMED(name_, "steer_right_joint not defined");
      return false;
    }
    else
      this->joint_names_.push_back(joint_name);
    joint_name="";
    controller_nh_.getParam("drive_rear_left_joint", joint_name);
    if(joint_name=="")
    {
      ROS_ERROR_STREAM_NAMED(name_, "drive_rear_left_joint not defined");
      return false;
    }
    else
      this->joint_names_.push_back(joint_name);
    joint_name="";
    controller_nh_.getParam("drive_rear_right_joint", joint_name);
    if(joint_name=="")
    {
      ROS_ERROR_STREAM_NAMED(name_, "drive_right_joint not defined");
      return false;
    }
    else
      this->joint_names_.push_back(joint_name);
    joint_name="";
    controller_nh_.getParam("drive_front_left_joint", joint_name);
    if(joint_name=="")
    {
      ROS_ERROR_STREAM_NAMED(name_, "drive_front_left_joint not defined");
      return false;
    }
    else
      this->joint_names_.push_back(joint_name);
    joint_name="";
    controller_nh_.getParam("drive_front_right_joint", joint_name);
    if(joint_name=="")
    {
      ROS_ERROR_STREAM_NAMED(name_, "drive_front_right_joint not defined");
      return false;
    }
    else
      this->joint_names_.push_back(joint_name);

    const unsigned int n_joints = joint_names_.size();
    // get the joints from the urdf file
    boost::shared_ptr<urdf::Model> urdf = internal::getUrdf(root_nh, "robot_description");
    if (!urdf)
    {
      ROS_ERROR_STREAM_NAMED(name_, "No robot description found");
      return false;
    }
    std::vector<internal::UrdfJointConstPtr> urdf_joints = internal::getUrdfJoints(*urdf, this->joint_names_);
    if (urdf_joints.empty())
    {
      ROS_ERROR_STREAM_NAMED(name_, "Desired joint not found in the robot model");
      return false;
    }
    // Initialize the joints
    this->joints_.resize(n_joints);
    this->pids_.resize(n_joints);
    for (unsigned int i = 0; i < n_joints; ++i)
    {
      // Joint handle
      try {
        this->joints_[i] = hw->getHandle(this->joint_names_[i]);
          
        // Node handle to PID gains
        ros::NodeHandle joint_nh(controller_nh_, std::string("gains/") + this->joints_[i].getName());
        // Init PID gains from ROS parameter server
        this->pids_[i].reset(new control_toolbox::Pid());
        if (!this->pids_[i]->init(joint_nh))
        {
          ROS_WARN_STREAM("Failed to initialize PID gains from ROS parameter server.");
          return false;
        }
      }catch (...){
        ROS_ERROR_STREAM_NAMED(name_, "Could not find joint '" << this->joint_names_[i] << "' in '" <<
        this->getHardwareInterfaceType() << "'.");
        return false;
      }
    }
    // get the car parameters
    this->axel_distance=0.26;
    controller_nh_.getParam("axel_distance", this->axel_distance);
    ROS_DEBUG_STREAM_NAMED(name_, "Axel distance set to: " << this->axel_distance);

    this->wheel_distance=0.165;
    controller_nh_.getParam("wheel_distance", this->wheel_distance);
    ROS_DEBUG_STREAM_NAMED(name_, "Wheel distance set to: " << this->wheel_distance);

    this->wheel_diameter=0.063;
    controller_nh_.getParam("wheel_diameter", this->wheel_diameter);
    ROS_DEBUG_STREAM_NAMED(name_, "Wheel diameter set to: " << this->wheel_diameter);

    this->encoder_ticks=60;
    controller_nh_.getParam("encoder_ticks", this->encoder_ticks);
    ROS_DEBUG_STREAM_NAMED(name_, "Encoder ticks set to: " << this->encoder_ticks);

    encoder_rate=40;
    controller_nh_.getParam("encoder_rate", encoder_rate);
    ROS_DEBUG_STREAM_NAMED(name_, "Encoder rate set to: " << encoder_rate);
    this->encoder_time=1.0/encoder_rate;

    this->control_topic="/control";
    controller_nh_.getParam("control_topic", this->control_topic);
    ROS_DEBUG_STREAM_NAMED(name_, "Control topic set to: " << this->control_topic);

    this->encoders_topic="/encoders";
    controller_nh_.getParam("encoders_topic", this->encoders_topic);
    ROS_DEBUG_STREAM_NAMED(name_, "Encoders topic set to: " << this->encoders_topic);

    this->min_steer_angle=-0.4;
    controller_nh_.getParam("min_steer_angle",this->min_steer_angle);
    ROS_DEBUG_STREAM_NAMED(name_, "Minimum steer angle set to: " << this->min_steer_angle);
    
    this->max_steer_angle=0.4;
    controller_nh_.getParam("max_steer_angle",this->max_steer_angle);
    ROS_DEBUG_STREAM_NAMED(name_, "Maximum steer angle set to: " << this->max_steer_angle);

    this->min_steer_control=-100.0;
    controller_nh_.getParam("min_steer_control",this->min_steer_control);
    ROS_DEBUG_STREAM_NAMED(name_, "Minimum steer control set to: " << this->min_steer_control);
    
    this->max_steer_control=100.0;
    controller_nh_.getParam("max_steer_control",this->max_steer_control);
    ROS_DEBUG_STREAM_NAMED(name_, "Maximum steer control set to: " << this->max_steer_control);
    
    this->min_speed=-0.5;
    controller_nh_.getParam("min_speed",this->min_speed);
    ROS_DEBUG_STREAM_NAMED(name_, "Minimum speed set to: " << this->min_speed);
    
    this->max_speed=0.5;
    controller_nh_.getParam("max_speed",this->max_speed);
    ROS_DEBUG_STREAM_NAMED(name_, "Maximum speed set to: " << this->max_speed);

    this->min_speed_control=-20.0;
    controller_nh_.getParam("min_speed_control",this->min_speed_control);
    ROS_DEBUG_STREAM_NAMED(name_, "Minimum speed control set to: " << this->min_speed_control);
    
    this->max_speed_control=20.0;
    controller_nh_.getParam("max_speed_control",this->max_speed_control);
    ROS_DEBUG_STREAM_NAMED(name_, "Maximum speed control set to: " << this->max_speed_control);
   
    // ros communications
    this->control_sub = root_nh.subscribe(this->control_topic, 1, &ModelCarController::control_callback,this);

    this->encoders_pub = root_nh.advertise<iri_model_car_msgs::encoders>(this->encoders_topic,1);

    ROS_DEBUG_STREAM_NAMED(name_, "Initialized controller '" << name_ << "' with:" <<
    "\n- Number of joints: " << joints_.size() <<
    "\n- Hardware interface type: '" << this->getHardwareInterfaceType() << "'");

    this->last_cmd_drive=0.0;
    this->last_cmd_steer=0.0;
    this->current_steer_angle=0.0;
    this->last_left_encoder=0;
    this->last_right_encoder=0;

    return true;
  }

  void ModelCarController::update(const ros::Time& time, const ros::Duration& period)
  {
    double error,command,cotan_steer;
    double steer_l_pos,steer_r_pos,drive_r_l_pos,drive_r_r_pos,drive_f_l_pos,drive_f_r_pos;
    double steer_l_vel,steer_r_vel,drive_r_l_vel,drive_r_r_vel,drive_f_l_vel,drive_f_r_vel;
    double new_left_encoder,new_right_encoder;
    static double encoder_time_left=this->encoder_time,total_left_ticks=0.0,total_right_ticks=0.0;

    steer_l_pos=this->joints_[0].getPosition();
    steer_r_pos=this->joints_[1].getPosition();
    drive_r_l_pos=this->joints_[2].getPosition();
    drive_r_r_pos=this->joints_[3].getPosition();
    drive_f_l_pos=this->joints_[4].getPosition();
    drive_f_r_pos=this->joints_[5].getPosition();
    steer_l_vel=this->joints_[0].getVelocity();
    steer_r_vel=this->joints_[1].getVelocity();
    drive_r_l_vel=this->joints_[2].getVelocity();
    drive_r_r_vel=this->joints_[3].getVelocity();
    drive_f_l_vel=this->joints_[4].getVelocity();
    drive_f_r_vel=this->joints_[5].getVelocity();

    // Update PIDs and send command to the motors
    error=this->front_left_cmd-steer_l_pos;
    command=pids_[0]->computeCommand(error,period);
    this->joints_[0].setCommand(command);
    ROS_DEBUG_STREAM("target left steering: " << this->front_left_cmd << " current left steering: " << steer_l_pos << " command: " << command);
    error=this->front_right_cmd-steer_r_pos;
    command=pids_[1]->computeCommand(error,period);
    this->joints_[1].setCommand(command);
    ROS_DEBUG_STREAM("target right steering: " << this->front_right_cmd << " current right steering: " << steer_r_pos << " command: " << command);

    cotan_steer=(1/tan(steer_l_pos)+1/tan(steer_r_pos))/2;
    this->current_steer_angle=atan2(1.0,cotan_steer);
    if(this->current_steer_angle>(3.14159/2.0))
      this->current_steer_angle-=3.14159;
    else if(this->current_steer_angle<-(3.14159/2.0))
      this->current_steer_angle+=3.14159;
    ROS_DEBUG_STREAM("Current steer angle: " << this->current_steer_angle);

    error=this->rear_left_cmd-drive_r_l_vel;
    command=pids_[2]->computeCommand(error,period);
    this->joints_[2].setCommand(command);
    ROS_DEBUG_STREAM("target rear left speed: " << this->rear_left_cmd << " current rear left speed: " << drive_r_l_vel << " command: " << command);
    error=this->rear_right_cmd-drive_r_r_vel;
    command=pids_[3]->computeCommand(error,period);
    this->joints_[3].setCommand(command);
    ROS_DEBUG_STREAM("target rear right speed: " << this->rear_right_cmd << " current rear right speed: " << drive_r_r_vel << " command: " << command);
    error=this->rear_left_cmd-drive_f_l_vel;
    command=pids_[4]->computeCommand(error,period);
    this->joints_[4].setCommand(command);
    ROS_DEBUG_STREAM("target front left speed: " << this->rear_left_cmd << " current front left speed: " << drive_f_l_vel << " command: " << command);
    error=this->rear_right_cmd-drive_f_r_vel;
    command=pids_[5]->computeCommand(error,period);
    this->joints_[5].setCommand(command);
    ROS_DEBUG_STREAM("target front right speed: " << this->rear_right_cmd << " current front right speed: " << drive_f_r_vel << " command: " << command);

    encoder_time_left-=period.toSec();
    if(encoder_time_left<0.0)
    {
      this->encoder_data.header.stamp=ros::Time::now();
      new_left_encoder=drive_r_l_pos*this->encoder_ticks/(2.0*3.14159);
      total_left_ticks+=abs(new_left_encoder-this->last_left_encoder);
      this->encoder_data.left_ticks=(int)total_left_ticks;
      if(this->last_left_encoder<new_left_encoder)
        this->encoder_data.left_forward=true;
      else
        this->encoder_data.left_forward=false;
      new_right_encoder=drive_r_r_pos*this->encoder_ticks/(2.0*3.14159);
      total_right_ticks+=abs(new_right_encoder-this->last_right_encoder);
      this->encoder_data.right_ticks=(int)total_right_ticks;
      if(this->last_right_encoder<new_right_encoder)
        this->encoder_data.right_forward=true;
      else
        this->encoder_data.right_forward=false;
     
      this->last_left_encoder=new_left_encoder; 
      this->last_right_encoder=new_right_encoder; 
      encoder_time_left=this->encoder_time;
      this->encoders_pub.publish(this->encoder_data);
    }
  }

  void ModelCarController::control_callback(const ackermann_msgs::AckermannDriveStamped::ConstPtr& msg)
  {
    double radius,steer_angle,speed;

    // input is defined in the range [-100.0,100.0] for both speed and steering
    // saturate the input
    if(msg->drive.steering_angle>this->max_steer_control)
      steer_angle=this->max_steer_control;
    else if(msg->drive.steering_angle<this->min_steer_control)
      steer_angle=this->min_steer_control;
    else 
      steer_angle=msg->drive.steering_angle;

    if(msg->drive.speed>this->max_speed_control)
      speed=this->max_speed_control;
    else if(msg->drive.speed<this->min_speed_control)
      speed=this->min_speed_control;
    else
      speed=msg->drive.speed;

    // convert the inputs to actual physical units
    if(speed>=0.0)
      speed*=this->max_speed/this->max_speed_control;
    else
      speed*=this->min_speed/this->min_speed_control;

    if(steer_angle>=0.0)
      steer_angle*=(this->max_steer_angle/this->max_steer_control);
    else
      steer_angle*=(this->min_steer_angle/this->min_steer_control);
    if(fabs(steer_angle)>0.001)
      radius=fabs(this->axel_distance/tan(steer_angle));
    else
      radius=std::numeric_limits<double>::max();

    if(steer_angle>0)
    {
      // right outer
      this->front_right_cmd=atan2(this->axel_distance,radius+this->wheel_distance/2.0);
      this->rear_right_cmd=(speed*((radius+this->wheel_distance/2.0)/(radius*this->wheel_diameter/2.0)));
      // left inner
      this->front_left_cmd=atan2(this->axel_distance,radius-this->wheel_distance/2.0);
      this->rear_left_cmd=(speed*((radius-this->wheel_distance/2.0)/(radius*this->wheel_diameter/2.0)));
    }
    else
    {
      // right inner
      this->front_right_cmd=-atan2(this->axel_distance,radius-this->wheel_distance/2.0);
      this->rear_right_cmd=(speed*((radius-this->wheel_distance/2.0)/(radius*this->wheel_diameter/2.0)));
      // left outer
      this->front_left_cmd=-atan2(this->axel_distance,radius+this->wheel_distance/2.0);
      this->rear_left_cmd=(speed*((radius+this->wheel_distance/2.0)/(radius*this->wheel_diameter/2.0)));
    }

    this->last_cmd_steer=steer_angle;
    this->last_cmd_drive=speed;
  }

} // namespace

PLUGINLIB_EXPORT_CLASS(iri_model_car_controller::ModelCarController, controller_interface::ControllerBase)

