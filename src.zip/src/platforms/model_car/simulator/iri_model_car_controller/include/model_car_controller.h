#ifndef MODEL_CAR_CONTROLLER_H
#define MODEL_CAR_CONTROLLER_H

// C++ standard
#include <cassert>
#include <iterator>
#include <stdexcept>
#include <string>

// Boost
#include <boost/shared_ptr.hpp>
#include <boost/scoped_ptr.hpp>

// ROS
#include <ros/node_handle.h>
#include <ackermann_msgs/AckermannDriveStamped.h>
#include <iri_model_car_msgs/encoders.h>
#include <pluginlib/class_list_macros.h>

// URDF
#include <urdf/model.h>

// ros_controls
#include <controller_interface/controller.h>
#include <control_toolbox/pid.h>
#include <hardware_interface/joint_command_interface.h>

namespace iri_model_car_controller
{
  /**
   * \brief 
   *
   */
  class ModelCarController : public controller_interface::Controller<hardware_interface::EffortJointInterface>
  {
    public:
      ModelCarController();
      // public interface inherited from Controller
      using controller_interface::Controller<hardware_interface::EffortJointInterface>::init;
      bool init(hardware_interface::EffortJointInterface* hw, ros::NodeHandle& root_nh, ros::NodeHandle& controller_nh);
      // public interface inherited from ControllerBase 
      void starting(const ros::Time& time);
      void stopping(const ros::Time& time);
      void update(const ros::Time& time, const ros::Duration& period);

    private:
      // action subscriber
      ros::Subscriber control_sub;
      void control_callback(const ackermann_msgs::AckermannDriveStamped::ConstPtr& msg);
      ros::Publisher encoders_pub;
      iri_model_car_msgs::encoders encoder_data;

      typedef typename hardware_interface::EffortJointInterface::ResourceHandleType JointHandle;

      std::string name_;///< Controller name.
      std::vector<JointHandle> joints_;///< Handles to controlled joints.
      std::vector<std::string> joint_names_;///< Controlled joint names.

      typedef boost::shared_ptr<control_toolbox::Pid> PidPtr;
      std::vector<PidPtr> pids_;

      double axel_distance;
      double wheel_distance;
      double wheel_diameter;
      int encoder_ticks;
      double encoder_time;
      std::string control_topic;
      std::string encoders_topic;
      double last_left_encoder;
      double last_right_encoder;

      double max_steer_angle;
      double min_steer_angle;
      double max_steer_control;
      double min_steer_control;
      double max_speed;
      double min_speed;
      double max_speed_control;
      double min_speed_control;

      // joint commands
      double front_left_cmd;
      double front_right_cmd;
      double rear_left_cmd;
      double rear_right_cmd;
      double last_cmd_drive;
      double last_cmd_steer;

      double current_steer_angle;

      // ROS API
      ros::NodeHandle controller_nh_;
  };

} // namespace

#endif // header guard
