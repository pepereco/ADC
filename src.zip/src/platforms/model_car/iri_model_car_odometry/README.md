## Description

This ROS package generates the odometry information from the encoder provided by the platform. The encoder message is defined in [iri_model_car_msgs](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_msgs).

Additionally, this package also generates an additional feedback information specific to Ackermannn-like platforms with information which is not available in a standard [Odometry](http://docs.ros.org/en/melodic/api/nav_msgs/html/msg/Odometry.html) message. This feedback information includes the following information as an [AckermannDriveStamped](http://docs.ros.org/en/melodic/api/ackermann_msgs/html/msg/AckermannDriveStamped.html) message:

* Forward speed (m/s)
* Steering angle (rad)
* Steering angle velocity (rad/s)

The platform does not provide actual feedback information from the steering angle and velocity, so the motion command sent to the platform is used to generate it.

Due to the low resolution of the encoders used in the platform, at low speeds, the raw encoder information is not suitable to generate accurate odometry information (the encoder count increments present isolates impulses separated by 0's), To solve that a simple first order low pass filter can be enabled. The cut-off frequency of this filter can be set by a parameter.

This package can also, optionally, publish the transform between the *odom* and *base_footprint* frames using TF.

# ROS Interface

### Topic publishers

  - ~**ackermann_feedback** (ackermann_msgs/AckermannDriveStamped.msg): specific ackermann feedback information (steering angle and velocity).
  - ~**odom** (nav_msgs/Odometry.msg): Standard odometry information with the pose and velocities estimation with covariances.
  - /**tf** (tf/tfMessage): Transform between the *odom* and *base_footprint* frames.

### Topic subscribers
  - ~**control** (ackermann_msgs/AckermannDrive.msg): motion control message sent to the platform. It is used to compute the steering angle and velocity
  - ~**encoders** (iri_model_car_msgs/encoders.msg): left and right encoder information from the platform used to estimate the pose information.

### Parameters

- ~**rate** (Double; default: 10.0; min: 0.1; max: 1000) The main node thread loop rate in Hz. 
- ~**odom_frame** (String; default: odom) Name of the odometry frame.
- ~**robot_frame** (String; default: base_footprint) Name of the robot frame.
- ~**encoder_ticks** (Integer; default: 60: min: 1; max: 1000) Number of encoder ticks per revolution.
- ~**wheel_diameter** (Double; default: 0.108; min: 0.01; max: 1000) Diameter of the wheel in meters. This parameter must coincide with the actual platform value to minimize estimation errors.
- ~**wheel_distance** (Double; default: 0.261; min: 0.01; max: 1000) Distance between wheels in meters. This parameter must coincide with the actual platform value to minimize estimation errors.
- ~**axel_distance** (Double; default: 0.3662; min: 0.01; max: 1.0) Distance between axels in meters. This parameter must coincide with the actual platform value to minimize estimation errors.
- ~**enable_filter** (Bool; default: True) Enable or disable the use of the low pass filter for the encoder data.
- ~**filter_coeff** (Double; default: 0.3; min: 0.01; max: 1.0) Coefficient for the first order low pass filter used to smooth the estimation of the forward speed.
- ~**max_steer_angle** (Double; default: 0.4; min: -1.0; max: 1.0) Maximum steering angle.
- ~**min_steer_angle** (Double; default: -0.4; min: -1.0; max: 1.0) Minimum steering angle.
- ~**max_steer_control** (Double; default: 10.0; min: -100.0; max: 100.0) Maximum output steer command value.
- ~**min_steer_control** (Double; default: -10.0; min: -100.0; max: 100.0) Minimum output steer command value.
- ~**publish_tf** (Bool; Default: True) Whether to publish the transform between *odom* and *base_footprint* frames or not.


## Dependencies
This package requires the following packages:

* [iri_model_car_msgs](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_msgs): Set of specific ROS messages for the model car.

## Installation

Move to the active workspace:
```bash
roscd && cd ../src
```

Clone the repository: 
```bash
git clone ssh://git@gitlab.iri.upc.edu:2202/mobile_robotics/adc/platform/model_car/iri_model_car_odometry.git
```

Install ROS dependencies:
```
roscd
cd ..
rosdep install -i -r --from-paths src
```

Compile the workspace:
```
catkin_make
```

## Launch

This package is normally launched as part of a more complete launch file, either in simulation or with the real robot. Check the main [model car documentation](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to) for further information.

The main launch file (*node.launch*) has the following arguments:

* **node_name** (default=model_car_odometry): name of the ROS node.
* **output** (default=screen): Desired log output. Possible values are screen and log.
* **launch_prefix** (default=): Set of parameters to be pre-apended to the node launch command.
* **config_file** (default=$(find iri_model_car_odometry)/config/params.yaml): file with the node configuration. See [the parameter section](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_odometry#parameters) for more information on the available parameters.
* **encoders_topic** (default=/encoders): Name of the encoders topic to be used.
* **odom_topic** (default=/odom): Name of the odom topic to be used
* **control_topic** (default=/control): Name of the control topic to be used. 
* **ackermann_feedback_topic** (default=/ackermann_feedback): Name of the ackermann feedback topic to be used.

To include the iri_model_car_odometry into another launch file, include the following lines:

```
  <include file="$(find iri_model_car_odometry)/launch/node.launch">
    <arg name="node_name"                  value="$(arg node_name)"/>
    <arg name="output"                     value="$(arg output)"/>
    <arg name="launch_prefix"              value="$(arg launch_prefix)"/>
    <arg name="config_file"                value="$(arg config_file)"/>
    <arg name="encoders_topic"             value="$(arg encoders_topic)"/>
    <arg name="odom_topic"                 value="$(arg odom_topic)"/>
    <arg name="control_topic"              value="$(arg control_topic)"/>
    <arg name="ackermann_feedback_topic"   value="$(arg ackermann_feedback_topic)"/>
  </include>
```

## Disclaimer

Copyright (C) Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
Mantainer IRI labrobotics (labrobotica@iri.upc.edu)

This package is distributed in the hope that it will be useful, but without any warranty. It is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. should the program prove defective, the GMR group does not assume the cost of any necessary servicing, repair  or correction.

In no event unless required by applicable law the author will be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs), even if the author has been advised of the possibility of such damages.

You should have received a copy of the GNU Lesser General Public License along with this program. If not, see <http://www.gnu.org/licenses/>
