#include "model_car_odometry_alg.h"

ModelCarOdometryAlgorithm::ModelCarOdometryAlgorithm(void)
{
  pthread_mutex_init(&this->access_,NULL);
}

ModelCarOdometryAlgorithm::~ModelCarOdometryAlgorithm(void)
{
  pthread_mutex_destroy(&this->access_);
}

void ModelCarOdometryAlgorithm::config_update(Config& config, uint32_t level)
{
  this->lock();

  // save the current configuration
  this->config_=config;
  
  this->unlock();
}

// ModelCarOdometryAlgorithm Public API
