#include "model_car_odometry_alg_node.h"

ModelCarOdometryAlgNode::ModelCarOdometryAlgNode(void) :
  algorithm_base::IriBaseAlgorithm<ModelCarOdometryAlgorithm>()
{
  //init class attributes if necessary
  if(!this->private_node_handle_.getParam("rate", this->config_.rate))
  {
    ROS_WARN("ModelCarOdometryAlgNode::ModelCarOdometryAlgNode: param 'rate' not found");
  }
  else
    this->setRate(this->config_.rate);

  // [init publishers]
  this->ackermann_feedback_publisher_ = this->private_node_handle_.advertise<ackermann_msgs::AckermannDriveStamped>("ackermann_feedback", 1);
  this->odom_publisher_ = this->private_node_handle_.advertise<nav_msgs::Odometry>("odom", 1);
  
  // [init subscribers]
  this->control_subscriber_ = this->private_node_handle_.subscribe("control", 1, &ModelCarOdometryAlgNode::control_callback, this);
  pthread_mutex_init(&this->control_mutex_,NULL);

  this->encoders_subscriber_ = this->private_node_handle_.subscribe("encoders", 1, &ModelCarOdometryAlgNode::encoders_callback, this);
  pthread_mutex_init(&this->encoders_mutex_,NULL);

  
  // [init services]
  
  // [init clients]
  
  // [init action servers]
  
  // [init action clients]
  
  this->new_encoder_data=false;
  this->fwd_direction=true;
}

ModelCarOdometryAlgNode::~ModelCarOdometryAlgNode(void)
{
  // [free dynamic memory]
  pthread_mutex_destroy(&this->control_mutex_);
  pthread_mutex_destroy(&this->encoders_mutex_);
}

void ModelCarOdometryAlgNode::mainNodeThread(void)
{
  static ros::Time last_time=ros::Time::now();
  static int last_left_encoder,last_right_encoder,dticks;
  static bool first=true;
  static double theta=0.0,x=0.0,y=0.0,last_left_speed,last_right_speed,last_steering_angle=0;
  double dt,current_left_speed,left_speed,current_right_speed,right_speed;
  double radius,left_angular_speed,right_angular_speed;
  tf2::Quaternion q;

  //lock access to algorithm if necessary
  this->alg_.lock();
  ROS_DEBUG("ModelCarOdometryAlgNode::mainNodeThread");

  if(this->new_encoder_data)
  {
    this->new_encoder_data=false;
    if(first)
    {
      first=false;
      last_left_encoder=this->encoder_data.left_ticks;
      last_right_encoder=this->encoder_data.right_ticks;
      last_time=this->odom_Odometry_msg_.header.stamp;
    }
    else
    {
      this->odom_Odometry_msg_.header.frame_id=this->config_.odom_frame;
      this->odom_Odometry_msg_.header.stamp=this->encoder_data.header.stamp;
      this->odom_Odometry_msg_.child_frame_id=this->config_.robot_frame;
      // compute the increment of time
      dt=(this->odom_Odometry_msg_.header.stamp-last_time).toSec();
      
      if(dt>0)
      {
        // compute linear speed
        dticks=this->encoder_data.left_ticks-last_left_encoder;
        if(!this->fwd_direction)
          dticks*=-1;
        current_left_speed=(dticks*3.14159*this->config_.wheel_diameter/this->config_.encoder_ticks)/dt;
        if(this->config_.enable_filter)
          left_speed=last_left_speed+this->config_.filter_coeff*(current_left_speed-last_left_speed);
        else
          left_speed=current_left_speed;
        dticks=this->encoder_data.right_ticks-last_right_encoder;
        if(!this->fwd_direction)
          dticks*=-1;
        current_right_speed=(dticks*3.14159*this->config_.wheel_diameter/this->config_.encoder_ticks)/dt;
        if(this->config_.enable_filter)
          right_speed=last_right_speed+this->config_.filter_coeff*(current_right_speed-last_right_speed); 
        else
          right_speed=current_right_speed;
        last_left_encoder=this->encoder_data.left_ticks;
        last_left_speed=left_speed;
        last_right_encoder=this->encoder_data.right_ticks;
        last_right_speed=right_speed;

        this->odom_Odometry_msg_.twist.twist.linear.x=(left_speed+right_speed)/2.0;
        this->odom_Odometry_msg_.twist.twist.linear.y=0.0;
        this->odom_Odometry_msg_.twist.twist.linear.z=0.0;
        this->odom_Odometry_msg_.twist.covariance[0]=(2*3.14159/this->config_.encoder_ticks)*(this->config_.wheel_diameter/2.0)/dt;
        this->odom_Odometry_msg_.twist.covariance[7]=(2*3.14159/this->config_.encoder_ticks)*(this->config_.wheel_diameter/2.0)/dt;

        // compute angular speed
        if(this->steering_angle==0.0)
          radius=std::numeric_limits<double>::max();
        else
          radius=fabs(this->config_.axel_distance/tan(fabs(this->steering_angle)));
        if(this->steering_angle>0)
        {
          left_angular_speed=left_speed/(radius-(this->config_.wheel_distance/2.0));
          right_angular_speed=right_speed/(radius+(this->config_.wheel_distance/2.0));
        }
        else
        {
          left_angular_speed=-left_speed/(radius+(this->config_.wheel_distance/2.0));
          right_angular_speed=-right_speed/(radius-(this->config_.wheel_distance/2.0));
        }
        this->odom_Odometry_msg_.twist.twist.angular.x=0.0;
        this->odom_Odometry_msg_.twist.twist.angular.y=0.0;
        this->odom_Odometry_msg_.twist.twist.angular.z=(left_angular_speed+right_angular_speed)/2.0;
        this->odom_Odometry_msg_.twist.covariance[35]=0.1*((2*3.14159/this->config_.encoder_ticks)*(this->config_.wheel_diameter/2.0)/dt)/(this->config_.axel_distance*0.29);

        // compute displacement
        theta+=this->odom_Odometry_msg_.twist.twist.angular.z*dt/2.0;
        x+=this->odom_Odometry_msg_.twist.twist.linear.x*cos(theta)*dt;
        y+=this->odom_Odometry_msg_.twist.twist.linear.x*sin(theta)*dt;
        this->odom_Odometry_msg_.pose.pose.position.x=x;
        this->odom_Odometry_msg_.pose.pose.position.y=y;
        this->odom_Odometry_msg_.pose.pose.position.z=0.0;
        theta+=this->odom_Odometry_msg_.twist.twist.angular.z*dt/2.0;
        q.setRPY(0.0, 0.0, theta);
        this->odom_Odometry_msg_.pose.pose.orientation=tf2::toMsg(q);
  
        this->odom_publisher_.publish(this->odom_Odometry_msg_);

        if(this->config_.publish_tf)
        {
          this->transform_msg.header.stamp = this->encoder_data.header.stamp;
          this->transform_msg.header.frame_id = this->config_.odom_frame;
          this->transform_msg.child_frame_id = this->config_.robot_frame;
          this->transform_msg.transform.translation.x = x;
          this->transform_msg.transform.translation.y = y;
          this->transform_msg.transform.translation.z = 0.0;
          this->transform_msg.transform.rotation = this->odom_Odometry_msg_.pose.pose.orientation;
          this->tf2_broadcaster.sendTransform(this->transform_msg);
        }
        // publish ackermann specific data
        this->ackermann_feedback_AckermannDriveStamped_msg_.header.stamp=this->encoder_data.header.stamp;
        this->ackermann_feedback_AckermannDriveStamped_msg_.drive.speed=this->odom_Odometry_msg_.twist.twist.linear.x;
        this->ackermann_feedback_AckermannDriveStamped_msg_.drive.acceleration=0.0;
        this->ackermann_feedback_AckermannDriveStamped_msg_.drive.jerk=0.0;
        this->ackermann_feedback_AckermannDriveStamped_msg_.drive.steering_angle=this->steering_angle;
        this->ackermann_feedback_AckermannDriveStamped_msg_.drive.steering_angle_velocity=(this->steering_angle-last_steering_angle)/dt;
        this->ackermann_feedback_publisher_.publish(this->ackermann_feedback_AckermannDriveStamped_msg_);

        last_steering_angle=this->steering_angle;
      }
      last_time=this->encoder_data.header.stamp;
    }
  }
  // [fill msg structures]

  // Initialize the topic message structure
  
  // [fill srv structure and make request to the server]
  
  // [fill action structure and make request to the action server]

  // [publish messages]
  
  this->alg_.unlock();
}

/*  [subscriber callbacks] */
void ModelCarOdometryAlgNode::control_callback(const ackermann_msgs::AckermannDriveStamped::ConstPtr& msg)
{
  ROS_DEBUG("ModelCarOdometryAlgNode::control_callback: New Message Received");

  //use appropiate mutex to shared variables if necessary
  this->alg_.lock();
  //this->control_mutex_enter();

  if(msg->drive.steering_angle>=0)
    this->steering_angle=(msg->drive.steering_angle/this->config_.max_steer_control)*this->config_.max_steer_angle;
  else
    this->steering_angle=(msg->drive.steering_angle/this->config_.min_steer_control)*this->config_.min_steer_angle;
  if(msg->drive.speed>this->config_.speed_deadband)
    this->fwd_direction=true;
  else if(msg->drive.speed<-this->config_.speed_deadband)
    this->fwd_direction=false;
  // else keep the value
  //unlock previously blocked shared variables
  this->alg_.unlock();
  //this->control_mutex_exit();
}

void ModelCarOdometryAlgNode::control_mutex_enter(void)
{
  pthread_mutex_lock(&this->control_mutex_);
}

void ModelCarOdometryAlgNode::control_mutex_exit(void)
{
  pthread_mutex_unlock(&this->control_mutex_);
}

void ModelCarOdometryAlgNode::encoders_callback(const iri_model_car_msgs::encoders::ConstPtr& msg)
{
  ROS_DEBUG("ModelCarOdometryAlgNode::encoders_callback: New Message Received");

  //use appropiate mutex to shared variables if necessary
  this->alg_.lock();
  //this->encoders_mutex_enter();

  this->new_encoder_data=true;
  this->encoder_data=*msg;
  //std::cout << msg->data << std::endl;
  //unlock previously blocked shared variables
  this->alg_.unlock();
  //this->encoders_mutex_exit();
}

void ModelCarOdometryAlgNode::encoders_mutex_enter(void)
{
  pthread_mutex_lock(&this->encoders_mutex_);
}

void ModelCarOdometryAlgNode::encoders_mutex_exit(void)
{
  pthread_mutex_unlock(&this->encoders_mutex_);
}


/*  [service callbacks] */

/*  [action callbacks] */

/*  [action requests] */

void ModelCarOdometryAlgNode::node_config_update(Config &config, uint32_t level)
{
  this->alg_.lock();
  if(config.rate!=this->getRate())
    this->setRate(config.rate);
  this->config_=config;
  this->alg_.unlock();
}

void ModelCarOdometryAlgNode::addNodeDiagnostics(void)
{
}

/* main function */
int main(int argc,char *argv[])
{
  return algorithm_base::main<ModelCarOdometryAlgNode>(argc, argv, "model_car_odometry_alg_node");
}
