# Description

This ROS package contains the physical description of a 1:8 scale model car used for the autonomous driving competitions. This description can be used either in the real model car or in the simulated model.

# How to use it

## Installation

Move to workspace:
```
roscd && cd ../src
```

Clone the repository: 
```
git clone https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_description.git
```

Install all ROS dependencies with the following commands:
```
roscd
cd ..
rosdep install -i -r --from-paths src
```

Compile all the ROS packages with the following commands:
```
catkin_make
```

## Launch

This package provides a simple launch file to display the physical description of the model car and control each of the joints using the [joint_state_publisher](http://wiki.ros.org/joint_state_publisher) node:
```
roslaunch iri_model_car_description description_test.launch
```

This launch file include a second launch file named *description.launch* which is intended to be included from other launch file that require the model car description. This launch file has two parameters:

* **name** (default=model_car): name of the car used as a namespace to include everything inside it.
* **sim_config_path** (default=iri_model_car_gazebo/config): path where the simulation sensor configuration files for all sensors are located. See the [iri_model_car_gazebo](https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/simulator/iri_model_car_gazebo) documentation for more details.

To include the iri_model_car_description into an other launch file, include the following lines:
```
  <include file="$(find iri_model_car_description)/launch/description.launch">
    <arg name="name"  value="$(arg name)"/>
    <arg name="sim_config_path" value="$(arg sim_config_path)"/>
  </include>
```

# Disclaimer

Copyright (C) Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
Mantainer IRI labrobotics (labrobotica@iri.upc.edu)

This package is distributed in the hope that it will be useful, but without any warranty. It is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. should the program prove defective, the GMR group does not assume the cost of any necessary servicing, repair  or correction.

In no event unless required by applicable law the author will be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs), even if the author has been advised of the possibility of such damages.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>
