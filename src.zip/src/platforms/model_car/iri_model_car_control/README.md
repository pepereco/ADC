## Description

This ROS package generates the motion commands to the platform (both forward speed and steering angle) from a standard [Twist](http://docs.ros.org/en/jade/api/geometry_msgs/html/msg/Twist.html) ROS message.

The forward speed command accepted by the platform is in the range [-100,100] and has no physical magnitude. To generate this command from the input Twist (linear velocity in the x axis) a simple PID controller is used together with the actual speed of the platform taken from the odometry information. The PID parameters can be set by a set of parameters.

The steering angle command accepted by the platform is also in the range [-100,100] and has no physical magnitude. To generate this command, both the desired linear speed in the x axis and the angular speed in the z axis are used to generate the required steering angle using the kinematic parameters of the platform. In this case, no feedback is available, so the computed value is directly sent to the platform without any controller.

This package also implements a watchdog feature in order to stop the platform in case the input motion commands are received periodically. The value of this watchdog period can be set by a parameter.

# ROS Interface

### Topic publishers
  - ~**control** (ackermann_msgs/AckermannDriveStamped.msg) Actual motion commands sent to the platform.

### Topic subscribers
  - ~**cmd_vel** (geometry_msgs/Twist.msg) Standard velocity command in ROS.
  - ~**odom** (nav_msgs/Odometry.msg) Pose and velocities feedback information from the platform.

### Parameters
- ~**rate** (Double; default: 10.0; min: 0.1; max: 1000) The main node thread loop rate in Hz.
- ~**speed_Kp** (Double; default: 1.0; min: 0.0; max: 1000) Proportional constant of the speed PID.
- ~**speed_Ki** (Double; default: 0.0; min: 0.0; max: 1000) Integral constant of the speed PID.
- ~**speed_Kd** (Double; default: 0.0; min: 0.0; max: 1000) Differential constant of the speed PID.
- ~**speed_i_max** (Double; default: 10.0; min: 0.0; max: 1000) Maximum integral value pf the speed PID.
- ~**watchdog_time** ** (Double; default: 0.5; min: 0.0; max: 1000) Maximum time between two control commands.
- ~**axel_distance** (Double; default: 0.3662; min: 0.01; max: 1.0) Distance between axels in meters. This parameter must coincide with the actual platform value to minimize estimation errors.
- ~**max_steer_angle** (Double; default: 0.4; min: -1.0; max: 1.0) Maximum steering angle.
- ~**min_steer_angle** (Double; default: -0.4; min: -1.0; max: 1.0) Minimum steering angle.
- ~**max_speed_control** (Double; default: 10.0; min: -100.0; max: 100.0) Maximum output speed command value.
- ~**min_speed_control** (Double; default: -10.0; min: -100.0; max: 100.0) Minimum output speed command value.
- ~**max_steer_control** (Double; default: 10.0; min: -100.0; max: 100.0) Maximum output steer command value.
- ~**min_steer_control** (Double; default: -10.0; min: -100.0; max: 100.0) Minimum output steer command value.

## Dependencies

This package requires the following packages:

* [iri_model_car_msgs](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_msgs): Set of specific ROS messages for the model car.

## Installation

Move to the active workspace:
```bash
roscd && cd ../src
```
Clone the repository:
```bash
git clone https://gitlab.iri.upc.edu/mobile_robotics/adc/platform/model_car/iri_model_car_control
```
Install ROS dependencies:
```
roscd
cd ..
rosdep install -i -r --from-paths src
```
Compile the workspace:
```
catkin_make
```

## Launch

This package is normally launched as part of a more complete launch file, either in simulation or with the real robot. Check the main [model car documentation](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to) for further information.

The main launch file (*node.launch*) has the following arguments:

* **node_name** (default=model_car_control): name of the ROS node.
* **output** (default=screen): Desired log output. Possible values are screen and log.
* **launch_prefix** (default=): Set of parameters to be pre-appended to the node launch command.
* **config_file** (default=$(find iri_model_car_control)/config/params.yaml): file with the node configuration. See [the parameters section](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_control#parameters) for more information on the available parameters.
* **cmd_vel_topic** (default=/encoders): Name of the velocities command topic to be used.
* **odom_topic** (default=/odom): Name of the odometry topic to be used
* **control_topic** (default=/control): Name of the control topic to be used.

To include the iri_model_car_control into another launch file, include the following lines:

```
  <include file="$(find iri_model_car_control)/launch/node.launch">
    <arg name="node_name"      value="$(arg node_name)"/>
    <arg name="output"         value="$(arg output)"/>
    <arg name="launch_prefix"  value="$(arg launch_prefix)"/>
    <arg name="config_file"    value="$(arg config_file)"/>
    <arg name="cmd_vel_topic"  value="$(arg cmd_vel_topic)"/>
    <arg name="odom_topic"     value="$(arg odom_topic)"/>
    <arg name="control_topic"  value="$(arg control_topic)"/>
  </include>

```

## Disclaimer

Copyright (C) Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
Mantainer IRI labrobotics (labrobotica@iri.upc.edu)

This package is distributed in the hope that it will be useful, but without any warranty. It is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. should the program prove defective, the GMR group does not assume the cost of any necessary servicing, repair  or correction.

In no event unless required by applicable law the author will be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs), even if the author has been advised of the possibility of such damages.

You should have received a copy of the GNU Lesser General Public License along with this program. If not, see <http://www.gnu.org/licenses/>
