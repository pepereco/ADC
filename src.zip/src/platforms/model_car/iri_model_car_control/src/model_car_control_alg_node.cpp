#include "model_car_control_alg_node.h"

ModelCarControlAlgNode::ModelCarControlAlgNode(void) :
  algorithm_base::IriBaseAlgorithm<ModelCarControlAlgorithm>()
{
  //init class attributes if necessary
  if(!this->private_node_handle_.getParam("rate", this->config_.rate))
  {
    ROS_WARN("ModelCarControlAlgNode::ModelCarControlAlgNode: param 'rate' not found");
  }
  else
    this->setRate(this->config_.rate);

  // [init publishers]
  this->control_publisher_ = this->private_node_handle_.advertise<ackermann_msgs::AckermannDriveStamped>("control", 1);
  
  // [init subscribers]
  this->cmd_vel_subscriber_ = this->private_node_handle_.subscribe("cmd_vel", 1, &ModelCarControlAlgNode::cmd_vel_callback, this);
  pthread_mutex_init(&this->cmd_vel_mutex_,NULL);

  this->odom_subscriber_ = this->private_node_handle_.subscribe("odom", 1, &ModelCarControlAlgNode::odom_callback, this);
  pthread_mutex_init(&this->odom_mutex_,NULL);

  // [init services]
  
  // [init clients]
  
  // [init action servers]
  
  // [init action clients]
  
  this->new_speed_feedback=false;
  this->speed_pid.initPid(this->config_.speed_Kp,this->config_.speed_Ki,this->config_.speed_Kd,this->config_.speed_i_max,-this->config_.speed_i_max,true);
}

ModelCarControlAlgNode::~ModelCarControlAlgNode(void)
{
  // [free dynamic memory]
  pthread_mutex_destroy(&this->cmd_vel_mutex_);
  pthread_mutex_destroy(&this->odom_mutex_);
}

void ModelCarControlAlgNode::mainNodeThread(void)
{
  static bool first=true;
  static ros::Time last_time;
  ros::Duration dt;
  double error;

  //lock access to algorithm if necessary
  this->alg_.lock();
  ROS_DEBUG("ModelCarControlAlgNode::mainNodeThread");
  // [fill msg structures]

  this->control_AckermannDriveStamped_msg_.header.stamp=ros::Time::now();
  if(this->control_watchdog.is_active())
  {
    this->control_AckermannDriveStamped_msg_.drive.steering_angle=0.0;
    this->control_AckermannDriveStamped_msg_.drive.steering_angle_velocity=0.0;
    this->control_AckermannDriveStamped_msg_.drive.speed=0.0;
    this->control_AckermannDriveStamped_msg_.drive.acceleration=0.0;
    this->control_AckermannDriveStamped_msg_.drive.jerk=0.0;
    this->control_watchdog.reset(ros::Duration(this->config_.watchdog_time));
    this->linear_speed_control=0.0;
    first=true;
  }
  else
  {
    if(this->new_speed_feedback)
    {
      this->new_speed_feedback=false;
      if(first)
      {
        first=false;
        last_time=this->feedback_time;
      }
      else
      {
        if(fabs(this->linear_speed_control)<this->config_.speed_deadband)
        {
          this->control_AckermannDriveStamped_msg_.drive.speed=0.0;
          this->speed_pid.reset();
        }
        else
        {
          dt=this->feedback_time-last_time;
          //linear speed
          error=this->linear_speed_control-this->linear_speed_feedback;
          this->control_AckermannDriveStamped_msg_.drive.speed=this->speed_pid.computeCommand(error,dt);
          if(this->control_AckermannDriveStamped_msg_.drive.speed>this->config_.max_speed_control)
            this->control_AckermannDriveStamped_msg_.drive.speed=this->config_.max_speed_control;
          else if(this->control_AckermannDriveStamped_msg_.drive.speed<this->config_.min_speed_control)
            this->control_AckermannDriveStamped_msg_.drive.speed=this->config_.min_speed_control;
          //angular speed
          if(this->steer_angle_control>=0)
            this->control_AckermannDriveStamped_msg_.drive.steering_angle=(this->steer_angle_control/this->config_.max_steer_angle)*this->config_.max_steer_control;
          else 
            this->control_AckermannDriveStamped_msg_.drive.steering_angle=(this->steer_angle_control/this->config_.min_steer_angle)*this->config_.min_steer_control;
        }
        last_time=this->feedback_time;
      }
    }  
  }
  this->control_publisher_.publish(this->control_AckermannDriveStamped_msg_);
  // [fill srv structure and make request to the server]
  
  // [fill action structure and make request to the action server]

  // [publish messages]
  // Uncomment the following line to publish the topic message

  
  this->alg_.unlock();
}

/*  [subscriber callbacks] */
void ModelCarControlAlgNode::cmd_vel_callback(const geometry_msgs::Twist::ConstPtr& msg)
{
  double radius;

  ROS_DEBUG("ModelCarControlAlgNode::cmd_vel_callback: New Message Received");

  //use appropiate mutex to shared variables if necessary
  this->alg_.lock();
  //this->cmd_vel_mutex_enter();

  this->linear_speed_control=msg->linear.x;
  if(msg->angular.z==0.0)
    radius=std::numeric_limits<double>::max();
  else
    radius=msg->linear.x/msg->angular.z;
  this->steer_angle_control=atan2(this->config_.axel_distance,radius);
  if(this->steer_angle_control>1.5707)
    this->steer_angle_control-=3.14159;
  if(this->steer_angle_control>this->config_.max_steer_angle)
    this->steer_angle_control=this->config_.max_steer_angle;
  else if(this->steer_angle_control<this->config_.min_steer_angle)
    this->steer_angle_control=this->config_.min_steer_angle;
  this->control_watchdog.reset(ros::Duration(this->config_.watchdog_time));
  //std::cout << msg->data << std::endl;
  //unlock previously blocked shared variables
  this->alg_.unlock();
  //this->cmd_vel_mutex_exit();
}

void ModelCarControlAlgNode::cmd_vel_mutex_enter(void)
{
  pthread_mutex_lock(&this->cmd_vel_mutex_);
}

void ModelCarControlAlgNode::cmd_vel_mutex_exit(void)
{
  pthread_mutex_unlock(&this->cmd_vel_mutex_);
}

void ModelCarControlAlgNode::odom_callback(const nav_msgs::Odometry::ConstPtr& msg)
{
  double radius;

  ROS_DEBUG("ModelCarControlAlgNode::odom_callback: New Message Received");

  //use appropiate mutex to shared variables if necessary
  this->alg_.lock();
  //this->odom_mutex_enter();

  this->new_speed_feedback=true;
  this->linear_speed_feedback=msg->twist.twist.linear.x;
  this->feedback_time=msg->header.stamp;
  //std::cout << msg->data << std::endl;
  //unlock previously blocked shared variables
  this->alg_.unlock();
  //this->odom_mutex_exit();
}

void ModelCarControlAlgNode::odom_mutex_enter(void)
{
  pthread_mutex_lock(&this->odom_mutex_);
}

void ModelCarControlAlgNode::odom_mutex_exit(void)
{
  pthread_mutex_unlock(&this->odom_mutex_);
}


/*  [service callbacks] */

/*  [action callbacks] */

/*  [action requests] */

void ModelCarControlAlgNode::node_config_update(Config &config, uint32_t level)
{
  this->alg_.lock();
  if(config.rate!=this->getRate())
    this->setRate(config.rate);
  this->config_=config;
  this->speed_pid.setGains(this->config_.speed_Kp,this->config_.speed_Ki,this->config_.speed_Kd,this->config_.speed_i_max,-this->config_.speed_i_max,true);
  this->alg_.unlock();
}

void ModelCarControlAlgNode::addNodeDiagnostics(void)
{
}

/* main function */
int main(int argc,char *argv[])
{
  return algorithm_base::main<ModelCarControlAlgNode>(argc, argv, "model_car_control_alg_node");
}
