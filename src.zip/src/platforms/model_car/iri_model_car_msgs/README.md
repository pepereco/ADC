# Description

Package containing ROS message definitions for the model car 

# ROS Messages

### topics

- *encoders*: message with the encoder information (absolute ticks and direction) of both wheel encoders.
    - **header** (Header): Standard ROS message header
    - **left\_ticks** (int32): absolute number of ticks from the left encoder from the initial position. This value always gets bigger whatever the motion direction.
    - **left\_forward** (bool): actual left motion direction. It defines if the tick increment from the last sample is positive or negative.
    - **right\_ticks** (int32): absolute number of ticks from the right encoder from the initial position. This value always gets bigger whatever the motion direction.
    - **right\_forward** (bool): actual right motion direction. It defines if the tick increment from the last sample is positive or negative.

- *ultrasounds*: message with the range information of each of the ultrasound sensors on the model car platform.
    - **header** (Header): Standard ROS message header
    - **side\_right** (sensor_msgs/Range): range information (in meters) of the ultrasound sensor at the right side of the model car platform.
    - **rear\_right** (sensor_msgs/Range): range information (in meters) of the ultrasound sensor at the rear right part of the model car platform.
    - **rear\_center** (sensor_msgs/Range): range information (in meters) of the ultrasound sensor at the rear center part of the model car platform.
    - **rear\_left** (sensor_msgs/Range): range information (in meters) of the ultrasound sensor at the rear left part of the model car platform.
    - **side\_left** (sensor_msgs/Range): range information (in meters) of the ultrasound sensor at the left side of the model car platform.

# Dependencies

This node has the following ROS dependencies:

  * [std_msgs](http://wiki.ros.org/std_msgs)
  * [sensor_msgs](http://wiki.ros.org/sensor_msgs)

This dependencies can be installed with the following command:

```
sudo apt install ros-$ROS_DISTRO-dependency-name
```

This node has the following ROS IRI dependencies:

  * none

Follow the previous links for instructions on how to install the required ROS IRI dependencies.

It also has the following IRI libraries dependencies:

  * none

Follow the previous links for instructions on how to install the required IRI dependencies.

# Installation

Move to the active workspace:
```bash
roscd && cd ../src
```
Clone the repository:
```bash
git clone <url>
```
Install ROS dependencies:
```
roscd
cd ..
rosdep install -i -r --from-paths src
```
Compile the workspace:
```
catkin_make
```

# How to use it

To use the messages defined in this package in another package you need to add:

In your `CMakeLists.txt`:

```
find_package(catkin REQUIRED COMPONENTS ... iri_model_car_msgs)
add_dependencies(your_executable ${catkin_EXPORTED_TARGETS})
```

In your `package.xml`:
```
<build_depend>iri_model_car_msgs</build_depend>
```

In your header files, for example, to use `encoders.msg`:
```
#include <iri_model_car_msgs/encoders.h>
```

## Disclaimer

Copyright (C) Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
Mantainer IRI labrobotics (labrobotica@iri.upc.edu)

This package is distributed in the hope that it will be useful, but without any warranty. It is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. should the program prove defective, the GMR group does not assume the cost of any necessary servicing, repair  or correction.

In no event unless required by applicable law the author will be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs), even if the author has been advised of the possibility of such damages.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>



