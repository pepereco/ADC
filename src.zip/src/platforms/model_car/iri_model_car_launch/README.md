# Description
This package provide some user launch files and config files to start up the model car and run some advanced functionalities. Check the main [model car documentation](https://gitlab.iri.upc.edu/mobile_robotics/adc/platforms/model_car/iri_model_car_how_to) for further information. 

# Dependencies
This node has the following dependencies:
* none

# Install

Move to the active workspace:
```bash
roscd && cd ../src
```
Clone the repository: 
```bash
git clone <url>
```
Install ROS dependencies:
```
roscd
cd ..
rosdep install -i -r --from-paths src
```
Compile the workspace:
```
catkin_make
```

# How to use it

This package provide differents launch files that can be tested.
