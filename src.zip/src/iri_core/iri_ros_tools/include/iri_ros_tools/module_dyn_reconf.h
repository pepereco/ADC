#ifndef _MODULE_DYN_RECONF_H
#define _MODULE_DYN_RECONF_H

#include <dynamic_reconfigure/Reconfigure.h>
#include <iri_ros_tools/module_service.h>

typedef enum {DYN_RECONF_NO_SUCH_PARAM,
              DYN_RECONF_NO_CHANGE,
              DYN_RECONF_SUCCESSFULL} dyn_reconf_status_t;

/**
  * \brief Dynamic reconfigure client wrapper
  *
  * This class inherits from the generic CModuleService class to implement 
  * the specifics of the dynamic reconfigure service. It ptovides functions
  * to set integer, boolean, float and string parameters of remote ROS nodes.
  */
class CModuleDynReconf : protected CModuleService<dynamic_reconfigure::Reconfigure>
{
  private:
    /**
      * \brief Name of the parameter to change
      *
      * This attribute stores the name of the parameter that is being changed
      * when the service is called. It is then used by the check function to
      * make sure the value has been changed successfully.
      */
    std::string param_name;
    /**
      * \brief Boolean value to change
      *
      * This attribute stores the value of the parameter to be modified when 
      * the service is called. It is then used by the check function to make
      * sure the value has been changed correctly.
      */
    bool bool_value;
    /**
      * \brief Integer value to change
      *
      * This attribute stores the value of the parameter to be modified when 
      * the service is called. It is then used by the check function to make
      * sure the value has been changed correctly.
      */
    int int_value;
    /**
      * \brief String value to change
      *
      * This attribute stores the value of the parameter to be modified when 
      * the service is called. It is then used by the check function to make
      * sure the value has been changed correctly.
      */
    std::string string_value;
    /**
      * \brief Double value to change
      *
      * This attribute stores the value of the parameter to be modified when 
      * the service is called. It is then used by the check function to make
      * sure the value has been changed correctly.
      */
    double double_value;
    /**
      * \brief Status of the last service call
      *
      *
      */
    dyn_reconf_status_t dyn_reconf_status;
  protected:
    /**
      * \brief Service data check callback
      *
      * This callback function is called when the service response is received
      * to check whether the parameter has been changed successfully or not.
      *
      * \param msg Dynamic reconfigure message with the request and response
      *            data.
      *
      * \return A boolean indicating whether the parameter has been changed
      *         successfully (true) or not (false)
      *            
      */
    bool check_dyn_reconf(dynamic_reconfigure::Reconfigure &msg);
  public:
    /**
      * \brief Constructor
      *
      */
    CModuleDynReconf(const std::string &name,const std::string &name_space=std::string(""));
    /**
      * \brief Sets a parameter of type boolean
      *
      * This functions sets a parameter of type boolean. It calls the dynamic 
      * reconfigure server with the provided data and waits for an answer. If
      * the data has not been changed, this function will report an error, as 
      * well as if the service call itself fails or is pending.
      * 
      * \param name String with the name of the parameter to change. This must
      *             coincide with a parameter name on the associated dynamic
      *             reconfigure server.
      *
      * \param value A boolean with the new value for the parameter.
      *
      * \return A boolean indicating whether the parameter has been successfully
      *         changed (true) or not (false)
      */
    bool set_parameter(const std::string &name,bool value);
    /**
      * \brief Sets a parameter of type integer
      *
      * This functions sets a parameter of type integer. It calls the dynamic 
      * reconfigure server with the provided data and waits for an answer. If
      * the data has not been changed, this function will report an error, as 
      * well as if the service call itself fails or is pending.
      * 
      * \param name String with the name of the parameter to change. This must
      *             coincide with a parameter name on the associated dynamic
      *             reconfigure server.
      *
      * \param value An integer with the new value for the parameter. This value
      *              must be inside the valid value range of the parameter.
      *
      * \return A boolean indicating whether the parameter has been successfully
      *         changed (true) or not (false)
      */
    bool set_parameter(const std::string &name,int value);
    /**
      * \brief Sets a parameter of type string
      *
      * This functions sets a parameter of type string. It calls the dynamic 
      * reconfigure server with the provided data and waits for an answer. If
      * the data has not been changed, this function will report an error, as 
      * well as if the service call itself fails or is pending.
      * 
      * \param name String with the name of the parameter to change. This must
      *             coincide with a parameter name on the associated dynamic
      *             reconfigure server.
      *
      * \param value A string with the new value for the parameter. This value
      *              must be inside the valid value range of the parameter.
      *
      * \return A boolean indicating whether the parameter has been successfully
      *         changed (true) or not (false)
      */
    bool set_parameter(const std::string &name,std::string &value);
    /**
      * \brief Sets a parameter of type double
      *
      * This functions sets a parameter of type double. It calls the dynamic 
      * reconfigure server with the provided data and waits for an answer. If
      * the data has not been changed, this function will report an error, as 
      * well as if the service call itself fails or is pending.
      * 
      * \param name String with the name of the parameter to change. This must
      *             coincide with a parameter name on the associated dynamic
      *             reconfigure server.
      *
      * \param value A double with the new value for the parameter. This value
      *              must be inside the valid value range of the parameter.
      *
      * \return A boolean indicating whether the parameter has been successfully
      *         changed (true) or not (false)
      */
    bool set_parameter(const std::string &name,double value);
    /**
      * \brief returns the las call status
      *
      * This function returns the status of the last service call, which can be 
      * one of the dyn_reconf_status_t data type values.
      *
      * \return the status of the last service call.
      */
    dyn_reconf_status_t get_status(void);
    /**
      * \brief Destructor
      *
      */
    ~CModuleDynReconf();
};

CModuleDynReconf::CModuleDynReconf(const std::string &name,const std::string &name_space) : CModuleService(name,name_space)
{
  this->dyn_reconf_status=DYN_RECONF_SUCCESSFULL;
  this->set_max_num_retries(1);
  this->set_call_check_function(boost::bind(&CModuleDynReconf::check_dyn_reconf,this,_1));
}
bool CModuleDynReconf::check_dyn_reconf(dynamic_reconfigure::Reconfigure &msg)
{
  unsigned int i=0;

  for(i=0;i<msg.response.config.bools.size();i++)
  {
    if(msg.response.config.bools[i].name==this->param_name)
    {
      if(msg.response.config.bools[i].value!=this->bool_value)
      {
        this->dyn_reconf_status=DYN_RECONF_NO_CHANGE;
        return false;
      }
      else 
      {
        this->dyn_reconf_status=DYN_RECONF_SUCCESSFULL;
        return true;
      }
    }
  }
  for(i=0;i<msg.response.config.ints.size();i++)
  {
    if(msg.response.config.ints[i].name==this->param_name)
    {
      if(msg.response.config.ints[i].value!=this->int_value)
      {
        this->dyn_reconf_status=DYN_RECONF_NO_CHANGE;
        return false;
      }
      else 
      {
        this->dyn_reconf_status=DYN_RECONF_SUCCESSFULL;
        return true;
      }
    }
  }
  for(i=0;i<msg.response.config.strs.size();i++)
  {
    if(msg.response.config.strs[i].name==this->param_name)
    {
      if(msg.response.config.strs[i].value!=this->string_value)
      {
        this->dyn_reconf_status=DYN_RECONF_NO_CHANGE;
        return false;
      }
      else 
      {
        this->dyn_reconf_status=DYN_RECONF_SUCCESSFULL;
        return true;
      }
    }
  }
  for(i=0;i<msg.response.config.doubles.size();i++)
  {
    if(msg.response.config.doubles[i].name==this->param_name)
    {
      if(msg.response.config.doubles[i].value!=this->double_value)
      {
        this->dyn_reconf_status=DYN_RECONF_NO_CHANGE;
        return false;
      }
      else 
      {
        this->dyn_reconf_status=DYN_RECONF_SUCCESSFULL;
        return true;
      }
    }
  }

  this->dyn_reconf_status=DYN_RECONF_NO_SUCH_PARAM;
  return false;
}

bool CModuleDynReconf::set_parameter(const std::string &name,bool value)
{
  dynamic_reconfigure::Reconfigure set_params_srv;

  ROS_DEBUG_STREAM("CModuleDynReconf::set_parameter: Sending new request on service " << this->get_name());
  ROS_DEBUG_STREAM("CModuleDynReconf::set boolean parameter " << name << " to " << value);

  set_params_srv.request.config.bools.resize(1);
  set_params_srv.request.config.bools[0].name=name;
  set_params_srv.request.config.bools[0].value=value;
  this->param_name=name;
  this->bool_value=value;
  switch(this->call(set_params_srv))
  {
    case ACT_SRV_SUCCESS: ROS_DEBUG_STREAM("CModule::set_parameters: Request successfull on server: " << this->get_name()); 
                          return true;
                          break;
    case ACT_SRV_PENDING:
    case ACT_SRV_FAIL: ROS_ERROR_STREAM("CModuleDynReconf::set_parameters: Request failed on server: " << this->get_name());
                       return false;
                       break;
    default: return false;
  }
}

bool CModuleDynReconf::set_parameter(const std::string &name,int value)
{
  dynamic_reconfigure::Reconfigure set_params_srv;

  ROS_DEBUG_STREAM("CModuleDynReconf::set_parameter: Sending new request on service " << this->get_name());
  ROS_DEBUG_STREAM("CModule::set integer parameter " << name << " to " << value);

  set_params_srv.request.config.ints.resize(1);
  set_params_srv.request.config.ints[0].name=name;
  set_params_srv.request.config.ints[0].value=value;
  this->param_name=name;
  this->int_value=value;
  switch(this->call(set_params_srv))
  {
    case ACT_SRV_SUCCESS: ROS_DEBUG_STREAM("CModule::set_parameters: Request successfull on server: " << this->get_name()); 
                          return true;
                          break;
    case ACT_SRV_PENDING:
    case ACT_SRV_FAIL: ROS_ERROR_STREAM("CModuleDynReconf::set_parameters: Request failed on server: " << this->get_name());
                       return false;
                       break;
    default: return false;
  }
}

bool CModuleDynReconf::set_parameter(const std::string &name,std::string &value)
{
  dynamic_reconfigure::Reconfigure set_params_srv;

  ROS_DEBUG_STREAM("CModuleDynReconf::set_parameter: Sending new request on service " << this->get_name());
  ROS_DEBUG_STREAM("CModuleDynReconf::set string parameter " << name << " to " << value);

  set_params_srv.request.config.strs.resize(1);
  set_params_srv.request.config.strs[0].name=name;
  set_params_srv.request.config.strs[0].value=value;
  this->param_name=name;
  this->string_value=value;
  switch(this->call(set_params_srv))
  {
    case ACT_SRV_SUCCESS: ROS_DEBUG_STREAM("CModule::set_parameters: Request successfull on server: " << this->get_name()); 
                          return true;
                          break;
    case ACT_SRV_PENDING:
    case ACT_SRV_FAIL: ROS_ERROR_STREAM("CModuleDynReconf::set_parameters: Request failed on server: " << this->get_name());
                       return false;
                       break;
    default: return false;
  }
}

bool CModuleDynReconf::set_parameter(const std::string &name,double value)
{
  dynamic_reconfigure::Reconfigure set_params_srv;

  ROS_DEBUG_STREAM("CModule::set_parameter: Sending new request on service " << this->get_name());
  ROS_DEBUG_STREAM("CModule::set double parameter " << name << " to " << value);

  set_params_srv.request.config.doubles.resize(1);
  set_params_srv.request.config.doubles[0].name=name;
  set_params_srv.request.config.doubles[0].value=value;
  this->param_name=name;
  this->double_value=value;
  switch(this->call(set_params_srv))
  {
    case ACT_SRV_SUCCESS: ROS_DEBUG_STREAM("CModule::set_parameters: Request successfull on server: " << this->get_name()); 
                          return true;
                          break;
    case ACT_SRV_PENDING:
    case ACT_SRV_FAIL: ROS_ERROR_STREAM("CModuleDynReconf::set_parameters: Request failed on server: " << this->get_name());
                       return false;
                       break;
    default: return false;
  }
}

dyn_reconf_status_t CModuleDynReconf::get_status(void)
{
  return this->dyn_reconf_status;
}

CModuleDynReconf::~CModuleDynReconf()
{

}

#endif
