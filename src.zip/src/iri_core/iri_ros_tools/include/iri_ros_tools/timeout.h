#ifndef _TIMEOUT_H
#define _TIMEOUT_H

#include <ros/ros.h>

/**
  * \brief Class to handle timeouts in ROS
  *
  * This class is intended to handle timeouts using ROS infrastructure. This
  * class works by polling instead of being event driver to simplify its use.
  * When started with the start() function, the current time and the desired 
  * lapse time are stored internally. Then, only when the timed_out() function
  * is called, the actual violation of the desired timeout is checked.
  */
class CROSTimeout
{
  private:
    /**
      * \brief Timeout active
      *
      * This attribute indicates whether the timeout object has been started
      * or not. This attribute is internally handled.
      */
    bool active;
    /**
      * \brief Initial time 
      *
      * This is the time from which the timeout is calculated. It is initialized
      * when the start() function is called.
      */
    ros::Time start_time;
    /**
      * \brief Duration of the timeout
      *
      * This is the desired timeout value. It is initialized when the start()
      * function is called. This value is added to the start time to compute
      * whether the timeout is active or not.
      */
    ros::Duration time_period;
    // mutex
    /**
      * \brief Internal Mutex
      *
      * This Mutex is used to ensure atomic access to the internal attributes 
      * of the class.
      */
    pthread_mutex_t access_;
  public:
    /**
      * \brief Constructor
      *
      */
    CROSTimeout();
    /**
      * \brief Starts the timeout operation
      *
      * This functions starts and enables the operation of the timeout. It takes 
      * the current time and the desired period and stores them internally.
      *
      * \param time a ROS Duration object with teh desired timeout value in 
      *             seconds.
      */
    void start(const ros::Duration &time);
    /**
      * \brief Stops the current timeout
      *
      * This functions stops any active timeout so that the timed_out() function
      * will never return true. If there is no active timeout, this function 
      * does nothing.
      */
    void stop(void);
    /**
      * \brief Checks the state of the current timeout
      *
      * This function checks whether the desired timeout time has elapsed or not.
      * If no timeout is active, this function always returns false.
      *
      * \return a boolean indicating whether the desired time has elapsed (true)
      *         or not (false)
      */
    bool timed_out(void);
    /**
      * \brief Destructor
      *
      */
    ~CROSTimeout();
};

#endif
