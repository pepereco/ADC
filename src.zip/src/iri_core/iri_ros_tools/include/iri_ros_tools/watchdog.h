#ifndef _WATCHDOG_H
#define _WATCHDOG_H

#include <ros/ros.h>

/**
  * \brief Class to handle watchdogs in ROS
  *
  * This class is intented to handle watchdogs using ROS infrastructure. This 
  * class works by polling instead of being event driven to simplify its use.
  * This class starts operating when an object is instantiated, and the reset()
  * function must be called with the desired watchdog time to ensure it does 
  * not get active.
  * 
  * Only when the is_active() function is called, the actual violation of the 
  * watchdog period is checked.
  */
class CROSWatchdog
{
  private:
    /**
      * \brief Initial time of the monitoring process
      *
      * This is the time at which the watchdog period started. It is initialized
      * with the time at which the reset() function is called.
      */
    ros::Time start_time;
    /**
      * \brief Maximum period of the watchdog
      *
      * This period is the maximum time allowed to call the reset() function 
      * again before reporting an error. It is initialized when the reset 
      * function is called.
      */
    ros::Duration max_time;
    /**
      * \brief Internal Mutex
      *
      * This Mutex is used to ensure atomic access to the internal attributes 
      * of the class.
      */
    pthread_mutex_t access_;
  public:
    /**
      * \brief Constructor
      *
      */
    CROSWatchdog();
    /**
      * \brief Resets the watchdog object
      *
      * This function is used to reset the watchdog time. It should be called
      * inside the callback function or inside the process to monitor. The 
      * maximum period can be modified whenever this function is called.
      *  
      * \param time Maximum period, in seconds, allowed to call this function
      *^            again before reporting and error.
      * 
      */
    void reset(const ros::Duration &time);
    /**
      * \brief Checks if the watchdog has not been reset for the allowed time
      *
      * This function checks whether the watchdog object has been reset in the 
      * allowed time or not. The actual violation of the watchdog period is
      * performed only when this function is called.
      */
    bool is_active(void);
    /**
      * \brief Destructor
      *
      */
    ~CROSWatchdog();
};

#endif
