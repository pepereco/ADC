#ifndef _IRI_MODULE_H
#define _IRI_MODULE_H

#include <iri_ros_tools/module_common.h>
#include <iri_ros_tools/module_service.h>
#include <iri_ros_tools/module_action.h>
#include <iri_ros_tools/module_exceptions.h>

#include <dynamic_reconfigure/server.h>
#include <dynamic_reconfigure/Reconfigure.h>

#include "threadserver.h"
#include "eventserver.h"
#include "mutex.h"

#define MODULE_DEFAULT_RATE 10

/** 
 * \brief Base class for all state machine modules
 *
 * This class may be used as a base class for state machine modules. It 
 * implements the following features:
 * * an abstract function (state_machine()) that is called at a configurable
 *   rate to implement the actual state machine in inherited classes. This 
 *   function must be implemented in the inherited classes. This function
 *   is called with the internal mutex locked.
 * * A dynamic reconfigure server. The callback function associated to this
 *   server is abstract and must be implemnted in the inherited class. This
 *   class is a template on the dynamic reconfigure data structure.
 * * An internal node handle is used to define the module namespace with the
 *   parameters provided at construction time (name and namespace).
 *
 * Any inherited class must call (preferably in the constructor) the start 
 * operation function in order to properly set up the internal operation of 
 * the class.
 */
template<class ModuleCfg>
class CModule
{
  protected:
    /**
      * \brief internal ROS node handle
      *
      * A ROS node handle that can be used by inherited classes to initialize 
      * ROS interfaces. This node handle is initialized at construction time
      * as follows:
      * 
      * /<node namespace>/<provided namespace>/<provided name>
      *
      */
    ros::NodeHandle module_nh;
  private:
    /**
      * \brief name of the module
      *
      * Attribute with the name of the module, together with the full namespace.
      * This name is used to report information, errors and warnings regarding 
      * the module.
      */
    std::string name;
    /**
      * \brief rate in Hz of the internal thread
      *
      * This is the actual rate at which the state_machine() function will be 
      * called. Use the set_rate() and get_rate() function to modify and 
      * retrieve its value.
      */
    ros::Rate module_rate;
    /**
      * \brief Internal mutex
      *
      * Mutex variables to ensure atomic access to internal attributes from the 
      * state machine and the ROS callback functions. It is internally handled
      * and the lock() and unlock() functions must be used to access it.
      */
    CMutex module_access;
    /* reconfiguer attributes */
    /**
      * \brief Dynamic reconfigure server
      *
      * A dynamic reconfigure server which depends on the dynamic reconfigure
      * data structure this class is template of. This server has the 
      * reconfigure_callback() callback function associated to it.
      */
    dynamic_reconfigure::Server<ModuleCfg> dyn_reconf;
    /* thread attributes */
    /**
      * \brief IRI thread server
      *
      * Pointer to the single instance of the thread server in the current 
      * process. It is used to handle the class thread.
      */
    CThreadServer *thread_server;
    /**
      * \brief Name of the internal thread
      *
      * Name of the thread used to execute the state machine of the module.
      * It is used to identify it inside the thread server.
      */
    std::string module_thread_id;
    /* event attributes */
    /**
      * \brief IRI event server
      *
      * Pointer to the single instance of the event server in the current
      * process. It is used to handle the class events.
      */
    CEventServer *event_server;
    /**
      * \brief Name of the event to terminate the internal thread
      *
      * Name of the event used to signal the termniation of the internal 
      * thread. It is used to identify it inside the event server. The 
      * activation of this event is monitored by the thread periodically.
      */
    std::string finish_thread_event_id;
  protected:
    /**
      * \brief Main thread function
      *
      * This is the main function of the internal thread. The thread itself is 
      * configured at contruction time, but it is not started until the 
      * start_operation() functions is called. This function monitors the
      * internal event to know when it has to stop, and calls the state_machine()
      * function at the desired rate.
      *
      * \param name string with the desired name for the action.
      *
      * \param namespace string with the base namespace for the action.
      */
    static void *module_thread(void *param);
    /**
      * \brief Function to implement the state machine
      *
      * This is an abstract function that must be implemented by any inherited class
      * in order to be able to instantiate an object. This function must implement 
      * the desired state machine of the module without blocking at any time, to
      * ensure a correct operation.
      *
      * This function is called with the internal mutex locked(), and it is called
      * at the desired rate.
      *
      * \param void pointer pointing to the this pointer of the current object.
      *
      * \return this functions always return a NULL pointer.
      */
    virtual void state_machine(void)=0;
    /**
      * \brief Dynamic reconfigure callback
      *
      * This abstarct function must be implemented by any inherited class in order 
      * to be able to instantiate an object. This function is called whenever a 
      * new dynamic reconfigure service call is received and must configure the
      * module with the provided data.
      *
      * \param config reference to the dynamic reconfigure data structure with
      *               all the configuration data for the class.
      * \param level integer representing the execution level at which the 
      *              function has been called. In this case it has no meaning
      *              and can be ignored.
      */
    virtual void reconfigure_callback(ModuleCfg &config, uint32_t level)=0;
    /**
      * \brief function to start the operation of the class
      *
      * This function must be called in the inherited class constructor in order
      * to start the internal thread and also start the dynamic reconfigure
      * server. 
      *  
      * TODO: this function should disapear
      */
    void start_operation(void);
    /**
      * \brief lock the mutex
      *
      * Function to lock the internal mutex of the class. Since the mutex is not 
      * public or protected, inherited classes must use this function to access
      * it.      
      */
    void lock(void);
    /**
      * \brief unlock the mutex
      *
      * Function to unlock the internal mutex of the class. Since the mutex is not 
      * public or protected, inherited classes must use this function to access
      * it.      
      */
    void unlock(void);
  public:
    /**
      * \brief Constructor
      *
      * Constructor of the base class. This function initializes and configures all
      * the internal attributes, but the object is not operating properly until the 
      * start_operation() funciton is called.
      *   
      * \param name string with the desired name for the module.
      *
      * \param namespace string with the base namespace for the module.
      */
    CModule(const std::string &name,const std::string &name_space=std::string(""));
    /**
      * \brief Function to set the rate
      *
      * This function sets the desired rate of the internal thread which defines
      * the frequency at which the state_machine() function is called. 
      *
      * If the desired rate is not valid, a CModuleException is thrown.
      * 
      * \param rate_hz the desired rate of the internal thread in Hertz. It must be 
      *                any non-negative float value.
      */
    void set_rate(double rate_hz);
    /**
      * \brief Function to get the rate
      * 
      * This function returns the current value of the thread rate. By default this 
      * value is set to 10 Hz.
      * 
      * \return the value of the current thread rate in hertz.
      */
    double get_rate(void);
    /**
      * \brief Function to get the name of the module
      *
      * This function returns the full name of the module, with the whole namespace.
      *
      * \return the name of the module.
      */
    std::string get_name(void);
    /**
      * \brief Destructor
      *
      * This function signals the internal thread to stop, waits until it finishes and
      * the frees all the internal resources.
      */
    virtual ~CModule();
};

template<class ModuleCfg>
CModule<ModuleCfg>::CModule(const std::string &name,const std::string &name_space) : 
  module_rate(MODULE_DEFAULT_RATE), 
  dyn_reconf(module_nh),
  module_nh(name_space+"/"+name)
{
  try
  {
    this->name=this->module_nh.getNamespace();
    this->event_server=CEventServer::instance();
    this->finish_thread_event_id=this->name+"_finish_thread_event";
    this->event_server->create_event(this->finish_thread_event_id);
    this->thread_server=CThreadServer::instance();
    this->module_thread_id=this->name+"_module_thread";
    this->thread_server->create_thread(this->module_thread_id);
    this->thread_server->attach_thread(this->module_thread_id,this->module_thread,this);
  }
  catch (CException &ex)
  {
    ROS_ERROR_STREAM("CModule::constructor: exception caught: " << ex.what());
    throw CModuleException(_HERE_,"Impossible to build module",this->name);
  }
}

template<class ModuleCfg>
void CModule<ModuleCfg>::set_rate(double rate_hz)
{
  if(rate_hz<=0.0)
    throw CModuleException(_HERE_,"Module rate must be positive",this->name);
  else
    this->module_rate=rate_hz;
}

template<class ModuleCfg>
double CModule<ModuleCfg>::get_rate(void)
{
  return this->module_rate;
}

template<class ModuleCfg>
std::string CModule<ModuleCfg>::get_name(void)
{
  return this->name;
}
 
template<class ModuleCfg>
void *CModule<ModuleCfg>::module_thread(void *param)
{
  CModule *module=(CModule *)param;
  bool end =false;

  /* initialize the dynamic reconfigure */
  module->dyn_reconf.setCallback(boost::bind(&CModule<ModuleCfg>::reconfigure_callback,module,_1,_2));
  
  while(!end)
  {
    if(module->event_server->event_is_set(module->finish_thread_event_id))
      end=true;
    else
    {
      module->module_access.enter();
      module->state_machine();
      module->module_access.exit();
      module->module_rate.sleep();
    }
  }
  
  pthread_exit(NULL);
}

template<class ModuleCfg>
void CModule<ModuleCfg>::start_operation(void)
{
  this->thread_server->start_thread(this->module_thread_id);
}

template<class ModuleCfg>
void CModule<ModuleCfg>::lock(void)
{
  this->module_access.enter();
}

template<class ModuleCfg>
void CModule<ModuleCfg>::unlock(void)
{
  this->module_access.exit();
}

template<class ModuleCfg>
CModule<ModuleCfg>::~CModule()
{
  if(this->thread_server->get_thread_state(this->module_thread_id)==starting || this->thread_server->get_thread_state(this->module_thread_id)==active)
  {
    this->event_server->set_event(this->finish_thread_event_id);
    this->thread_server->end_thread(this->module_thread_id);
  }
  this->thread_server->detach_thread(this->module_thread_id);
  this->thread_server->delete_thread(this->module_thread_id);
  this->module_thread_id="";
  this->event_server->delete_event(this->finish_thread_event_id);
  this->finish_thread_event_id="";
}

#endif
