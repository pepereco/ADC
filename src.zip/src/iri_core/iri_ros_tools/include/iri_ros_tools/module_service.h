#ifndef _MODULE_SERVICE_H
#define _MODULE_SERVICE_H

#include <ros/ros.h>
#include <iri_ros_tools/module_common.h>

#define     DEFAULT_SERVICE_MAX_RETRIES     5

/**
  * \brief Service client wrapper
  *
  * This class wraps a simple ROS service client in order to simplify its use.
  * This class is a template of any ROS service and provides the common features
  * to call the service and, in addition, it also provides the following features:
  *
  *  * the maximum number of times the action can fail to start before reporting 
  *    an error.
  * 
  * All these new features can be configured using the class API. 
  *
  * The service name is created inside the namespace defined by the (optional)
  * namespace and the actual name provided at contruction time as follows
  * 
  *   <main node namespace>/<class namespace>/<class name>

  */
template<class service_msg>
class CModuleService
{
  private:
    /**
      * \brief name of the service object
      *
      * Attribute with the name of the service object, together with the full 
      * namespace. This name is used to report information, errors and 
      * warnings regarding the service object.
      * 
      */
    std::string name;
    /**
      * \brief Number of tries to start the action
      * 
      * This attribute holds the number of attempts to call the service. It is 
      * only used internally to handle possible start failures.
      * 
      */
    unsigned int current_num_retries;
    /**
      * \brief maximum number of start attempts
      * 
      * This attribute holds the maximum number of attempts to call the service.
      * This value can be modified by the user with the set_max_num_retries() 
      * functions, and the actual value can be obtain with the get_max_num_retries()
      * functions.
      * 
      */
    unsigned int max_num_retries;
    /**
      * \brief
      *
      */
    bool enabled;
    /**
      * \brief internal ROS node handle
      *
      * A ROS node handle used to initialize the internal ROS service. This node 
      * handle is initialized at construction time as follows:
      * 
      * /<node namespace>/<provided namespace>/<provided name>
      * 
      */
    ros::NodeHandle nh;
    /**
      * \brief ROS service client
      *
      * This attribute is the ROS service client object. See the documentation on this
      * class for further details. 
      */
    ros::ServiceClient service_client;
    /**
      * \brief Call completion callback
      * 
      * Pointer to a function to check whether the information returned by the service
      * call is valid or not. If this function pointer is not initialized, no check is 
      * performed. By default this function points to the default_call_check() function.
      */
    boost::function< bool(service_msg &msg) > call_successfull;
  protected:
    /**
      * \brief Default completion callback
      * 
      * This is the default callback function used to check the data returned by the 
      * service call. It always returns true since no check is performed.
      * 
      * \param msg The complete service dependant message, with both the request and
      *            the response.
      *  
      * \return A boolean indicating whether the data received is valid or not.
      */
    bool default_call_check(service_msg &msg);
  public:
    /**
      * \brief Constructor
      * 
      * Constructor of the service class. This function initializes and configures all
      * the internal attributes, including the service client. 
      *   
      * \param name string with the desired name for the service.
      *
      * \param namespace string with the base namespace for the service.
      */
    CModuleService(const std::string &name,const std::string &name_space=std::string(""));
    /**
      * \brief Sets the maximum number of attempts to start the action
      * 
      * This function sets the maximum number of attempts allowed to start the
      * action before giving up. By default this value is set to 5.
      *
      * \param max_retries non-negative integer with the maximum number of attempts
      *                    to start the action
      * 
      */
    void set_max_num_retries(unsigned int max_retries);
    /**
      * \brief Gets the maximum number of attempts to start the action
      * 
      * This function returns the  maximum number of attempts allowed to start the
      * action before giving up. By default this value is set to 5.
      * 
      * \return non-negative integer with the maximum number of attempts to start 
      *         the action
      * 
      */
    unsigned int get_max_num_retries(void);
    /**
      * \brief Function to get the name of the module
      *
      * This function returns the full name of the module, with the whole namespace.
      *
      * \return the name of the module.
      * 
      */
    std::string get_name(void);
    /**
      * \brief
      *
      */
    void enable(void);
    /**
      * \brief
      *
      */
    void disable(void);
    /**
      * \brief
      *
      */
    bool is_enabled(void);
    /**
      * \brief Sets the callback function
      * 
      * This function sets the user function to check the data returned by the service
      * call. By default a dummy check function is used which always returns true.
      *  
      * \param function pointer to a function which accepts a service dependant data
      *                 structure and returns a boolean:
      *                         bool <name>(service_msg &msg)
      */
    void set_call_check_function(const boost::function< bool(service_msg &msg) > &function);
    /**
      * \brief Calls the service
      * 
      * This function actually calls the service with the provided information. If
      * the call is unsuccessfull or the data check reports an error, this functions
      * reports the call is pending, until the maximum number of retries has been
      * done.
      *
      * \param msg service dependant goal data structure to be send to the service server.
      *
      * \return the status of the request. It can be any value of the act_srv_status
      *         data type.
      */
    act_srv_status call(service_msg &msg);
    /**
      * \brief Destructor
      * 
      */
    ~CModuleService();
};

template<class service_msg>
CModuleService<service_msg>::CModuleService(const std::string &name,const std::string &name_space):nh(name_space)
{
  this->current_num_retries=0;
  this->max_num_retries=DEFAULT_SERVICE_MAX_RETRIES;
  this->service_client=this->nh.template serviceClient<service_msg>(name); 
  // assign the full service name
  this->name=this->nh.getNamespace()+"/"+name;
  // assign the default check function
  this->call_successfull=boost::bind(&CModuleService::default_call_check, this, _1);
  // enable parameter
  this->enabled=true;
}

template<class service_msg>
bool CModuleService<service_msg>::default_call_check(service_msg &msg)
{
  return true;
}

template<class service_msg>
void CModuleService<service_msg>::set_max_num_retries(unsigned int max_retries)
{
  this->max_num_retries=max_retries;
}

template<class service_msg>
unsigned int CModuleService<service_msg>::get_max_num_retries(void)
{
  return this->max_num_retries;
}

template<class service_msg>
std::string CModuleService<service_msg>::get_name(void)
{
  return this->name;
}

template<class service_msg>
void CModuleService<service_msg>::enable(void)
{
  this->enabled=true;
}

template<class service_msg>
void CModuleService<service_msg>::disable(void)
{
  this->enabled=false;
}

template<class service_msg>
bool CModuleService<service_msg>::is_enabled(void)
{
  return this->enabled;
}

template<class service_msg>
act_srv_status CModuleService<service_msg>::call(service_msg &msg)
{
  ROS_DEBUG_STREAM("CModuleService::call: Sending New Request to service " << this->service_client.getService());

  if(this->enabled)
  {
    if(this->service_client.call(msg))
    {
      if(this->call_successfull(msg))
      {
        ROS_DEBUG_STREAM("CModuleService::call: Request successfull! (server: " << this->service_client.getService() << ")");
        this->current_num_retries=0;
        return ACT_SRV_SUCCESS;
      }
      else
      {
        this->current_num_retries++;
        if(this->current_num_retries>this->max_num_retries)
        {
          ROS_ERROR_STREAM("CModuleService::call: Request failed! (server: " << this->service_client.getService() << ")");
          this->current_num_retries=0;
          return ACT_SRV_FAIL;
        }
        else
        {
          ROS_WARN_STREAM("CModuleService::call: Request pending! (server: " << this->service_client.getService() << ")");
          return ACT_SRV_PENDING;
        }
      }
    }
    else
    {
      this->current_num_retries++;
      if(this->current_num_retries>this->max_num_retries)
      {
        ROS_ERROR_STREAM("CModuleService::call: Request failed! (server: " << this->service_client.getService() << ")");
        this->current_num_retries=0;
        return ACT_SRV_FAIL;
      }
      else
      {
        ROS_WARN_STREAM("CModuleService::call: Request pending! (server: " << this->service_client.getService() << ")");
        return ACT_SRV_PENDING;
      }
    }
  }
  else
    return ACT_SRV_SUCCESS;
}

template<class service_msg>
void CModuleService<service_msg>::set_call_check_function(const boost::function< bool(service_msg &msg) > &function)
{
  this->call_successfull=function;
}

template<class service_msg>
CModuleService<service_msg>::~CModuleService()
{

}

#endif
