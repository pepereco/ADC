#ifndef _MODULE_COMMON_H
#define _MODULE_COMMON_H

typedef enum {ACT_SRV_SUCCESS,ACT_SRV_PENDING,ACT_SRV_FAIL} act_srv_status;

#endif
