#ifndef _MODULE_ACTION_H
#define _MODULE_ACTION_H

#include <iri_ros_tools/module_common.h>
#include <iri_ros_tools/module_exceptions.h>
#include <ros/ros.h>

#include <iri_ros_tools/timeout.h>
#include <iri_ros_tools/watchdog.h>

#include <actionlib/client/simple_action_client.h>
#include <actionlib/action_definition.h>

#include "mutex.h"

#define     DEFAULT_ACTION_MAX_RETRIES     5
#define     DEFAULT_ACTION_TIMEOUT         10
#define     DEFAULT_WATCHDOG_TIME          2

/**
  * \brief Possible action states returned by the get_state() function
  * 
  * These are the possible states of the action associated to this class. Most
  * of them represent actual states of the goal inside the action server, except
  * for two:
  *  * ACTION_TIMEOUT: indicates the action did not finish in the alloed time
  *  * ACTION_WATCHDOG: indicate the action has not received feedback for a long 
  *                     time
  */
typedef enum {ACTION_IDLE,
              ACTION_RUNNING,
              ACTION_SUCCESS,
              ACTION_TIMEOUT,
              ACTION_FB_WATCHDOG,
              ACTION_ABORTED,
              ACTION_PREEMPTED,
              ACTION_REJECTED} action_status;

/**
  * \brief Action client wrapper
  *
  * This class wraps a simple ROS action client in order to simplify its use.
  * This class is a template of any ROS action and provides the common features
  * to start, cancel and monitor the current state of the goal. In addition, it
  * provides the following features:
  *
  *  * the maximum number of times the action can fail to start before reporting 
  *    an error.
  *  * Timeout to control the maximum time the action can be active.
  *  * A watchdog to monitor the correct reception of the feedback of the action.
  * 
  * All these new features can be configured using the class API. 
  *
  * The action topics are created inside the namespace defined by the (optional)
  * namespace and the actual name provided at contruction time as follows
  * 
  *   <main node namespace>/<class namespace>/<class name>
  */
template<class action_ros>
class CModuleAction
{
  private:
    /**
      * \brief Internal Mutex
      *
      * This Mutex is used to ensure atomic access to the internal attributes 
      * of the class.
      */
    CMutex action_access;
    /**
      * \brief name of the action object
      *
      * Attribute with the name of the action object, together with the full 
      * namespace. This name is used to report information, errors and 
      * warnings regarding the action object.
      */
    std::string name;
    /**
      * \brief Status of the action
      * 
      * This attribute holds the current action of the object. This can be any
      * value of the action_status data type. This status is updated internally
      * and the get_state() function should be used to access it.
      */
    action_status status;
    // number of retries attributes
    /**
      * \brief Number of tries to start the action
      * 
      * This attribute holds the number of attempts to start the action. It is 
      * only used internally to handle possible start failures.
      */
    unsigned int current_num_retries;
    /**
      * \brief maximum number of start attempts
      * 
      * This attribute holds the maximum number of attempts to start the action.
      * This value can be modified by the user with the set_max_num_retries() 
      * functions, and the actual value can be obtain with the get_max_num_retries()
      * functions.
      */
    unsigned int max_num_retries;
    // ROS node handle
    /**
      * \brief internal ROS node handle
      *
      * A ROS node handle used to initialize the internal ROS action. This node 
      * handle is initialized at construction time as follows:
      * 
      * /<node namespace>/<provided namespace>/<provided name>
      *
      */
    ros::NodeHandle nh;
    // timeout attributes
    /**
      * \brief Use the timeout feature
      * 
      * This attribute specifies whether the timeout feature is to be used to limit
      * the amount of time the action is active or not. Its value is controlled by
      * the enable_timeout() and disable_timeout() functions.
      *
      * To check whether the timeout is active or not, use the is_timeout_enabled()
      * function.
      */
    bool use_timeout;
    /**
      * \brief Timeout value in seconds
      * 
      * This is the actual maximum time allowed to finish the action before reporting 
      * and error. This value can be set when starting a timeout with the start_timeout()
      * function or when updating the value with the update_timeout() function.
      */
    double timeout_value;
    /**
      * \brief Timeout object
      * 
      * This is a timeout object actually used to handle the timeout feature of this 
      * class. See the documentation of this class for further details.
      */
    CROSTimeout action_timeout;
    // watchdog attributes
    /**
      * \brief Use the watchdog feature
      * 
      * This attribute specifies whether the watchdog feature is to be used to limit
      * the amount of time between action feedback messages. Its value is controlled by
      * the enable_watchdog() and disable_watchdog() functions.
      *
      * To check whether the watchdog is active or not, use the is_watchdog_enabled()
      * function.
      */
    bool use_watchdog;
    /**
      * \brief Maximum time between feedback messages
      * 
      * This attribute holds the maximum time in seconds allowed between two consecutive
      * feedback messages. This value can be modified with the set_feedback_watchdog_time().
      * To get the current value use the get_feedback_watchdog_time() function.
      */
    double watchdog_time;
    /**
      * \brief Watchdog object
      * 
      * This is the watchdog object actually used to handle the watchdog feature of this
      * class. This feature is also anables. See the documentation of this class for
      * further details.
      */
    CROSWatchdog feedback_watchdog;
    /**
      * \brief
      *
      */
    bool enabled;
    // action attributes
    /**
      * \brief ROS topic messages names
      * 
      * This declaration defines all the ROS topis names of the provided action.
      */
    ACTION_DEFINITION(action_ros);
    /**
      * \brief Action client object
      * 
      * This points to the ROS action client object. See the documentation on this
      * class for further details.
      */
    actionlib::SimpleActionClient<action_ros> *action_client;
    /**
      * \brief Result message of the action
      * 
      * This attribute holds the result message of the last executed action. Use 
      * the get_result() function to get it. This data structure is updated by
      * the action_done() callback.
      */
    Result action_result_msg;
    /**
      * \brief Feedback message of the action
      * 
      * This attribute holds the last feedback message received of the current 
      * action. Use the get_feedback() function to get it. This data structure
      * is updated by the action_feedback() callback.
      */
    Feedback action_feedback_msg;
    /**
      * \brief Action done callback
      * 
      * This callback is called whenever the current action finishes. It stores 
      * the user defined result data structure into the internal attribute and
      * reports how the action ended, both using the rosout feature and the
      * internal status attribute.
      *
      * \param state termination state of the current action. Defined by ROS.
      *
      * \param result action dependant result data structure received from the
      *               action server.
      */
    void action_done(const actionlib::SimpleClientGoalState& state,const ResultConstPtr& result)
    {
      this->action_access.enter();
      if(state==actionlib::SimpleClientGoalState::ABORTED)
      {
        ROS_ERROR_STREAM("CModuleAction::action_done: goal on server " << this->name << " aborted");
        this->status=ACTION_ABORTED;
      }
      if(state==actionlib::SimpleClientGoalState::REJECTED)
      {
        ROS_ERROR_STREAM("CModuleAction::action_done: goal on server " << this->name << " rejected");
        this->status=ACTION_REJECTED;
      }
      else if(state==actionlib::SimpleClientGoalState::PREEMPTED)
      {
        ROS_WARN_STREAM("CModuleAction::action_done: goal on server " << this->name << " preempted");
        this->status=ACTION_PREEMPTED;
      }
      else if(state==actionlib::SimpleClientGoalState::SUCCEEDED)
      {
        ROS_INFO_STREAM("CModuleAction::action_done: goal on server " << this->name << " successfull");
        this->status=ACTION_SUCCESS;
      } 
      this->action_result_msg=*result;
      this->action_feedback_msg=Feedback();
      this->action_access.exit();
    }
    /**
      * \brief Action active callback
      * 
      * This callback is called when the action becomes active, after it has been 
      * received by the server.
      */
    void action_active(void);
    /**
      * \brief Action feedback callback
      * 
      * This callback is called whenever new feedback data is received from the 
      * action server. This function updated the internal feedback data structure.
      *
      * \param feedback action dependant feedback data structure received from the
      *                 action server.
      */
    void action_feedback(const FeedbackConstPtr& feedback)
    {
      ROS_DEBUG_STREAM("CModuleAction::action_feedback: Got Feedback from server " << this->name << "!");
      this->action_access.enter();
      this->action_feedback_msg=*feedback;
      if(this->use_watchdog)
        this->feedback_watchdog.reset(ros::Duration(this->watchdog_time));
      this->action_access.exit();
    }
  public:
    /**
      * \brief Constructor
      * 
      * Constructor of the action class. This function initializes and configures all
      * the internal attributes, including the action client. 
      *   
      * \param name string with the desired name for the action.
      *
      * \param namespace string with the base namespace for the action.

      */
    CModuleAction(const std::string &name,const std::string &name_space=std::string(""));
    /**
      * \brief Sets the maximum number of attempts to start the action
      * 
      * This function sets the maximum number of attempts allowed to start the
      * action before giving up. By default this value is set to 5.
      *
      * \param max_retries non-negative integer with the maximum number of attempts
      *                    to start the action
      */
    void set_max_num_retries(unsigned int max_retries);
    /**
      * \brief Gets the maximum number of attempts to start the action
      * 
      * This function returns the  maximum number of attempts allowed to start the
      * action before giving up. By default this value is set to 5.
      * 
      * \return non-negative integer with the maximum number of attempts to start 
      *         the action
      */
    unsigned int get_max_num_retries(void);
    /**
      * \brief Enables the actiin feedback watchdog
      * 
      * This function enables the internal action feedback watchdog to limit 
      * the maximum time between feedback messages. By default this feature is 
      * enabled.
      *
      * \param time_s the desired maximum time between feedback messages before 
      *               reporting and error.
      */
    void enable_watchdog(double time_s);
    /**
      * \brief Disables the action feedback watchdog
      * 
      * This function disables the internal action feedback watchdog to limit 
      * the maximum time between feedback messgaes. By default this feature is 
      * enabled.
      */
    void disable_watchdog(void);
    /**
      * \brief Checks whether the feedback watchdog is enabled or not
      * 
      * This functions checks whether the internal feedback watchdog for the current
      * action is enabled or not.
      *
      * \return A boolean indicating whether the watchdog is enabled (true) or not
      *         (false)
      */
    bool is_watchdog_enabled(void);
    /**
      * \brief Gets the feedback watchdog time
      * 
      * This functions returns the maximum allowed time between two consecutive 
      * feedback messages before reporting an error. By default this value is
      * set to 2.
      *
      * \return the maximum allowed time in seconds between two consecutive 
      *         feedback messages.
      */
    double get_feedback_watchdog_time(void);
    /**
      * \brief Checks the state of the watchdog
      * 
      * This function checks whether the internal watchdog has been activated
      * because the feedback callback functions has not been called for longer
      * than the allowed time.
      *
      * \return A boolean indicating whether the watchdog is active (true) or
      *         not (false)
      */
    bool is_watchdog_active(void);
    /**
      * \brief Enables the action timeout
      * 
      * This function enables the internal action timeout to limit the maximum 
      * time the action can be active without finishing properly. By default 
      * this feature is disabled.
      *
      * \param time_s the desired maximum ammount of time the action can be 
      *               active before reporting and error.
      */
    void enable_timeout(double time_s);
    /**
      * \brief Disables the action timeout
      * 
      * This function disables the internal action timeout to limit the maximum 
      * time the action can be active without finishing properly. By default 
      * this feature is disabled.
      */
    void disable_timeout(void); 
    /**
      * \brief Updates the current timeout value
      * 
      * This function updates the current timeout value, if it is enabled. The
      * time already elapsed since the start of the action is not taken into
      * account when updating the value, so the provided time will be the new
      * timeout time.
      *
      * \param time_s the new timeout time in seconds to wait for the termination
      *               of the current action.
      */
    void update_timeout(double time_s);
    /**
      * \brief Stops the timeout
      * 
      * This functions stops the internal timeout, if it is enabled, so that no
      * timeout error will be reported.
      */
    void stop_timeout(void);
    /**
      * \brief Checks whether the timeout is enabled or not
      * 
      * This functions checks whether the internal timeout value for the current
      * action is enabled or not.
      *
      * \return A boolean indicating whether the timeout is enabled (true) or not
      *         (false)
      */
    bool is_timeout_enabled(void);
    /**
      * \brief Checks whether the timeout is active or not
      * 
      * This functions chekcs whether the maximum time allowed to complete the 
      *action has elapsed or not. 
      * 
      * \return A boolean indicating whether the timeout is active (true) or not
      *         (false)
      */
    bool is_timeout_active(void);
    /**
      * \brief Function to get the name of the module
      *
      * This function returns the full name of the module, with the whole namespace.
      *
      * \return the name of the module.
      * 
      */
    std::string get_name(void);
    /**
      * \brief 
      *
      */
    void enable(void);
    /**
      * \brief 
      *
      */
    void disable(void);
    /**
      * \brief 
      *
      */
    bool is_enabled(void);
    /**
      * \brief start the action
      * 
      * This function start the action with the provided goal information. This function
      * first checks whether the action server is connected or not. In case it is not 
      * connected it will return reporting a pending condition util the maximum number of
      * repetitions has been reached. In this case it will report an error.
      *
      * If the action server is connected, it sends all the goal information, resets the 
      * feeedback watchdog and enables the internal timeout in case it is enabled.
      *
      * \param msg action dependant goal data structure to be send to the action server.
      *
      * \return the status of the request. It can be any value of the act_srv_status
      *         data type.
      */
    act_srv_status make_request(Goal &msg)
    {
      if(this->enabled)
      {
        if(this->action_client->isServerConnected())
        {
          ROS_DEBUG_STREAM("CModuleAction::make_request: Server " << this->name << " is Available!");
          this->current_num_retries=0;
          this->action_client->sendGoal(msg,
                      boost::bind(&CModuleAction<action_ros>::action_done,     this, _1, _2),
                      boost::bind(&CModuleAction<action_ros>::action_active,   this),
                      boost::bind(&CModuleAction<action_ros>::action_feedback, this, _1));
          this->feedback_watchdog.reset(ros::Duration(this->watchdog_time));
          this->status=ACTION_RUNNING;
          if(this->use_timeout)
          {
            if(this->timeout_value>0.0)
              this->action_timeout.start(ros::Duration(this->timeout_value));
          }
          ROS_DEBUG_STREAM("CModuleAction::make_request: Goal Sent to server " << this->name << ". Wait for Result!");
          return ACT_SRV_SUCCESS;
        }
        else
        {
          this->current_num_retries++;
          if(this->current_num_retries>this->max_num_retries)
          {
            this->current_num_retries=0;
            ROS_DEBUG_STREAM("CModuleAction::make_request: Action start on server " << this->name << " failed!");
            return ACT_SRV_FAIL;
          }
          else
          {
            ROS_DEBUG_STREAM("CModuleAction::make_request: Action start on server " << this->name << " pending!");
            return ACT_SRV_PENDING;
          }
        }
      }
      else 
      {
        this->status=ACTION_RUNNING;
        return ACT_SRV_SUCCESS;
      }
    }

    /**
      * \brief Cancels the current action
      * 
      * This function cancels the current action. When this function is called,
      * the action in the action server may still be active, so it is necessary 
      * to check the is_finished() function to actually know when the action
      * has ended.
      */
    void cancel(void);
    /**
      * \brief Checks whether the action has finished or not
      * 
      * This function checks whether the current action has ended or not. The
      * action may end for several reasons, use the get_state() function to
      * know the exact cause.
      * 
      * \return A boolean indicating whether the current actions has finished
      *         (true) or not (false);
      */
    bool is_finished(void);
    /**
      * \brief Returns the current status of the action
      * 
      * This functions returns the current status of the action. If no action 
      * is active, the value returned by this function is meaningless.
      *  
      * \return the current state of the action. It can be any value of the 
      *         actio_status data structure.
      */
    action_status get_state(void);
    /**
      * \brief Returns the action result
      * 
      * This function returns the action dependant result data structure 
      * returned by the action server when the last goal has ended. If no 
      * goal has been started of the current goal is still active, the
      * value returned by this function is meaningless.
      *
      * \return an action dependant result data structure of the last 
      *         executed action.
      */
    Result get_result(void)
    {
      return this->action_result_msg;
    }
    /**
      * \brief Returns the action feedback
      * 
      * This function returns the last received action dependant feedback
      * data structure. If no action is active, the value resturned by
      * this functions is meaningless.
      *
      * \return the last action dependant feedback data structure received
      *         from the current goal.
      */
    Feedback get_feedback(void)
    {
      return this->action_feedback_msg;
    }
    /**
      * \brief Destructor
      * 
      */
    ~CModuleAction();
};

template<class action_ros>
CModuleAction<action_ros>::CModuleAction(const std::string &name,const std::string &name_space):nh(name_space)
{
  this->name=this->nh.getNamespace()+"/"+name;
  this->status=ACTION_IDLE;
  // retry control
  this->current_num_retries=0;
  this->max_num_retries=DEFAULT_ACTION_MAX_RETRIES;
  // assign the full service name
  // timeouts
  this->use_timeout=false;
  this->timeout_value=0.0;
  this->timeout_value=DEFAULT_ACTION_TIMEOUT;
  // waychdog
  this->use_watchdog=true;
  this->watchdog_time=DEFAULT_WATCHDOG_TIME;
  // internal action
  this->action_client=NULL;
  this->action_client=new actionlib::SimpleActionClient<action_ros>(this->nh,name,true);
  // enable parameter
  this->enabled=true;
}

template<class action_ros>
void CModuleAction<action_ros>::action_active(void)
{
  ROS_DEBUG_STREAM("CModuleAction::action_active: Goal on server " << this->name << " just went active!");
}

template<class action_ros>
void CModuleAction<action_ros>::set_max_num_retries(unsigned int max_retries)
{
  this->action_access.enter();
  this->max_num_retries=max_retries;
  this->action_access.exit();
}

template<class action_ros>
unsigned int CModuleAction<action_ros>::get_max_num_retries(void)
{
  return this->max_num_retries;
}

template<class action_ros>
void CModuleAction<action_ros>::enable_watchdog(double time_s)
{
  this->action_access.enter();
  if(time_s>0.0)
  {
    this->watchdog_time=time_s;
    this->use_watchdog=true;
    this->feedback_watchdog.reset(ros::Duration(this->watchdog_time));
  }
  else
  {
    this->action_access.exit();
    throw CModuleException(_HERE_,"Invalid watchdog value",this->name);
  }
  this->action_access.exit();
}

template<class action_ros>
void CModuleAction<action_ros>::disable_watchdog(void)
{
  this->action_access.enter();
  this->use_watchdog=false;
  this->action_access.exit();
}

template<class action_ros>
bool CModuleAction<action_ros>::is_watchdog_enabled(void)
{
  return this->use_watchdog;
}

template<class action_ros>
double CModuleAction<action_ros>::get_feedback_watchdog_time(void)
{
  return this->watchdog_time;
}

template<class action_ros>
bool CModuleAction<action_ros>::is_watchdog_active(void)
{
  this->action_access.enter();
  if(this->enabled)
  {
    if(this->use_watchdog && this->feedback_watchdog.is_active())
    {
      this->status=ACTION_FB_WATCHDOG;
      this->action_access.exit();
      return true;
    }
    else
    {
      this->action_access.exit();
      return false;
    }
  }
  else
    return false;
}

template<class action_ros>
void CModuleAction<action_ros>::enable_timeout(double time_s)
{
  this->action_access.enter();
  if(time_s>0.0)
  {
    this->timeout_value=time_s;
    this->use_timeout=true;
  }
  else
  {
    this->action_access.exit();
    throw CModuleException(_HERE_,"Invalid timeout value",this->name);
  }
  this->action_access.exit();
}

template<class action_ros>
void CModuleAction<action_ros>::disable_timeout(void)
{
  this->action_access.enter();
  this->use_timeout=false;
  this->action_access.exit();
}

template<class action_ros>
void CModuleAction<action_ros>::update_timeout(double time_s)
{
  this->action_access.enter();
  if(this->use_timeout)
  {
    if(time_s>0.0)
    {
      this->action_timeout.start(ros::Duration(time_s));
      this->timeout_value=time_s;
    }
    else
    {
      this->action_access.exit();
      throw CModuleException(_HERE_,"Invalid timeout value",this->name);
    }
  }
  this->action_access.exit();
}

template<class action_ros>
void CModuleAction<action_ros>::stop_timeout(void)
{
  this->action_access.enter();
  this->action_timeout.stop();
  this->action_access.exit();
}

template<class action_ros>
bool CModuleAction<action_ros>::is_timeout_enabled(void)
{
  return this->use_timeout;
}

template<class action_ros>
bool CModuleAction<action_ros>::is_timeout_active(void)
{
  this->action_access.enter();
  if(this->use_timeout && this->action_timeout.timed_out())
  {
    this->status=ACTION_TIMEOUT;
    this->action_access.exit();
    return true;
  }
  else
  {
    this->action_access.exit();
    return false;
  }
}

template<class action_ros>
void CModuleAction<action_ros>::enable(void)
{
  this->action_access.enter();
  this->enabled=true;
  this->action_access.exit();
}

template<class action_ros>
void CModuleAction<action_ros>::disable(void)
{
  this->action_access.enter();
  this->enabled=false;
  this->action_access.exit();
}

template<class action_ros>
bool CModuleAction<action_ros>::is_enabled(void)
{
  return this->enabled;
}

template<class action_ros>
std::string CModuleAction<action_ros>::get_name(void)
{
  return this->name;
}

template<class action_ros>
void CModuleAction<action_ros>::cancel(void)
{
  actionlib::SimpleClientGoalState action_state(actionlib::SimpleClientGoalState::PENDING);

  if(this->enabled)
  { 
    action_state=action_client->getState();
    if(action_state==actionlib::SimpleClientGoalState::ACTIVE)
      this->action_client->cancelGoal();
  }
}

template<class action_ros>
bool CModuleAction<action_ros>::is_finished(void)
{
  actionlib::SimpleClientGoalState action_state(actionlib::SimpleClientGoalState::PENDING);
  
  if(this->enabled)
  {
    action_state=action_client->getState();
    if(action_state==actionlib::SimpleClientGoalState::ACTIVE)
      return false;
    else
      return true;
  }
  else 
    return true;
}

template<class action_ros>
action_status CModuleAction<action_ros>::get_state(void)
{
  if(this->enabled)
  {
    if(this->status==ACTION_RUNNING)
    {
      this->is_timeout_active();
      this->is_watchdog_active();
    }
  }
  else
    this->status=ACTION_SUCCESS;

  return this->status;
}

template<class action_ros>
CModuleAction<action_ros>::~CModuleAction()
{
  if(this->enabled)
  {
    if(this->status==ACTION_RUNNING)
      this->action_client->cancelGoal();
  }
  delete this->action_client;
}

#endif
