#!/bin/bash

echo "/*********************************************/"
echo "/*   Creating New ROS TF Listener broadcaster */"
echo "/*********************************************/"

script_name="add_tf_listener_broadcaster"

# check wether the scripts path environment variable has been defined
scripts_path=`echo "${IRI_ROS_SCRIPTS_PATH}"`
if [[ -z "${scripts_path}" ]]
then
  echo "ERROR: The scripts path environment varibale has not been defined. Please see the wiki documentation for instructions on how to create it."
  exit
# else
#   echo "The scripts path environment variable has been properly defined."
fi

source "${IRI_ROS_SCRIPTS_PATH}/libraries/scripts_library.sh"
source "${IRI_ROS_SCRIPTS_PATH}/libraries/create_tf_broadcaster.sh"
source "${IRI_ROS_SCRIPTS_PATH}/libraries/create_tf_listener.sh"

check_libraries
check_templates

pub_subs=
ros_pkg=

#check for input project name paramenter
while getopts “:o:p:” OPTION
do
  case $OPTION in
    o)
       pub_subs=$OPTARG
       ;;
    p)
       ros_pkg=$OPTARG
       ;;

    ?)
       echo "ERROR: invalid input argument ${OPTION}"
       kill_exit "Usage: ${script_name}.sh -o [broadcaster,listener] -p ros_pkg"
       exit
       ;;
  esac
done

#check if publisher name parameter is filled up
if [ ! "${pub_subs}" ] || [ ! "${ros_pkg}" ]
then
  echo "ERROR: Missing input parameters..."
  kill_exit "Usage: ${script_name}.sh -o [broadcaster,listener] -p ros_pkg"
fi

#check publisher subscriber parameter
if [[ ! "${pub_subs}" = "broadcaster" ]] && [[ ! "${pub_subs}" = "listener" ]]
then
  kill_exit "ERROR: First parameter must be either \"broadcaster\" or \"listener\", aborting ..."
fi

#check if package exists
result=`roscd ${ros_pkg}`
if [[ -z "${result}" ]]
then
  roscd ${ros_pkg}
else
  kill_exit "ERROR: ROS package ${ros_pkg} does NOT exist or can't be found. Create it, or load the correct workspace."
fi

check_package "${ros_pkg}"
if [[ ${pkg_exists} == true ]]
then
  roscd ${ros_pkg}
else
  kill_exit "ROS package ${ros_pkg} does NOT exist of can't be found. Create it, or load the correct workspace."
fi

#retrieve header and source files and pkg kind (algorithm/driver)
get_h_cpp_files ${ros_pkg}
is_driver_or_alg_node ${ros_pkg}
echo "node_h=${node_h}"
echo "node_c=${node_c}"
echo "driver_alg=${driver_alg}"

if [[ -z ${node_h} ]] || [[ -z ${node_c} ]] || [[ -z ${driver_alg} ]]
then
  kill_exit "ERROR: Problems found with headers and/or source files"
fi

#go to package folder
roscd "${ros_pkg}"

#modify readme with added ROS interface
type="topic"
fill_readme_ros_interface ${type} ${pub_subs} ${ros_pkg} "tf" "tf" "tfMessage" "true"

#modify node files adding server/client parameters
if [[ "${pub_subs}" = "broadcaster" ]]
then
  create_tf_broadcaster  ${ros_pkg} ${node_h} ${node_c} ${driver_alg}
else
  create_tf_listener     ${ros_pkg} ${node_h} ${node_c} ${driver_alg}
fi
