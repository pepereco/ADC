#include "template_node.h"

TemplateNode::TemplateNode(ros::NodeHandle &nh) : 
  iri_base_driver::IriBaseNodeDriver<TemplateDriver>(nh)
{
  //init class attributes if necessary
  if(!this->private_node_handle_.getParam("rate", this->config_.rate))
  {
    ROS_WARN("TemplateNode::TemplateNode: param 'rate' not found");
  }
  else
    this->setRate(this->config_.rate);

  // [init publishers]
  
  // [init subscribers]
  
  // [init services]
  
  // [init clients]
  
  // [init action servers]
  
  // [init action clients]
}

void TemplateNode::mainNodeThread(void)
{
  //lock access to driver if necessary
  this->driver_.lock();
  ROS_DEBUG("TemplateNode::mainNodeThread");

  // [fill msg Header if necessary]

  // [fill msg structures]
  
  // [fill srv structure and make request to the server]
  
  // [fill action structure and make request to the action server]

  // [publish messages]

  //unlock access to driver if previously blocked
  this->driver_.unlock();
}

/*  [subscriber callbacks] */

/*  [service callbacks] */

/*  [action callbacks] */

/*  [action requests] */

void TemplateNode::postNodeOpenHook(void)
{
}

void TemplateNode::preNodeCloseHook(void)
{
}

void TemplateNode::addNodeDiagnostics(void)
{
}

void TemplateNode::node_config_update(Config& new_cfg, uint32_t level)
{
  this->driver_.lock();
  if(new_cfg.rate!=this->getRate())
    this->setRate(new_cfg.rate);
  this->config_=new_cfg;
  this->driver_.unlock();
}

TemplateNode::~TemplateNode(void)
{
  // [free dynamic memory]
}

/* main function */
int main(int argc,char *argv[])
{
  return iri_base_driver::main<TemplateNode>(argc, argv, "template_node");
}
