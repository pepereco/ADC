#include "template_driver.h"

TemplateDriver::TemplateDriver(void)
{
  //setDriverId(driver string id);
}

bool TemplateDriver::openDriver(void)
{
  //setDriverId(driver string id);

  return true;
}

bool TemplateDriver::closeDriver(void)
{
  return true;
}

bool TemplateDriver::startDriver(void)
{
  return true;
}

bool TemplateDriver::stopDriver(void)
{
  return true;
}

void TemplateDriver::config_update(Config& new_cfg, uint32_t level)
{
  this->lock();
  
  // depending on current state
  // update driver with new_cfg data
  switch(this->getState())
  {
    case iri_base_driver::CLOSED:
      break;

    case iri_base_driver::OPENED:
      break;

    case iri_base_driver::RUNNING:
      break;
  }

  // save the current configuration
  this->config_=new_cfg;

  this->unlock();
}

TemplateDriver::~TemplateDriver(void)
{
}
