IRI_ROS_SCRIPTS
==============

## Description

Set of scripts to easily generate driver and algorithm packages in ROS, and also a set of scripts to add topic publishers and subscribers, service clients and servers, action clients and servers and tf listeners and broadcasters to existing package nodes.

- Create packages: the following scripts create a new ROS package containing a single ROS node (which inherits from IRI ROS base classes), a dynamic reconfigure file, sample launch files, LICENSE and README files. 
    - create_algorithm_package.sh: the created ROS node inherits from [iri_base_algorithm](https://gitlab.iri.upc.edu/labrobotica/ros/iri_core/iri_base_algorithm) class.
    - create_driver_package.sh:    the created ROS node inherits from [iri_base_driver](https://gitlab.iri.upc.edu/labrobotica/ros/iri_core/iri_base_driver) class.
- Add communication interfaces: the following scripts modify the node inside the target ROS package (which must have the IRI structure). They add the dependencies to the specified message types, the objects variables and callback functions if needed, and some commented code examples on how to use them.
    - add_topic_publisher_subscriber.sh
    - add_service_server_client.sh
    - add_action_server_client.sh
    - add_tf_listener_broadcaster.sh

## Installation

- Clone this repository

- Install realpath:

      sudo apt-get install realpath

- Source the setup.bash file contained in the repository. 

      source /path/to/iri_ros_scripts/setup.bash

- You can add that line to your `~/.bashrc` so it is automatically loaded.


## How to use it

- Go to your ROS workspace source directory:

```
roscd; cd ../src;
```

```
create_algorithm_package.sh -n node_name [-i][-p prefix]
```
- **-n node\_name**: The node's name. It has a default 'iri\_' prefix.
- **-i**: (optional) Avoid adding the default iri_ prefix to the provided node name.
- **-p prefix**: (optional) Replaces default 'iri\_' prefix with specified 'prefix\_'.
```
create_driver_package.sh -n node_name [-i][-p prefix]
```
- **-n node\_name**: The node's name. It has a default 'iri\_' prefix.
- **-i**: (optional) Avoid adding the default iri_ prefix to the provided node name.
- **-p prefix**: (optional) Replaces default 'iri\_' prefix with specified 'prefix\_'.
```
add_topic_publisher_subscriber.sh -o <publisher,subscriber> -p ros_pkg_name -t topic_name -m message.msg -b #
```
- **-o \[publisher, subscriber\]**: To add a publisher or a subscriber.
- **-p ros\_pkg\_name**: The target ros package.
- **-t topic\_name**: The topic's name. **It must not have a backslash (\\) nor any whitespace characters**.
- **-m message**: The topic's message.msg.
- **-b buffer\_length**: The buffer's length (usually 1).
```
add_service_server_client.sh -o <server,client> -p ros_pkg_name -s service_name -m service.srv
```
- **-o \[server, client\]**: To add a service server or client.
- **-p ros\_pkg\_name**: The target ros package.
- **-s service\_name**: The service's name. **It must not have a backslash (\\) nor any whitespace characters**.
- **-m service**: The service's service.srv.
```
add_action_server_client.sh -o <server,client> -p ros_pkg_name -a action_name -m action.action
```
- **-o \[server, client\]**: To add an action server or client.
- **-p ros\_pkg\_name**: The target ros package.
- **-a action\_name**: The action's name. **It must not have a backslash (\\) nor any whitespace characters**.
- **-m message**: The action's message.action.
```
add_tf_listener_broadcaster.sh -o <listener,broadcaster> -p ros_pkg_name
```
- **-o \[listener, broadcaster\]**: To add a tf listener or broadcaster.
- **-p ros\_pkg\_name**: The target ros package.