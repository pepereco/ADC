#!/bin/bash

source "${ROS_ROOT}/../rosbash/rosbash" || kill_exit "ERROR: ROS_ROOT Not found, try to install ROS again"

# kill_exit
# prints string in $1 and exits script
# - $1: string to print
function kill_exit
{
  echo -e $1
  echo ""
  exit
}

# check_libraries
# looks for other scripts in the library. If one script has 
# not been found exits the script
function check_libraries
{
  echo "Checking libraries ..."
  if [[ -d "${IRI_ROS_SCRIPTS_PATH}/libraries" ]]
  then
    pushd "${IRI_ROS_SCRIPTS_PATH}/libraries" > /dev/null
    if [[ -e "create_server.sh" ]] && [[ -e "create_client.sh" ]] && [[ -e "create_publisher.sh" ]] && [[ -e "create_subscriber.sh" ]] && [[ -e "create_tf_broadcaster.sh" ]] && [[ -e "create_tf_listener.sh" ]]
    then
      echo "All library files available"
      popd > /dev/null
    else
      popd > /dev/null
      kill_exit "ERROR: Missing some script files, please download IRI_ROS scripts again, aborting ..."
    fi
  else
    popd > /dev/null
    kill_exit "ERROR: Missing libraries folder, please download IRI_ROS scripts again, aborting ..."
  fi
}

# check_templates
# looks for template files in the library. If one template is
# missing then exits the script
function check_templates
{
  echo "Checking driver templates ..."
  if [[ -d "${IRI_ROS_SCRIPTS_PATH}/driver_templates" ]]
  then
    pushd "${IRI_ROS_SCRIPTS_PATH}/driver_templates" > /dev/null
    if [[ -e "CMakeLists.txt" ]] && [[ -e "template_driver.cfg" ]] && [[ -e "template_driver.h" ]] && [[ -e "template_driver.cpp" ]] && [[ -e "template_driver_node.h" ]] && [[ -e "template_driver_node.cpp" ]]
    then
      echo "Driver template files available"
      popd > /dev/null
    else
      popd > /dev/null
      kill_exit "ERROR: Missing some driver template files, please download IRI_ROS scripts again, aborting ..."
    fi
  else
    popd > /dev/null
    kill_exit "ERROR: Missing driver templates folder, please download IRI_ROS scripts again, aborting ..."
  fi

  echo "Checking algorithm templates ..."
  if [[ -d "${IRI_ROS_SCRIPTS_PATH}/algorithm_templates" ]]
  then
    pushd "${IRI_ROS_SCRIPTS_PATH}/algorithm_templates" > /dev/null
    if [[ -e "CMakeLists.txt" ]] && [[ -e "template_alg.cfg" ]] && [[ -e "template_alg.cpp" ]] && [[ -e "template_alg.h" ]] && [[ -e "template_alg_node.cpp" ]] && [[ -e "template_alg_node.h" ]]
    then
      echo "Generic algorithm template files available"
      popd > /dev/null
    else
      popd > /dev/null
      kill_exit "ERROR: Missing some generic algorithm template files, please download IRI_ROS scripts again, aborting ..."
    fi
  else
    popd > /dev/null
    kill_exit "ERROR: Missing generic algorithm templates folder, please download IRI_ROS scripts again, aborting ..."
  fi
}

# check_package
# looks for package in $1. Tries to access package via roscd.
# If an error is returned, pkg does NOT exists
function check_package
{
  if [[ -z $1 ]]
  then
    kill_exit "ERROR: check_package: missing input parameters"
  fi

  #save "roscd pkg" output
  local out=`roscd $1`

  #if no output ==> pkg exists
  if [[ -z "${out}" ]]
  then
    pkg_exists=true
  else
    pkg_exists=false
  fi
}

# create_basename
# Given a package name without spaces, creates the corresponding basename
# - $1: package name
function create_basename
{
  if [[ -z $1 ]]
  then
    kill_exit "ERROR: create_basename: missing input parameters"
  fi

  local in_pkg=$1

  #parse input name for '_'
  local parsed_name=$(echo ${in_pkg} | sed 's/_/ /g')

  #for each word, uppercase the first letter and add it to basename
  for ii in ${parsed_name}
  do
    local first=$(echo ${ii:0:1} | tr "[:lower:]" "[:upper:]")
    basename="${basename}${first}${ii:1}"
  done
  #echo "basename=${basename}"
}

# get_core_basename
# Given a source file, retrieves the class name
# Looks for class destructor
# if no destrctor defined, function fails
function get_class_basename
{
  if [[ -z $1 ]]
  then
    kill_exit "ERROR: get_class_basename missing input parameters"
  fi

  local source_file=$1
  local class_name_def=`sed -n "/::~ */p" ${source_file}`
  local last_char_pos=`expr index "${class_name_def}" :`
  let last_char_pos-=1
  class_name=`expr substr "${class_name_def}" 1 ${last_char_pos}`
}

# browse_files
# Looks for all files in a folder to match the file in $1 with extension $2.
# - $1: file to find
# - $2: file extension
function browse_files
{
  if [[ -z $1 ]] || [[ -z $2 ]]
  then
    kill_exit "ERROR: browse_files missing input parameters"
  fi

  local my_file=$1
  local ext=$2
  local ls_file=

  # for all files in current directory
  for ls_file in `ls`
  do
  # check if file extension is the same
  if [[ ${ls_file##*.} =  ${ext} ]]
  then
    # check if filename is the same
    if [[ ${my_file} = ${ls_file} ]]
    then
    file_path=`pwd`
    found_it=true
    break
    fi
  fi
  done
}

# find_ros_message
# Validates existance of the given ros message type file in $1 with 
# extension $2. When $2=action then looks for the 7 .msg created files.
# Adds message package to project package.xml if required.
# - $1: name of the ros message file to find
# - $2: type of the ros message file: msg, srv or action
# - $3: name of the ros pkg who wants to search the file
#       (for searching package.xml to add dependency)
function find_ros_message
{
  if [[ -z $1 ]] || [[ -z $2 ]] || [[ -z $3 ]]
  then
    kill_exit "ERROR: find_ros_message: missing input parameters"
  fi

  # read input parameters
  my_file=$1
  local ext=$2
  local ros_pkg=$3
  local ros_out=
  local my_file_tmp=
  found_it=true

  if [[ ${ext} = "msg" ]] || [[ ${ext} = "srv" ]]
  then
    if [[ ${my_file} == */* ]]
    then
      my_file_tmp="${my_file%.*}" #extract extension
      ros_out=`eval "ros${ext} list | grep ${my_file_tmp}$"`
    else
      my_file_tmp="${my_file%.*}" #extract extension
      ros_out=`eval "ros${ext} list | grep /${my_file_tmp}$"`
    fi
  else
    #action file
    ros_out=`eval "rosmsg show ${my_file}Action"`

    local act_msgs="${my_file}Action ${my_file}ActionFeedback ${my_file}ActionGoal ${my_file}ActionResult ${my_file}Feedback ${my_file}Goal ${my_file}Result"
    for am in ${act_msgs}
    do
      ros_out=`eval "rosmsg list | grep ${am}"`
      #ros_out=`eval "rosmsg show ${am}"`
      if [[ -z "${ros_out}" ]]
      then
        found_it=false
        break
      fi
    done
  fi

  if [[ -n "${ros_out}" ]]
  then
    found_it=true

    if [[ ${my_file} == */* ]]
    then
      local parsed_name=$(echo ${my_file} | sed 's/\// /g')
      file_pkg=${parsed_name%% *}
      my_file=${parsed_name##* }
    else
      file_pkg=
    fi

    if [[ -z ${file_pkg} ]]
    then
      file_pkg=(`echo ${ros_out} | tr '[' ' ' | tr ']' ' ' | tr '/' ' '`)
      lines_found=`echo "$ros_out" | wc -l`
      if [[ $lines_found != 1 ]]
      then
        echo "WARNING: Found multiple packages ($lines_found) containing the same message filename ($my_file), using the one that appears first., ($file_pkg)"
      fi
    fi
  else
    found_it=false
  fi
}

# # add_pkg_dependency_to_readme
# # Adds $2 as dependency to README.md file.
# # - $1: current ros package
# # - $2: message ros package
# function add_pkg_dependency_to_readme
# {
#   if [[ -z $1 ]] || [[ -z $2 ]]
#   then
#     kill_exit "ERROR: add_pkg_dependency_to_readme: missing input parameters"
#   fi
# 
#   local ros_pkg=$1
#   local file_pkg=$2
# 
#   #go to package folder
#   roscd "${ros_pkg}"
#   
#   file=README.md
#   line="\- ${file_pkg}"
#   comment="## Dependencies"
#   add_line_to_file "${line}" "${comment}" "${file}"
# }

# fill_readme_ros_interface
# Adds ROS interface type $1/$2 to README.md from $2 package, as a $3 name and $4/$5 type
# - $1: interface type: topic, service, action
# - $2: interface subtype: publisher/subscriber, client/server, client/server
# - $3: current ros package
# - $4: interface name
# - $5: interface package
# - $6: interface message
function fill_readme_ros_interface # ${type} ${pub_subs} ${ros_pkg} ${topic_name} ${file_pkg} ${msg_file} ${absolute_ns}
{
  if [[ -z $1 ]] || [[ -z $2 ]] || [[ -z $3 ]] || [[ -z $4 ]] || [[ -z $5 ]] || [[ -z $6 ]]
  then
    kill_exit "ERROR: fill_readme_ros_interface missing input parameters"
  fi

  #echo "fill_readme_ros_interface $1 $2 $3 $4 $5 $6"
  local if_type=$1
  local if_subtype=$2
  local ros_pkg=$3
  local if_name=$4
  local if_pkg=$5
  local if_msg=$6
  local absolute_ns=$7  
  
  roscd "${ros_pkg}"
  
  local file=README.md
  local line=""
  local comment=""
  
  echo "Filling $file with ROS Interfaces information..."

  if [ "$absolute_ns" = true ]
  then
    line="  - /**$if_name** ($if_pkg/$if_msg)"
  else
    line="  - ~**$if_name** ($if_pkg/$if_msg)"
  fi
  
  case "$if_type" in
  "topic")

      case "$if_subtype" in
      "publisher")
        comment="### Topic publishers"
        ;;
      "subscriber")
        comment="### Topic subscribers"
        ;;
      "broadcaster")
        comment="### Topic publishers"
        ;;
      "listener")
        comment="### Topic subscribers"
        ;;
      esac
      ;;
  "service")
      case "$if_subtype" in
      "client")
        comment="### Service clients"
        ;;
      "server")
        comment="### Service servers"
        ;;
      esac
      ;;
  "action")
      case "$if_subtype" in
      "client")
        comment="### Action clients"
        ;;
      "server")
        comment="### Action servers"
        ;;
      esac
      ;;
  esac
  
  add_line_to_file "${comment}" "# ROS Interface" "${file}"

  add_line_to_file "${line}" "${comment}" "${file}"
}

# find_comment_in_file
# Searches for $1 in $2. Returns true if found.
# - $1: line to be found in file
# - $2: text file name
function find_comment_in_file
{
  if [[ -z $1 ]] || [[ -z $2 ]]
  then
    kill_exit "ERROR: find_comment_in_file: missing input parameters"
  fi

  local comment_to_find=$1
  local file=$2
  comment_found="true"

  #look for key comment
  local comm_found=$(grep -n "${comment_to_find}" "${file}")
  if [[ -z "${comm_found}" ]]
  then
    comment_found="false"
  else
    line_number=${comm_found%%:*}
  fi
}

# text_found_in_file
# Searches for $1 in $2. text_found is true if found.
# - $1: text to be found in file
# - $2: text file name
function text_found_in_file
{
  if [[ -z $1 ]] || [[ -z $2 ]]
  then
    kill_exit "ERROR: text_found_in_file missing input parameters"
  fi

  local text_to_find=$1
  local file=$2

  #look for key line
  local found=$(grep -n "${text_to_find}" "${file}")
  if [[ -n "${found}" ]]
  then
    text_found="true"
  else
    text_found="false"
  fi
}

# add_line_to_file
# Looks for comment line $2 in $3 file. If found, places line $1 after comment.
# If comment is not found, exits script. If $1 already exists, skips adding it 
# again.
# - $1: line to be added
# - $2: comment to be found
# - $3: text file name
function add_line_to_file
{
  #echo "add_line_to_file $1 $2 $3"
  if [[ -z $1 ]] || [[ -z $2 ]] || [[ -z $3 ]]
  then
    kill_exit "ERROR: add_line_to_file: missing input parameters"
  fi

  local line_to_add=$1
  local comment_to_find=$2
  local file=$3

  #look for key comment
  find_comment_in_file "${comment_to_find}" "${file}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: File ${file} needs to be restored, missing comment: \"${comment_to_find}\""
  fi

  #check if line already exists in file
  local line_found=$(grep "^${line_to_add}" "${file}")

  if [[ -z "${line_found}" ]]
  then
    #echo "Adding line after comment: ${line_to_add} after ${comment_to_find}"
    sed -i -e "/${comment_to_find}/a\\${line_to_add}" "${file}"
  else
    #skip line
    echo "File ${file} already included the line, skipping..."
  fi
}

# get_h_cpp_files
# Looks for header files in include folder, if empty looks for headers files
# in include/pkg_name folder.
# Assumes that if headers files are in include/pkg_name, the source code is
# in the same header file
# - $1: pkg name
function get_h_cpp_files
{
  if [[ -z $1 ]]
  then
    kill_exit "ERROR: get_h_cpp_files: missing input parameters"
  fi

  local ros_pkg=$1
  node_h=""
  node_c=""
  roscd "${ros_pkg}"

  if [[ -z `ls -l "include/" | grep "^-" | grep "\.h$"` ]]
  then
    if [[ -z `ls -l "include/${ros_pkg}" | grep "^-" | grep "\.h$"` ]]
    then
      kill_exit "ERROR: no include files found!"
    else
      node_h=$( ls "include/${ros_pkg}" | grep "\node.h$" )
      node_h="include/${ros_pkg}/${node_h}"
      node_c=${node_h}
    fi
  else
    node_h=$( ls "include/" | grep "\node.h$" )
    node_h="include/${node_h}"
    node_c=$( ls "src/" | grep "\node.cpp$" )
    node_c="src/${node_c}"
  fi
}

function is_driver_or_alg_node
{
  if [[ -z $1 ]]
  then
    kill_exit "ERROR: is_driver_or_alg_node: missing input parameters"
  fi

  local ros_pkg=$1
  roscd "${ros_pkg}"

  find_comment_in_file "IriBaseAlgorithm" "${node_h}"
  if [[ ${comment_found} = "true" ]]
  then
    driver_alg="alg"
  else
    find_comment_in_file "IriBaseDriver" "${node_h}"
    if [[ ${comment_found} = "true" ]]
    then
      driver_alg="driver"
    else
      driver_alg=""
      kill_exit "Could not found whether this pkg is a Driver or Algorithm"
    fi
  fi
}

function change_license_to_LGPL
{
  find . -name package.xml -exec sed -i -e 's:<license>.*</license>:<license>LGPL</license>:g' {} \;
}

function change_maintainer_email_domain_to_iri_upc_edu
{
  find . -name package.xml -exec sed -i -e 's:@todo.todo:@iri.upc.edu:g' {} \;
}

function goto_catkin_workspace
{
  roscd
  if [[ -f .catkin ]]
  then
    cd .. # to catkin work space
  else
    setup_line=$(grep "setup-file" ".rosinstall")
    ros_path=$(sed -n 's/.*- setup-file: {local-name: \(.*\)devel.*/\1/p' <<< ${setup_line})
    cd ${ros_path}
  fi
}

function check_package_file_integrity
{
  local driver_alg=$1
  local comment=""
  
  local type
  
  local build_depend="false"
  local run_depend="false"
  local depend="false"
  local exec_depend="false"

  
  if [[ "${driver_alg}" = "driver" ]]
  then
    type="driver"
  else
    type="algorithm"
  fi

  comment="<build_depend>iri_base_${type}</build_depend>"
  text_found_in_file "${comment}" "package.xml"
  if [[ "${text_found}" = "true"  ]]
  then
    build_depend=true
  fi
  
  comment="<depend>iri_base_${type}</depend>"
  text_found_in_file "${comment}" "package.xml"
  if [[ "${text_found}" = "true"  ]]
  then
    depend=true
  fi

  comment="<exec_depend>iri_base_${type}</exec_depend>"
  text_found_in_file "${comment}" "package.xml"
  if [[ "${text_found}" = "true"  ]]
  then
    exec_depend="true"
  fi
  
  comment="<run_depend>iri_base_${type}</run_depend>"
  text_found_in_file "${comment}" "package.xml"
  if [[ "${text_found}" = "true"  ]]
  then
    run_depend="true"
  fi
  
  comment="<package format=\"2\">"
  text_found_in_file "${comment}" "package.xml"
  if [[ "${text_found}" = "true"  ]]
  then
    if [[ $build_depend != "true" || $exec_depend != "true" ]]; then
      if [[ "$depend"!="true" ]]
      then
        kill_exit "Exit. Missing iri_base_$type <build_depend> or <exec_depend> on package.xml (format 2)"
      fi
    fi
  else #format 1: <package>
    if [ "$build_depend" != "true" ] || [ "$run_depend" != "true" ]; then
      kill_exit "Exit. Missing iri_base_$type <build_depend> or <run_depend> on package.xml (format 1)"
    fi
  fi
}

function check_cmakelists_file_integrity
{
  local driver_alg=$1
  local comment=""
  local old_line=""

  old_line=$(grep "find_package(catkin REQUIRED COMPONENTS" "CMakeLists.txt")
  if [[ "${driver_alg}" = "driver" ]]
  then
    if [[ $old_line != *iri_base_driver* ]]
    then
      kill_exit "Missing iri_base_driver in the catkin REQUIRED COMPONENTS list in file CMakeLists.txt.  (multiline not supported)"
    fi
  else
    if [[ $old_line != *iri_base_algorithm* ]]
    then
      kill_exit "Missing iri_base_algorithm in the catkin REQUIRED COMPONENTS list in file CMakeLists.txt. (multiline not supported)"
    fi
  fi
  comment="add_dependencies(\${PROJECT_NAME} <msg_package_name>_generate_messages_cpp)"
  find_comment_in_file "${comment}" "CMakeLists.txt"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "Missing add_dependencies(\${PROJECT_NAME} <msg_package_name>_generate_messages_cpp) from the CMakeLists.txt file"
  fi
}

function add_build_run_dependencies
{
  local driver_alg=$1
  local ros_pkg=$2
  local new_pkg=$3
  local line=""
  local comment=""
  
  local type=
  local dep=
  local dep2="build_depend"
  local dep3="exec_depend"
  
  if [[ "${driver_alg}" = "driver" ]]
  then
    type="driver"
  else
    type="algorithm"
  fi

  if [[ "${new_pkg}" != "${ros_pkg}" ]]
  then
  
    comment="<package format=\"2\">"
    text_found_in_file "${comment}" "package.xml"
    if [[ "${text_found}" = "true"  ]]
    then
      dep="depend"
      line="^\s*<${dep}>${new_pkg}</${dep}>"
      find_comment_in_file "${line}" "package.xml"
      if [[ "${comment_found}" = "false" ]]
      then
        echo "Adding $new_pkg $dep to package.xml"
        line="\ \ <${dep}>${new_pkg}<\/${dep}>"
        comment="<${dep3}>iri_base_${type}<\/${dep3}>"
        add_line_to_file "${line}" "${comment}" "package.xml"
      else
        echo "$dep dependency for $new_pkg already included in package.xml"
      fi
    else #format 1: <package>
      dep="build_depend"
      line="<${dep}>${new_pkg}</${dep}>"
      find_comment_in_file "${line}" "package.xml"
      if [[ "${comment_found}" = "false" ]]
      then
        line="\ \ <${dep}>${new_pkg}<\/${dep}>"
        comment="<${dep2}>iri_base_${type}<\/${dep2}>"
        add_line_to_file "${line}" "${comment}" "package.xml"
      else
        echo "$dep dependency for $new_pkg already included in package.xml"
      fi
      
      dep="run_depend"
      line="<${dep}>${new_pkg}</${dep}>"
      find_comment_in_file "${line}" "package.xml"
      if [[ "${comment_found}" = "false" ]]
      then
        line="\ \ <${dep}>${new_pkg}<\/${dep}>"
        comment="<${dep2}>iri_base_${type}<\/${dep2}>"
        add_line_to_file "${line}" "${comment}" "package.xml"
      else
        echo "$dep dependency for $new_pkg already included in package.xml"
      fi
    fi
    
    #add_pkg_dependency_to_readme $ros_pkg $new_pkg

  fi
}

function add_cmake_dependencies
{
  local driver_alg=$1
  local ros_pkg=$2
  local new_pkg=$3
  local line=""
  local old_line=""
  local comment=""
  local old_string=""
  local new_string=""

  if [[ "${new_pkg}" != "${ros_pkg}" ]]
  then
    old_line=$(grep "find_package(catkin REQUIRED COMPONENTS" "CMakeLists.txt")
    if [[ $old_line == *${new_pkg}* ]]
    then
      echo "Dependency already included in CMakeLists.txt file.";
    else
      if [[ "${driver_alg}" = "driver" ]]
      then
        old_string="iri_base_driver"
      else
        old_string="iri_base_algorithm"
      fi
      new_string="${old_string}\ ${new_pkg}"
      sed -i -e "/find_package/ s/${old_string}/${new_string}/g" "CMakeLists.txt"
      sed -i -e "/CATKIN_DEPENDS/ s/${old_string}/${new_string}/g" "CMakeLists.txt"
    fi

    line="add_dependencies(\${PROJECT_NAME} ${new_pkg}_generate_messages_cpp)"
    comment="add_dependencies(\${PROJECT_NAME} <msg_package_name>_generate_messages_cpp)"
    add_line_to_file "${line}" "${comment}" "CMakeLists.txt"
  fi
}

# 11. Bash File Testing
# -b filename   Block special file
# -c filename   Special character file
# -d directoryname  Check for directory existence
# -e filename   Check for file existence
# -f filename   Check for regular file existence not a directory
# -G filename   Check if file exists and is owned by effective group ID.
# -g filename   true if file exists and is set-group-id.
# -k filename   Sticky bit
# -L filename   Symbolic link
# -O filename   True if file exists and is owned by the effective user id.
# -r filename   Check if file is a readable
# -S filename   Check if file is socket
# -s filename   Check if file is nonzero size
# -u filename   Check if file set-ser-id bit is set
# -w filename   Check if file is writable
# -x filename   Check if file is executable
# -n variable   Check if variable is not null (contains one or more characaters)
# -z variable   Check if variable is null (empty)