#!/bin/bash

# check wether the scripts path environment variable has been defined
scripts_path=`echo "${IRI_ROS_SCRIPTS_PATH}"`
if [[ -z "${scripts_path}" ]]
then
  echo "ERROR: The scripts path environment variable has not been defined. Please see the wiki documentation for instructions on how to create it."
  exit
# else
#   echo "The scripts path environment variable has been properly defined."
fi

source "${IRI_ROS_SCRIPTS_PATH}/libraries/scripts_library.sh"

function check_publisher_file_integrity
{
  local node_h=$1
  local node_c=$2
  local comment=""

  # check the node.h file
  comment="\[publisher subscriber headers\]"
  find_comment_in_file "${comment}" "${node_h}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[publisher subscriber headers\] from the header file ${node_h}"
  fi
  comment="\[publisher attributes\]"
  find_comment_in_file "${comment}" "${node_h}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[publisher attributes\] from the header file ${node_h}"
  fi

  # check the node.cpp file
  comment="\[init publishers\]"
  find_comment_in_file "${comment}" "${node_c}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[init publishers\] from the header file ${node_c}"
  fi
  comment="\[fill msg structures\]"
  find_comment_in_file "${comment}" "${node_c}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[fill msg structures\] from the header file ${node_c}"
  fi

  comment="\[publish messages\]"
  find_comment_in_file "${comment}" "${node_c}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[publish messages\] from the header file ${node_c}"
  fi
}

function check_publisher_attributes_functions
{
  local node_h=$1
  local node_c=$2
  local broadcaster_name=$3
  local line=""

  # check the node.h file
  line="tf::TransformBroadcaster ${broadcaster_name};"
  find_comment_in_file "${line}" "${node_h}"
  if [[ "${comment_found}" = "true" ]]
  then
    kill_exit "ERROR: A TF broadcaster with the same name is already declared in file ${node_h} line ${line_number}"
  fi

  line="geometry_msgs::TransformStampd transform_msg_;"
  find_comment_in_file "${line}" "${node_h}"
  if [[ "${comment_found}" = "true" ]]
  then
    kill_exit "ERROR: A message variable with the same name is already declared in file ${node_h} line ${line_number}"
  fi

  # check the node.cpp file
  line="this->${broadcaster_name}.sendTransform(this->transform_msg_);"
  find_comment_in_file "${line}" "${node_c}"
  if [[ "${comment_found}" = "true" ]]
  then
    kill_exit "ERROR: A message with the same name is already published in file ${node_c} line ${line_number}"
  fi
}

function create_tf_broadcaster
{
  #read input params
  local ros_pkg=$1
  local node_h=$2
  local node_c=$3
  local driver_alg=$4
  local broadcaster_name="tf_broadcaster_"
  local line=""
  local old_line=""
  local aux_line=""
  local comment=""
  local old_string=""
  local new_string=""

  #get class basename
  get_class_basename "${node_c}"
  if [[ -z ${class_name} ]]
  then
    kill_exit "ERROR: impossible to retrieve class basename"
  fi

  #check files integrity before making any changes
  check_package_file_integrity "${driver_alg}"
  check_cmakelists_file_integrity "${driver_alg}"
  check_publisher_file_integrity "${node_h}" "${node_c}"
  check_publisher_attributes_functions "${node_h}" "${node_c}" "${broadcaster_name}"

################################################################################
# modify Node.h #

  #look for include files and add them if are not already there
  line="#include <tf/transform_broadcaster.h>"
  comment="\[publisher subscriber headers\]"
  add_line_to_file "${line}" "${comment}" "${node_h}"

  # add the message type variable
  aux_line="geometry_msgs::TransformStamped transform_msg_;"
  line="\ \ \ \ ${aux_line}\n"
  comment="\[publisher attributes\]"
  add_line_to_file "${line}" "${comment}" "${node_h}"

  aux_line="tf::TransformBroadcaster tf_broadcaster_;"
  line="\ \ \ \ ${aux_line}"
  comment="\[publisher attributes\]"
  add_line_to_file "${line}" "${comment}" "${node_h}"


################################################################################
# modify Node.cpp #

  comment="\[publish messages\]"

  line="\n"
  aux_line="/*"
  line="${line}\ \ ${aux_line}\n"
  aux_line="//tf_broadcaster example"
  line="${line}\ \ ${aux_line}\n"
  aux_line="this->transform_msg_.header.stamp    = ros::Time::now();"
  line="${line}\ \ ${aux_line}\n"
  aux_line="this->transform_msg_.header.frame_id = \"parent_frame\";"
  line="${line}\ \ ${aux_line}\n"
  aux_line="this->transform_msg_.child_frame_id  = \"child_frame\";"
  line="${line}\ \ ${aux_line}\n"
  aux_line="geometry_msgs::Transform t;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="t.translation.x = 0.0;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="t.translation.y = 0.0;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="t.translation.z = 0.0;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="t.rotation = tf::createQuaternionMsgFromYaw(0.0);"
  line="${line}\ \ ${aux_line}\n"
  aux_line="this->transform_msg_.transform = t;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="this->tf_broadcaster_.sendTransform(this->transform_msg_);"
  line="${line}\ \ ${aux_line}\n"
  aux_line="///tf_broadcaster example"
  line="${line}\ \ ${aux_line}\n"
  aux_line="*/"
  line="${line}\ \ ${aux_line}\n"
  
  add_line_to_file "  ${line}" "${comment}" "${node_c}"

################################################################################
# Modify package.xml
# check if the message package is the current ros package

  add_build_run_dependencies "${driver_alg}" "${ros_pkg}" "tf"

################################################################################
# modify the CMakeLists.txt file

  add_cmake_dependencies "${driver_alg}" "${ros_pkg}" "tf"

################################################################################
#compile
  goto_catkin_workspace
  catkin_make --only-pkg-with-deps ${ros_pkg}
}
