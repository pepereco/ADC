#!/bin/bash

# check wether the scripts path environment variable has been defined
scripts_path=`echo "${IRI_ROS_SCRIPTS_PATH}"`
if [[ -z "${scripts_path}" ]]
then
  echo "ERROR: The scripts path environment variable has not been defined. Please see the wiki documentation for instructions on how to create it."
  exit
# else
#   echo "The scripts path environment variable has been properly defined."
fi

source "${IRI_ROS_SCRIPTS_PATH}/libraries/scripts_library.sh"

function check_subscriber_file_integrity
{
  local node_h=$1
  local node_c=$2
  local comment=""

  # check node.h file
  comment="\[publisher subscriber headers\]"
  find_comment_in_file "${comment}" "${node_h}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[publisher subscriber headers\] from the header file ${node_h}"
  fi
  comment="\[subscriber attributes\]"
  find_comment_in_file "${comment}" "${node_h}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[subscriber attributes\] from the header file ${node_h}"
  fi

  # check node.cpp file
  comment="\[init subscribers\]" 
  find_comment_in_file "${comment}" "${node_c}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[init subscribers\] from the header file ${node_c}"
  fi
  comment="\[subscriber callbacks\]"
  find_comment_in_file "${comment}" "${node_c}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[subscriber callbacks\] from the header file ${node_c}"
  fi
  comment="\[free dynamic memory\]"
  find_comment_in_file "${comment}" "${node_c}"
  if [[ "${comment_found}" = "false" ]]
  then
    kill_exit "ERROR: Missing \[free dynamic memory\] from the header file ${node_c}"
  fi
}

function check_subscriber_attributes_functions
{
  local node_h=$1
  local node_c=$2
  local listener_name=$3
  local class_name=$4
  local line=""

  # check node.h file

  line="tf::TransformListener ${listener_name};"
  find_comment_in_file "${line}" "${node_h}"
  if [[ "${comment_found}" = "true" ]]
  then
    kill_exit "ERROR: A TF listener with the same name is already declared in file ${node_h} line ${line_number}"
  fi

  # check node.cpp file
  
}

function create_tf_listener
{
  #read input params
  local ros_pkg=$1
  local node_h=$2
  local node_c=$3
  local driver_alg=$4
  local listener_name="tf_listener_"
  local line=""
  local old_line=""
  local aux_line=""
  local comment=""
  local old_string=""
  local new_string=""

  #get class basename
  get_class_basename "${node_c}"
  if [[ -z ${class_name} ]]
  then
    kill_exit "ERROR: impossible to retrieve class basename"
  fi
# echo "class_name=${class_name}"

  #check files integrity before making any changes
  check_package_file_integrity "${driver_alg}"
  check_cmakelists_file_integrity "${driver_alg}"
  check_subscriber_file_integrity "${node_h}" "${node_c}"
  check_subscriber_attributes_functions "${node_h}" "${node_c}" "${listener_name}" "${class_name}"

  local obj=""
  if [[ "${driver_alg}" = "driver" ]]
  then
    obj="this->driver_."
  else
    obj="this->alg_."
  fi

################################################################################
# modify Node.h #

  line="#include <tf/transform_listener.h>"
  comment="\[publisher subscriber headers\]"
  add_line_to_file "${line}" "${comment}" "${node_h}"


  aux_line="tf::TransformListener ${listener_name};"
  line="\ \ \ \ ${aux_line}\n"
  comment="\[subscriber attributes\]"
  add_line_to_file "${line}" "${comment}" "${node_h}"

################################################################################
# modify Node.cpp #

  comment="\[fill msg structures\]"
  
  line="\n"
  aux_line="/*"
  line="${line}\ \ ${aux_line}\n"
  aux_line="//tf_listener example BEGIN"
  line="${line}\ \ ${aux_line}\n"
  aux_line="try{"
  line="${line}\ \ ${aux_line}\n"
  aux_line="  std::string target_frame             = \"child_frame\";"
  line="${line}\ \ ${aux_line}\n"
  aux_line="  std::string source_frame             = \"parent_frame\";"
  line="${line}\ \ ${aux_line}\n"
  aux_line="  ros::Time time                       = ros::Time::now();"
  line="${line}\ \ ${aux_line}\n"
  aux_line="  ros::Duration timeout                = ros::Duration(0.1);"
  line="${line}\ \ ${aux_line}\n"
  aux_line="  ros::Duration polling_sleep_duration = ros::Duration(0.01);"
  line="${line}\ \ ${aux_line}\n"
  
  aux_line="  ${obj}unlock();"
  line="${line}\ \ ${aux_line}\n"

  aux_line="  bool tf_exists = this->tf_listener_.waitForTransform(target_frame, source_frame, time, timeout, polling_sleep_duration);"
  line="${line}\ \ ${aux_line}\n"
  
  aux_line="  ${obj}lock();"
  line="${line}\ \ ${aux_line}\n"

  aux_line="  if(tf_exists){"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    geometry_msgs::PoseStamped stamped_pose_in;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    stamped_pose_in.header.stamp     = time;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    stamped_pose_in.header.frame_id  = source_frame;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    stamped_pose_in.pose.position.x    = 1.0;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    stamped_pose_in.pose.position.y    = 0.0;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    stamped_pose_in.pose.position.z    = 0.0;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    stamped_pose_in.pose.orientation = tf::createQuaternionMsgFromYaw(0.0);"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    ROS_INFO(\"Original    pose in '%s' frame, with (x,y,z)=[%f,%f,%f], yaw=[%f]\", stamped_pose_in.header.frame_id.c_str(), stamped_pose_in.pose.position.x, stamped_pose_in.pose.position.y, stamped_pose_in.pose.position.z, tf::getYaw(stamped_pose_in.pose.orientation));"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    geometry_msgs::PoseStamped stamped_pose_out;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    this->tf_listener_.transformPose(target_frame, stamped_pose_in, stamped_pose_out);"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    ROS_INFO(\"Transformed pose in '%s'  frame, with (x,y,z)=[%f,%f,%f], yaw=[%f]\", stamped_pose_out.header.frame_id.c_str(), stamped_pose_out.pose.position.x, stamped_pose_out.pose.position.y, stamped_pose_out.pose.position.z, tf::getYaw(stamped_pose_out.pose.orientation));"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    ROS_INFO(\"---\");"
  line="${line}\ \ ${aux_line}\n"
  aux_line="\n"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    tf::StampedTransform tf_parent_child;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    tf::Transform tf_parent_point, tf_child_point;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    this->tf_listener_.lookupTransform(source_frame, target_frame, time, tf_parent_child);"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    tf_parent_point.setOrigin(tf::Vector3(stamped_pose_in.pose.position.x, stamped_pose_in.pose.position.y, stamped_pose_in.pose.position.z));"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    tf_parent_point.setRotation(tf::Quaternion(stamped_pose_in.pose.orientation.x, stamped_pose_in.pose.orientation.y, stamped_pose_in.pose.orientation.z, stamped_pose_in.pose.orientation.w));"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    tf_child_point = tf_parent_child.inverse()*tf_parent_point;"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    ROS_INFO(\"Transformed pose in '%s'  frame, with (x,y,z)=[%f,%f,%f], yaw=[%f]\", target_frame.c_str(), tf_child_point.getOrigin().x(), tf_child_point.getOrigin().y(), tf_child_point.getOrigin().z(), tf::getYaw(tf_child_point.getRotation()));"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    ROS_INFO(\"---\");"
  line="${line}\ \ ${aux_line}\n"

  aux_line="  }else{"
  line="${line}\ \ ${aux_line}\n"
  aux_line="    ROS_WARN(\"No transform found from '%s' to '%s'\", source_frame.c_str(), target_frame.c_str()); }"
  line="${line}\ \ ${aux_line}\n"
  aux_line="}catch (tf::TransformException &ex){"
  line="${line}\ \ ${aux_line}\n"
  aux_line="  ROS_ERROR(\"TF Exception: %s\",ex.what()); }"
  line="${line}\ \ ${aux_line}\n"
  aux_line="///tf_listener example END"
  line="${line}\ \ ${aux_line}\n"
  aux_line="*/"
  line="${line}\ \ ${aux_line}\n"
  
  add_line_to_file "  ${line}" "${comment}" "${node_c}"

################################################################################
# Modify package.xml
# check if the message package is the current ros package

  add_build_run_dependencies "${driver_alg}" "${ros_pkg}" "tf"

################################################################################
# modify the CMakeLists.txt file
# check if the message package is the current ros package

  add_cmake_dependencies "${driver_alg}" "${ros_pkg}" "tf"

################################################################################
#compile
  goto_catkin_workspace
  catkin_make --only-pkg-with-deps ${ros_pkg}
}
