#!/bin/bash
# Distributed under the terms of the GNU General Public License v2
# Author: Jose Luis Rivero <jrivero@iri.upc.edu>
#
# Usage: inside a stack directory run irilize.sh
# This will scan all ROS pkgs dirs and check if the prefix iri is
# currently being in use and if _node suffix is being used. 
# If this occurs, it will change to add the preffix and remove the
# suffix. References to this name all across the repo will be fixed.

REPO_ROOT=${IRI_ROS_STACK_PATH}

if [[ -z ${REPO_ROOT} ]]; then
    echo "IRI_ROS_STACK_PATH not found"
    exit 1
fi

get_dirs()
{
    echo $(find . -maxdepth 1 -type d -not -name ".*")
}

check_stack()
{
    $(test -f ./stack.xml) && return 0
    return 1
}

has_iri_prefix()
{
    local filename=${1}

    [[ ${filename#iri_} == ${filename} ]] && return 1
    return 0
}

has_node_suffix()
{
    local filename=${1}

    [[ ${filename%_node} == ${filename} ]] && return 1
    return 0
}

check_pkg_directory()
{
    local path=${1}

    $(test -f ${path}/manifest.xml) && return 0
    return 1
}

fix_references_launch_files()
{
    local old_name=${1} new_name=${2}

    echo "   # Scanning and patching launch file over repo"

    find . -name *.launch -exec sed -i \
             -e "s:to[[:space:]]*=[[:space:]]*\"${old_name}:to=\"${new_name}:g" \
             -e "s:pkg[[:space:]]*=[[:space:]]*\"${old_name}:pkg=\"${new_name}:g" \
             -e "s:name[[:space:]]*=[[:space:]]*\"${old_name}:name=\"${new_name}:g" \
             -e "s:([[:space:]]*find[[:space:]]*${old_name}:(find ${new_name}:g" {} \;
}

fix_references_manifest_dependencies()
{
    local old_name=${1} new_name=${2}

    echo "   # Scanning and patching manifest dependencies over repo"

    find . -name manifest.xml -exec sed -i \
            -e "s:${old_name}:${new_name}:g" {} \;
}

fix_references()
{
    local old_name=${1} new_name=${2}

    pushd ${REPO_ROOT} > /dev/null
    fix_references_launch_files ${old_name} ${new_name}
    fix_references_manifest_dependencies ${old_name} ${new_name}
    popd > /dev/null
}

fix_directory_content()
{
    local old_name=${1} new_name=${2}

    pushd ${new_name} >/dev/null
    # 1. Change CFG
    echo "   # Scanning and patching cfg pkg files"
    find . -name *.cfg -exec sed -i \
         -e "s:${old_name}:${new_name}:g" {} \;
    # 2. Change includes
    echo "   # Scanning and patching headers pkg files"
    find . -name *.h -exec sed -i \
         -e "/^#include/{s:${old_name}:${new_name}:}" \
         -e "/typedef.*Config/{s:${old_name}:${new_name}:}" {} \;

    popd >/dev/null
}

fix_filenames_iriprefix()
{
    if ( ! check_stack ); then
        echo " You are not on stack directory"
        return
    fi

    echo -n -e "* Stack directory detected \n\n"

    dirs=$(get_dirs)

    for dir in ${dirs}; do
        dirname=${dir#./}
        new_dirname=${dirname}

        if (! check_pkg_directory ${dir}); then
           echo " ? ${dirname} -- not a package directory"
           continue
        fi

        if ( ! has_iri_prefix ${dirname} ); then
           new_dirname="iri_${new_dirname}"
        fi

        if ( has_node_suffix ${dirname} ); then
           new_dirname="${new_dirname%_node}"
        fi

        if [[ $dirname == $new_dirname ]]; then
           echo " = ${dirname}"
        else
           echo " + ${dirname} -> ${new_dirname}"
           svn move ${dirname} ${new_dirname} >/dev/null
           fix_directory_content ${dirname} ${new_dirname}
           fix_references ${dirname} ${new_dirname}
        fi
        echo
   done
}

fix_filenames_iriprefix
