#include "template_alg.h"

TemplateAlg::TemplateAlg(void)
{
  pthread_mutex_init(&this->access_,NULL);
}

TemplateAlg::~TemplateAlg(void)
{
  pthread_mutex_destroy(&this->access_);
}

void TemplateAlg::config_update(Config& config, uint32_t level)
{
  this->lock();

  // save the current configuration
  this->config_=config;
  
  this->unlock();
}

// TemplateAlg Public API
