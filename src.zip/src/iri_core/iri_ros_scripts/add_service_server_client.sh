#!/bin/bash

echo "/*********************************************/"
echo "/*      Creating New ROS Server/Client       */"
echo "/*********************************************/"

# check wether the scripts path environment variable has been defined
scripts_path=`echo "${IRI_ROS_SCRIPTS_PATH}"`
if [[ -z "${scripts_path}" ]]
then
  echo "ERROR: The scripts path environment variable has not been defined. Please see the wiki documentation for instructions on how to create it."
  exit
# else
#   echo "The scripts path environment variable has been properly defined."
fi

source "${IRI_ROS_SCRIPTS_PATH}/libraries/scripts_library.sh"
source "${IRI_ROS_SCRIPTS_PATH}/libraries/create_server.sh"
source "${IRI_ROS_SCRIPTS_PATH}/libraries/create_client.sh"

check_libraries
check_templates

server_client=
ros_pkg=
service_name=
srv_file=

#check for input project name paramenter
while getopts “:o:p:s:m:” OPTION
do
  case $OPTION in
    o)
       server_client=$OPTARG
       ;;
    p)
       ros_pkg=$OPTARG
       ;;
    s)
       if echo "$OPTARG" | grep -q "/"; then
          kill_exit "ERROR: argument -$OPTION can't contain slash '/' characters"
          exit
       else
          service_name=$OPTARG
       fi
       ;;
    m)
       srv_file=$OPTARG
       ;;
    ?)
       echo "ERROR: invalid input argument ${OPTION}"
       kill_exit "Usage: add_service_server_client.sh -o [server,client] -p ros_pkg -s service_name -m service.srv"
       exit
       ;;
  esac
done

#check if publisher name parameter is filled up
if [ ! "${server_client}" ] || [ ! "${ros_pkg}" ] || [ ! "${service_name}" ] || [ ! "${srv_file}" ]
then
  echo "ERROR: Missing input parameters..."
  kill_exit "Usage: add_service_server_client.sh -o [server,client] -p ros_pkg -s service_name -m service.srv"
fi

#check server client parameter
if [[ ! "${server_client}" = "server" ]] && [[ ! "${server_client}" = "client" ]]
then
  kill_exit "ERROR: First parameter must be either \"server\" or \"client\", aborting ..."
fi

#check if package exists
check_package "${ros_pkg}"
if [[ ${pkg_exists} == true ]]
then
  roscd ${ros_pkg}
else
  kill_exit "ERROR: ROS package ${ros_pkg} does NOT exist yet, please first run iri_ros_create_package.sh"
fi

#validate file extension .srv
srv="srv"
ext=${srv_file##*.}
ext=$(echo ${ext} | tr "[:upper:]" "[:lower:]")

#check extension
if [[ ! "${ext}" = "${srv}" ]]
then
  kill_exit "ERROR: Wrong file extension, please provide a .srv file, aborting ..."
fi

#look for SRV file
find_ros_message ${srv_file} ${srv} ${ros_pkg}
if ${found_it}
then
  srv_file=${my_file}
  echo "SRV file ${srv_file} found!"
else
  kill_exit "ERROR: SRV file ${srv_file} does NOT exist, please check if file is in valid directories, aborting ..."
fi

#retrieve header and source files and pkg kind (algorithm/driver)
get_h_cpp_files ${ros_pkg}
is_driver_or_alg_node ${ros_pkg}
echo "node_h=${node_h}"
echo "node_c=${node_c}"
echo "driver_alg=${driver_alg}"

if [[ -z ${node_h} ]] || [[ -z ${node_c} ]] || [[ -z ${driver_alg} ]]
then
  kill_exit "ERROR: Problems found with headers and/or source files"
fi

#go to package folder
roscd "${ros_pkg}"

#modify readme with added ROS interface
type="service"
fill_readme_ros_interface ${type} ${server_client} ${ros_pkg} ${service_name} ${file_pkg} ${srv_file} "false"

#modify node files adding server/client parameters
if [[ "${server_client}" = "server" ]]
then
  create_server ${ros_pkg} ${service_name} ${srv_file%.srv} ${file_pkg} ${node_h} ${node_c} ${driver_alg}
else
  create_client ${ros_pkg} ${service_name} ${srv_file%.srv} ${file_pkg} ${node_h} ${node_c} ${driver_alg}
fi
