#!/bin/bash

echo "/**********************************************/"
echo "/* Creating New IRI_ROS Simple Algorithm Node */"
echo "/**********************************************/"

# check wether the scripts path environment variable has been defined
scripts_path=`echo "${IRI_ROS_SCRIPTS_PATH}"`
if [[ -z "${scripts_path}" ]]
then
  echo "ERROR: The scripts path environment variable has not been defined. Please see the wiki documentation for instructions on how to create it."
  exit
# else
#   echo "The scripts path environment variable has been properly defined."
fi

source "${IRI_ROS_SCRIPTS_PATH}/libraries/scripts_library.sh"

check_libraries
check_templates

usage="Usage: create_algorithm_package.sh -n node_name [-i] [-p <prefix>]\n
Parameters:\n
\t-i: avoid adding the default iri_ prefix to the provided node name.\n
\t-p <prefix>: replaces default iri_ prefix with specified <prefix>_."
input_name=""
use_iri_prefix=true
input_prefix=""

#check for input project name paramenter
while getopts “:n:ip:” OPTION
do
  case $OPTION in
    n)
       input_name=$OPTARG
       ;;
    i)
       use_iri_prefix=false
       ;;
    p)
       use_iri_prefix=false
       input_prefix=$OPTARG
       ;;
    ?)
       echo "ERROR: invalid argument $OPTION"
       kill_exit "${usage}"
       ;;
  esac
done

#check if project parameter is filled up
if [ ! "${input_name}" ]
then
  echo "ERROR: No project name provided, aborting ..."
  kill_exit "${usage}"
fi

#lowercase input name
input_name=$(echo ${input_name} | tr "[:upper:]" "[:lower:]")

#create alg filename
if [[ ${use_iri_prefix} == true ]]
then
  project_name="iri_${input_name}"
else
  if [[ "$input_prefix" != ""  ]]
  then
    project_name="${input_prefix}_${input_name}"
  else
    project_name="${input_name}"
  fi
fi

if [ -e "../${project_name}" ]
then
  kill_exit "${project_name} package directory already exists, aborting ..."
else
  echo "Generating folder structure for project ${project_name} ..."
fi

catkin_create_pkg ${project_name} iri_base_algorithm 
if [ $? -eq 0 ]
then
  echo "Package created successfully"
else
  exit 1;
fi

#create alg filename
alg_filename="${input_name}_alg"

#create node filename
node_filename="${input_name}_alg_node"

#create cfg filename
cfg_filename="${input_name}_alg_config"

#create basename from pkg name
create_basename ${input_name}

#create templates folder path name
temps_folder="${IRI_ROS_SCRIPTS_PATH}/algorithm_templates/"

################################################################################
# create template alg .h and .cpp files

#create alg basename
alg_basename="${basename}Algorithm"

mkdir -p ${project_name}/include/
mkdir -p ${project_name}/src/

#Set the filename and namespace on the template_alg files
sed -e "s/template_alg/${alg_filename}/g" \
    -e "s/TemplateAlg/${alg_basename}/g" \
    -e "s/template_namespace/${project_name}/g" \
    -e "s/TemplateConfig/${basename}Config/g" <${temps_folder}/template_alg.h >"${project_name}/include/${alg_filename}.h"
sed -e "s/template_alg/${alg_filename}/g" \
    -e "s/TemplateAlg/${alg_basename}/g" <${temps_folder}/template_alg.cpp >"${project_name}/src/${alg_filename}.cpp"
echo "Creating ${alg_filename}.h/cpp files..."
################################################################################



################################################################################
# create template node .h and .cpp files

#create node basename
node_basename="${basename}AlgNode"
#echo "node_basename $node_basename"

#Set the filename and namespace on the template_node files
sed -e "s/template_alg/${alg_filename}/g" \
    -e "s/TemplateAlg/${alg_basename}/g" \
    -e "s/template_node/${node_filename}/g" \
    -e "s/TemplateNode/${node_basename}/g" <${temps_folder}/template_alg_node.h >"${project_name}/include/${node_filename}.h"
sed -e "s/template_node/${node_filename}/g" \
    -e "s/TemplateAlg/${alg_basename}/g" \
    -e "s/TemplateNode/${node_basename}/g" <${temps_folder}/template_alg_node.cpp >"${project_name}/src/${node_filename}.cpp"
echo "Creating ${node_filename}.h/cpp files..."
################################################################################


################################################################################
#Set the filename and namespace on the CMakeLists.txt file
sed -e "s/template_alg/${alg_filename}/g" \
    -e "s/Template/${basename}/g" \
    -e "s/template_node/${project_name}/g" <${temps_folder}/CMakeLists.txt >"${project_name}/CMakeLists.txt"
echo "Creating ${project_name}/CMakeLists.txt file..."
################################################################################


################################################################################
#create cfg directory
cfg_dir="${project_name}/cfg"
if [ -e "$cfg_dir" ]
then
  echo "${cfg_dir} directory already exists, skipping ..."
else
  echo "Creating ${cfg_dir} directory"
  mkdir ${cfg_dir}
fi

#Set the filename and namespace on the template.cfg file
sed -e "s/template/${project_name}/g" \
    -e "s/TemplateAlg/${alg_basename}/g" \
    -e "s/template_node/${node_filename}/g" \
    -e "s/Template/${basename}/g" <${temps_folder}/template_alg.cfg >"${project_name}/cfg/${basename}.cfg"
eval "chmod 775 ${project_name}/cfg/${basename}.cfg"
echo "Creating ${cfg_dir}/${cfg_filename}.cfg file..."
################################################################################


################################################################################
#create launch/config directory
mkdir -p ${project_name}/launch/

sed -e "s/template/${project_name}/g" <${IRI_ROS_SCRIPTS_PATH}/common_templates/node.launch >"${project_name}/launch/node.launch"
sed -e "s/template/${project_name}/g" <${IRI_ROS_SCRIPTS_PATH}/common_templates/test.launch >"${project_name}/launch/test.launch"

mkdir -p ${project_name}/config/
cp ${IRI_ROS_SCRIPTS_PATH}/common_templates/params.yaml ${project_name}/config/params.yaml
################################################################################


################################################################################
#add license and readme
cp ${IRI_ROS_SCRIPTS_PATH}/common_templates/LICENSE ${project_name}/LICENSE

sed -e "s/template/${project_name}/g" < ${IRI_ROS_SCRIPTS_PATH}/common_templates/README.md > "${project_name}/README.md"
################################################################################
pushd "${project_name}" > /dev/null
change_license_to_LGPL
change_maintainer_email_domain_to_iri_upc_edu
popd > /dev/null
################################################################################
echo "Project ${project_name} has been successfully created!!"
echo ""
echo "Compiling workspace with: catkin_make --only-pkg-with-deps $project_name"
goto_catkin_workspace
catkin_make --only-pkg-with-deps ${project_name}