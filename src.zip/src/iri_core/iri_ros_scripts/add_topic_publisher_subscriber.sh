#!/bin/bash

echo "/*********************************************/"
echo "/*   Creating New ROS Publisher/Subscriber   */"
echo "/*********************************************/"

# check wether the scripts path environment variable has been defined
scripts_path=`echo "${IRI_ROS_SCRIPTS_PATH}"`
if [[ -z "${scripts_path}" ]]
then
  echo "ERROR: The scripts path environment varibale has not been defined. Please see the wiki documentation for instructions on how to create it."
  exit
# else
#   echo "The scripts path environment variable has been properly defined."
fi

source "${IRI_ROS_SCRIPTS_PATH}/libraries/scripts_library.sh"
source "${IRI_ROS_SCRIPTS_PATH}/libraries/create_publisher.sh"
source "${IRI_ROS_SCRIPTS_PATH}/libraries/create_subscriber.sh"

check_libraries
check_templates

pub_subs=
ros_pkg=
topic_name=
msg_file=
buffer=

#check for input project name paramenter
while getopts “:o:p:t:m:b:” OPTION
do
  case $OPTION in
    o)
       pub_subs=$OPTARG
       ;;
    p)
       ros_pkg=$OPTARG
       ;;
    t)
       if echo "$OPTARG" | grep -q "/"; then
          kill_exit "ERROR: argument -$OPTION can't contain slash '/' characters"
          exit
       else
          topic_name=$OPTARG
       fi
       ;;
    m)
       msg_file=$OPTARG
       ;;
    b)
       buffer=$OPTARG
       ;;
    ?)
       echo "ERROR: invalid input argument ${OPTION}"
       kill_exit "Usage: add_topic_publisher_subscriber.sh -o [publisher,subscriber] -p ros_pkg -t topic_name -m message.msg -b 1"
       exit
       ;;
  esac
done

#check if publisher name parameter is filled up
if [ ! "${pub_subs}" ] || [ ! "${ros_pkg}" ] || [ ! "${topic_name}" ] || [ ! "${msg_file}" ] || [ ! "${buffer}" ]
then
  echo "ERROR: Missing input parameters..."
  kill_exit "Usage: add_topic_publisher_subscriber.sh -o [publisher,subscriber] -p ros_pkg -t topic_name -m message.msg -b 1"
fi

#check publisher subscriber parameter
if [[ ! "${pub_subs}" = "publisher" ]] && [[ ! "${pub_subs}" = "subscriber" ]]
then
  kill_exit "ERROR: First parameter must be either \"publisher\" or \"subscriber\", aborting ..."
fi

#check if package exists
result=`roscd ${ros_pkg}`
if [[ -z "${result}" ]]
then
  roscd ${ros_pkg}
else
  kill_exit "ERROR: ROS package ${ros_pkg} does NOT exist yet, please first run iri_ros_create_package.sh"
fi

check_package "${ros_pkg}"
if [[ ${pkg_exists} == true ]]
then
  roscd ${ros_pkg}
else
  kill_exit "ERROR: ROS package ${ros_pkg} does NOT exist yet, please first run iri_ros_create_package.sh"
fi

#validate file extension .msg
msg="msg"
ext=${msg_file##*.}
ext=$(echo ${ext} | tr "[:upper:]" "[:lower:]")

#check extension
if [[ ! "${ext}" = "${msg}" ]]
then
  kill_exit "ERROR: Wrong file extension, please provide a .msg file, aborting ..."
fi

#look for MSG file
find_ros_message ${msg_file} ${msg} ${ros_pkg}
if ${found_it}
then
  msg_file=${my_file}
  echo "MSG file ${msg_file} found!"
else
  kill_exit "ERROR: MSG file ${msg_file} does NOT exist, please check if file is in valid directories, aborting ..."
fi

# Sanitize input and assign to new variable
export clean_buffer=`echo "${buffer}" | tr -cd '[:digit:]'`

#check if buffer parameter is filled up
if [ "$clean_buffer" ] && [ "$clean_buffer -gt 0" ]
then
  echo "Setting buffer length to $clean_buffer"
else
  kill_exit "ERROR: No buffer provided, aborting ..."  
fi

#retrieve header and source files and pkg kind (algorithm/driver)
get_h_cpp_files ${ros_pkg}
is_driver_or_alg_node ${ros_pkg}
echo "node_h=${node_h}"
echo "node_c=${node_c}"
echo "driver_alg=${driver_alg}"

if [[ -z ${node_h} ]] || [[ -z ${node_c} ]] || [[ -z ${driver_alg} ]]
then
  kill_exit "ERROR: Problems found with headers and/or source files"
fi

#go to package folder
roscd "${ros_pkg}"

#modify readme with added ROS interface
type="topic"
fill_readme_ros_interface ${type} ${pub_subs} ${ros_pkg} ${topic_name} ${file_pkg} ${msg_file} "false"

#modify node files adding server/client parameters
if [[ "${pub_subs}" = "publisher" ]]
then
  create_publisher  ${ros_pkg} ${topic_name} ${msg_file%.msg} ${file_pkg} ${buffer} ${node_h} ${node_c} ${driver_alg}
else
  create_subscriber ${ros_pkg} ${topic_name} ${msg_file%.msg} ${file_pkg} ${buffer} ${node_h} ${node_c} ${driver_alg}
fi
