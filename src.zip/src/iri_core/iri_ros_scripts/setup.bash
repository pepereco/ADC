#!/bin/bash

SCRIPT_PATH=`realpath "${BASH_SOURCE[0]}"`

export IRI_ROS_SCRIPTS_PATH=${SCRIPT_PATH%/*}
export PATH=${PATH}:${IRI_ROS_SCRIPTS_PATH}
