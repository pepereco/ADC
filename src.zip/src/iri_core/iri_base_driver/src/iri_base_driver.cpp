#include "iri_base_driver/iri_base_driver.h"

namespace iri_base_driver
{

IriBaseDriver::IriBaseDriver()
{
  this->current_state_=iri_base_driver::CLOSED;
  this->driver_id_="none";
  this->last_message="not operational yet";
  pthread_mutex_init(&this->access_,NULL);
  pthread_mutex_init(&this->internal_access_,NULL);
}

void IriBaseDriver::lock(void)
{
  pthread_mutex_lock(&this->access_);
}

void IriBaseDriver::unlock(void)
{
  pthread_mutex_unlock(&this->access_);
}

bool IriBaseDriver::try_enter(void)
{
  if(pthread_mutex_trylock(&this->access_)==0)
    return true;
  else
    return false;
}

void IriBaseDriver::setDriverId(const std::string & id)
{
  driver_id_ = id;
}

std::string IriBaseDriver::getID(void)
{
  return this->driver_id_;
}

bool IriBaseDriver::goState(state_t target_state)
{
  std::string transition;
  bool error=false;

  pthread_mutex_lock(&this->internal_access_);  
  try{
    do{
      switch(this->current_state_)
      {
        case iri_base_driver::CLOSED: if(target_state == iri_base_driver::OPENED || target_state == iri_base_driver::RUNNING)
                     {
                       transition="open";
                       ROS_DEBUG("Trying transition open from CLOSED to OPENED.");
                       if(this->openDriver())
                       {
                         this->current_state_=iri_base_driver::OPENED;
                         this->postOpenHook();
                         this->last_message="Transition open from CLOSED to OPENED succeeded.";
                         ROS_DEBUG("%s",this->last_message.c_str());
                       }
                       else
                       {
                         this->current_state_=iri_base_driver::CLOSED;
                         this->last_message="Transition open from CLOSED to OPENED failed.";
                         ROS_DEBUG("%s",this->last_message.c_str());
                         error=true;
                       }
                     }
                     else
                     {
                       this->current_state_=iri_base_driver::CLOSED;
                       this->last_message="No transition required";
                       ROS_DEBUG("%s",this->last_message.c_str());
                     }
                     break;
        case iri_base_driver::OPENED: if(target_state == iri_base_driver::CLOSED)
                     {
                       transition="close";
                       ROS_DEBUG("Trying transition close from OPENED to CLOSED.");
                       this->preCloseHook();
                       if(this->closeDriver())
                       {
                         this->current_state_=iri_base_driver::CLOSED;
                         this->last_message="Transition close from OPENED to CLOSED succeeded.";
                         ROS_DEBUG("%s",this->last_message.c_str());
                       }
                       else
                       {
                         this->current_state_=iri_base_driver::OPENED;
                         this->last_message="Transition close from OPENED to CLOSED failed.";
                         ROS_DEBUG("%s",this->last_message.c_str());
                         error=true;
                       }
                     }
                     else if(target_state == iri_base_driver::RUNNING)
                     {
                       transition="start";
                       ROS_DEBUG("Trying transition start from OPENED to RUNNING.");
                       if(this->startDriver())
                       {
                         this->current_state_=iri_base_driver::RUNNING;
                         this->last_message="Transition start from OPENED to RUNNING succeeded.";
                         ROS_DEBUG("%s",this->last_message.c_str());
                       }
                       else
                       {
                         this->current_state_=iri_base_driver::OPENED;
                         this->last_message="Transition start from OPENED to RUNNING failed.";
                         ROS_DEBUG("%s",this->last_message.c_str());
                         error=true;
                       }
                     }
                     else
                     {
                       this->current_state_=iri_base_driver::OPENED;
                       this->last_message="No transition required";
                       ROS_DEBUG("%s",this->last_message.c_str());
                     }
                     break;
        case RUNNING: if(target_state == iri_base_driver::OPENED || target_state == iri_base_driver::CLOSED)
                      {
                        transition="stop";
                        ROS_DEBUG("Trying transition stop from RUNNING to OPENED.");
                        if(this->stopDriver())
                        {
                          this->current_state_=iri_base_driver::OPENED;
                          this->last_message="Transition stop from RUNING to OPENED succeeded.";
                          ROS_DEBUG("%s",this->last_message.c_str());
                        }
                        else
                        {
                          this->current_state_=iri_base_driver::RUNNING;
                          this->last_message="Transition stop from RUNNING to OPENED failed.";
                          ROS_DEBUG("%s",this->last_message.c_str());
                          error=true;
                        }
                      }
                      else
                      {
                        this->current_state_=iri_base_driver::RUNNING;
                        this->last_message="No transition required";
                        ROS_DEBUG("%s",this->last_message.c_str());
                      }
                      break;
      }
    }while(!error && this->current_state_!=target_state);
  }catch(...){
    ROS_WARN("Caught exception in state transition %s\n",transition.c_str());
    error=true;
  }
  pthread_mutex_unlock(&this->internal_access_);  

  return error;
}

state_t IriBaseDriver::getState(void)
{
  return this->current_state_;
}

std::string IriBaseDriver::getStateName(void)
{
  switch(this->current_state_)
  {
    case iri_base_driver::CLOSED: return std::string("closed");
    case iri_base_driver::OPENED: return std::string("opened");
    case iri_base_driver::RUNNING: return std::string("running");
    default: return std::string("default value: not_possible");
  }
}

std::string IriBaseDriver::getStatusMessage(void)
{
  return this->last_message;
}

bool IriBaseDriver::isRunning(void)
{
  pthread_mutex_lock(&this->internal_access_);  
  if(this->current_state_ == iri_base_driver::RUNNING)
  {
    pthread_mutex_unlock(&this->internal_access_);  
    return true;
  }
  else
  {
    pthread_mutex_unlock(&this->internal_access_);  
    return false;
  }
}

bool IriBaseDriver::isOpened(void)
{
  pthread_mutex_lock(&this->internal_access_);  
  if(this->current_state_ == iri_base_driver::OPENED)
  {
    pthread_mutex_unlock(&this->internal_access_);  
    return true;
  }
  else
  {
    pthread_mutex_unlock(&this->internal_access_);  
    return false;
  }
}

bool IriBaseDriver::isClosed(void)
{
  pthread_mutex_lock(&this->internal_access_);  
  if(this->current_state_ == iri_base_driver::CLOSED)
  {
    pthread_mutex_unlock(&this->internal_access_);  
    return true;
  }
  else
  {
    pthread_mutex_unlock(&this->internal_access_);  
    return false;
  }
}

bool IriBaseDriver::isStopped(void)
{
  pthread_mutex_lock(&this->internal_access_);  
  if(this->current_state_ == iri_base_driver::OPENED || this->current_state_ == iri_base_driver::CLOSED)
  {
    pthread_mutex_unlock(&this->internal_access_);  
    return true;
  }
  else
  {
    pthread_mutex_unlock(&this->internal_access_);  
    return false;
  }
}

void IriBaseDriver::setPostOpenHook(boost::function< void() > function)
{
  this->postOpenHook = function;
}

void IriBaseDriver::setPreCloseHook(boost::function< void() > function)
{
  this->preCloseHook = function;
}

void IriBaseDriver::setPostStartHook(boost::function< void() > function)
{
  this->postStartHook = function;
}

void IriBaseDriver::setPreStopHook(boost::function< void() > function)
{
  this->preStopHook = function;
}

IriBaseDriver::~IriBaseDriver()
{
  pthread_mutex_destroy(&this->access_);
  pthread_mutex_destroy(&this->internal_access_);
}

}
