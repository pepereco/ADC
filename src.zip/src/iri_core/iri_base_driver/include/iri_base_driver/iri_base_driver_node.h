// Copyright (C) 2010-2011 Institut de Robotica i Informatica Industrial, CSIC-UPC.
// Author Sergi Hernandez & Joan Perez
// All rights reserved.
//
// This file is part of iri-ros-pkg
// iri-ros-pkg is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef _IRI_BASE_DRIVER_NODE_H
#define _IRI_BASE_DRIVER_NODE_H

#include <ros/ros.h>
#include <signal.h>

// boost thread includes for ROS::spin thread
#include <boost/thread.hpp>
#include <boost/bind.hpp>

// dynamic reconfigure server include
#include <dynamic_reconfigure/server.h>
#include <iri_base_driver/SensorLevels.h>

// diagnostic updater include
#include <diagnostic_updater/diagnostic_updater.h>

#include "iri_base_driver/iri_base_driver.h"

namespace iri_base_driver
{
 /**
  * \brief default main thread frequency
  * 
  * This constant determines the default frequency of the mainThread() in HZ.
  * All nodes will loop at this rate if loop_rate_ variable is not modified.
  */
  static const double DEFAULT_RATE = 10.0; //[Hz]

/**
 * \brief IRI ROS Base Node Class
 *
 * This class provides the base class for any ROS driver. The Driver object
 * must be an implementation of the IriBaseDriver class. The inherit template
 * design form allows complete access to the driver object while manteining 
 * flexibility to instantiate any object inherit from IriBaseDriver.
 *
 * A shared library is generated together with IriBaseDriver class to force 
 * implementation of virtual methods to final user. Functions from ROS driver 
 * base class to perform tests, add diagnostics or hooks, are mainteined to 
 * implement common purpose behaviours and forwarded to the final user node 
 * class for specification.
 *
 * Threads are implemented using iri_utils software utilities. The mainThread() 
 * function loops in a defined loop_rate_. In each iteration, the abstract 
 * mainNodeThread() function defined in the inherit node class is called.
 *
 * Similarly, functions such as addDiagnostics() are prepared for detailing
 * common features for all driver nodes while executing specific commands for
 * each specification by calling the respective function addNodeDiagnostics()
 * from the inherit node implementation.
 *
 * Instances of both IriBaseDriver and IriBaseNodeDriver can be easly generated 
 * with the  iri_ros_scripts package. Similarly, data can be sent and read 
 * through ROS topics by using those scripts. The scripts can be downloaded 
 * from the IRI GitLab respository (See http://wiki.iri.upc.edu).
 */
template <class Driver>
class IriBaseNodeDriver
{
  public:
   /**
    * \brief config object
    *
    * All template driver class will need a Config variable to allow ROS
    * dynamic reconfigure. This config class will contain all driver
    * parameters which may be modified once the driver node is launched.
    */
    typedef typename Driver::Config Config;

  private:
   /**
    * \brief ros spin thread
    * 
    * This boost thread object will manage the ros::spin function. It is 
    * instantiated and launched in the spin class method.
    */
    boost::shared_ptr<boost::thread> spin_thread_;

    /**
     * \brief Thread information structure
     *
     * This structure hold system level information of the thread and it is 
     * initialized when the thread is first created. This information can not 
     * be modified at any time and it is not accessible from outside the class.
     *
     */
    pthread_t main_thread;

   /**
    * \brief main thread loop rate
    * 
    * This value determines the loop frequency of the node main thread function
    * mainThread() in Hz. It is initialized at construction time. This variable 
    * may be modified in the node implementation constructor if a desired
    * frequency is required.
    */
    ros::Rate loop_rate_;

   /**
    * \brief 
    * 
    */
    diagnostic_updater::FunctionDiagnosticTask driver_status_standard_diagnostic_;

   /**
    * \brief main node post open hook
    *
    * This function sets the common parameters for all drivers which might be
    * tuned for the ROS dynamic reconfigure application.
    */
    void postOpenHook(void);

   /**
    * \brief main node pre close hook
    *
    */
    void preCloseHook(void);

   /**
    * \brief main node post start hook
    *
    */
    void postStartHook(void);

   /**
    * \brief main node pre stop hook
    *
    */
    void preStopHook(void);

   /**
    * \brief dynamic reconfigure server callback
    * 
    * This method is called whenever a new configuration is received through
    * the dynamic reconfigure. The derivated generic driver class must 
    * implement it.
    *
    * \param config an object with new configuration from all algorithm 
    *               parameters defined in the config file.
    * \param level  integer referring the level in which the configuration
    *               has been changed.
    */
    void reconfigureCallback(Config &config, uint32_t level);

   /**
    * \brief main node add diagnostics
    *
    * In this function ROS diagnostics applied to all node may be added.
    *
    */
    void addDiagnostics(void);

  protected:
   /**
    * \brief template driver class
    *
    * This template class refers to an implementation of an specific driver
    * interface. Will be used in the derivate class to define the common 
    * behaviour for all the different implementations from the same driver.
    */
    Driver driver_;

   /**
    * \brief public node handle communication object
    *
    * This node handle is going to be used to create topics and services within
    * the node namespace. Additional node handles can be instantatied if 
    * additional namespaces are needed.
    */
    ros::NodeHandle public_node_handle_;

   /**
    * \brief private node handle object
    *
    * This private node handle will be used to define algorithm parameters into
    * the ROS parametre server. For communication pruposes please use the 
    * previously defined node_handle_ object.
    */
    ros::NodeHandle private_node_handle_;

   /**
    * \brief dynamic reconfigure server
    * 
    * The dynamic reconfigure server is in charge to retrieve the parameters
    * defined in the config cfg file through the reconfigureCallback.
    */
    dynamic_reconfigure::Server<Config> dsrv_;

   /**
    * \brief diagnostic updater
    * 
    * The diagnostic updater allows definition of custom diagnostics. 
    * 
    */
    diagnostic_updater::Updater diagnostic_;

   /**
    * \brief 
    * 
    */
    void statusDiagnostic(diagnostic_updater::DiagnosticStatusWrapper& stat);

   /**
    * \brief node implementation post open hook
    * 
    * Abstrac function called by postOpenHook() that adds the specific driver
    * node parameters to the dynamic reconfigure application.
    */
    virtual void postNodeOpenHook(void);

   /**
    * \brief node implementation pre close hook
    * 
    */
    virtual void preNodeCloseHook(void);

   /**
    * \brief node implementation post start hook
    * 
    */
    virtual void postNodeStartHook(void);

   /**
    * \brief node implementation pre stop hook
    * 
    */
    virtual void preNodeStopHook(void);

   /**
    * \brief dynamic reconfigure server callback
    * 
    * This method is called whenever a new configuration is received through
    * the dynamic reconfigure. The derivated generic driver class must 
    * implement it.
    *
    * \param config an object with new configuration from all algorithm 
    *               parameters defined in the config file.
    * \param level  integer referring the level in which the configuration
    *               has been changed.
    */
    virtual void node_config_update(Config &config, uint32_t level);

   /**
    * \brief node add diagnostics
    *
    * In this abstract function additional ROS diagnostics applied to the 
    * specific node may be added.
    */
    virtual void addNodeDiagnostics(void) = 0;

   /**
    * \brief main node thread
    *
    * This is the main thread node function. Code written here will be executed
    * in every inherit driver node object. The loop won't exit until driver node
    * finish its execution. The commands implemented in the abstract function
    * mainNodeThread() will be executed in every iteration.
    * 
    * Loop frequency can be tuned my modifying loop_rate_ attribute.
    * 
    * \param param is a pointer to a IriBaseDriver object class. It is used to 
    *              access to the object attributes and methods.
    */
    static void *mainThread(void *param);

   /**
    * \brief specific node thread
    *
    * In this abstract function specific commands for the driver base node
    * have to be detailed.
    */
    virtual void mainNodeThread(void) = 0;

   /**
    * \brief 
    * 
    */
    void setRate(double rate_hz);

   /**
    * \brief 
    * 
    */
    double getRate(void);

    static void hupCalled(int sig);

  public:

   /**
    * \brief constructor
    *
    * This constructor creates and initializes the main thread of the class. It 
    * also sets the driver_base::postOpenHook thread. NodeHandle and loop_rate_
    * variables are also initialized.
    *
    */
    IriBaseNodeDriver(const ros::NodeHandle &nh = ros::NodeHandle("~"));

   /**
    * \brief spin
    * 
    * This method is meant to spin the node to update all ROS features. It also
    * launches de main thread. Once the object is instantiated, it will not 
    * start iterating until this method is called.
    */
    int spin(void);

    int nodelet_spin(void);
   /**
    * \brief destructor
    *
    * This destructor closes the driver object and kills the main thread.
    */
    ~IriBaseNodeDriver();
};

template <class Driver>
IriBaseNodeDriver<Driver>::IriBaseNodeDriver(const ros::NodeHandle &nh) : 
  public_node_handle_(nh),
  loop_rate_(DEFAULT_RATE),
  diagnostic_(),
  dsrv_(private_node_handle_),
  private_node_handle_("~"),
  driver_status_standard_diagnostic_("Driver Status", boost::bind(&IriBaseNodeDriver::statusDiagnostic, this, _1))
{
  ROS_DEBUG("IriBaseNodeDriver::Constructor");
  this->driver_.setPostOpenHook(boost::bind(&IriBaseNodeDriver::postOpenHook, this));
  this->driver_.setPreCloseHook(boost::bind(&IriBaseNodeDriver::preCloseHook, this));
  this->driver_.setPostStartHook(boost::bind(&IriBaseNodeDriver::postStartHook, this));
  this->driver_.setPreStopHook(boost::bind(&IriBaseNodeDriver::preStopHook, this));
  
  // initialize class attributes
  // allow Ctrl+C management
  signal(SIGHUP, &IriBaseNodeDriver<Driver>::hupCalled);

  // set the diagnostic updater period
  this->private_node_handle_.setParam("diagnostic_period",0.1);
}

template <class Driver>
void *IriBaseNodeDriver<Driver>::mainThread(void *param)
{
  ROS_DEBUG("IriBaseNodeDriver::mainThread");

  IriBaseNodeDriver<Driver> *iriNode = (IriBaseNodeDriver<Driver> *)param;

  while(ros::ok())
  {
    if(iriNode->driver_.isRunning())
      iriNode->mainNodeThread();
    iriNode->loop_rate_.sleep();
  }

  pthread_exit(NULL);
}

template <class Driver>
void IriBaseNodeDriver<Driver>::setRate(double rate_hz)
{
  this->loop_rate_=ros::Rate(rate_hz);
}

template <class Driver>
double IriBaseNodeDriver<Driver>::getRate(void)
{
  return 1.0/this->loop_rate_.expectedCycleTime().toSec();
}

template <class Driver>
void IriBaseNodeDriver<Driver>::postOpenHook(void)
{
  ROS_DEBUG("IriBaseNodeDriver::postOpenHook");

  //set hardware id with driver id
  this->diagnostic_.setHardwareID(this->driver_.getID());

  /* call the inherited class post open function */
  this->postNodeOpenHook();
}

template <class Driver>
void IriBaseNodeDriver<Driver>::postNodeOpenHook(void)
{

}

template <class Driver>
void IriBaseNodeDriver<Driver>::preCloseHook(void)
{
  ROS_DEBUG("IriBaseNodeDriver::preCloseHook");
  /* call the inherited class pre close function */
  this->preNodeCloseHook();
}

template <class Driver>
void IriBaseNodeDriver<Driver>::preNodeCloseHook(void)
{

}

template <class Driver>
void IriBaseNodeDriver<Driver>::postStartHook(void)
{
  ROS_DEBUG("IriBaseNodeDriver::postStartHook");
  /* call the inherited class post start function */
  this->postNodeStartHook();
}

template <class Driver>
void IriBaseNodeDriver<Driver>::postNodeStartHook(void)
{

}

template <class Driver>
void IriBaseNodeDriver<Driver>::preStopHook(void)
{
  ROS_DEBUG("IriBaseNodeDriver::preStopHook");
  /* call the inherited class pre stop function */
  this->preNodeStopHook();
}

template <class Driver>
void IriBaseNodeDriver<Driver>::preNodeStopHook(void)
{

}

template <class Driver>
void IriBaseNodeDriver<Driver>::node_config_update(Config &config, uint32_t level)
{

}

template <class Driver>
void IriBaseNodeDriver<Driver>::statusDiagnostic(diagnostic_updater::DiagnosticStatusWrapper& stat)
{
  if (driver_.isRunning())
    stat.summary(0, "OK");
  else
    stat.summary(2, "not running");

  stat.add("Driver state:", this->driver_.getStateName());
  stat.add("Latest status message:", this->driver_.getStatusMessage());
}

template <class Driver>
void IriBaseNodeDriver<Driver>::addDiagnostics(void)
{
  ROS_DEBUG("IriBaseNodeDriver::addDiagnostics");
  this->diagnostic_.add(this->driver_status_standard_diagnostic_);

  /* add the inherited class diagnostics */
  this->addNodeDiagnostics();
}

template <class Driver>
void IriBaseNodeDriver<Driver>::reconfigureCallback(Config &config, uint32_t level)
{
  iri_base_driver::state_t original_state;

  /// @todo Move this into the Driver class?
  ROS_DEBUG("IriBaseNodeDriver::reconfigureCallback");

  original_state=this->driver_.getState();
  /* go to the desired state for the update */
  switch(level)
  {
    case iri_base_driver::SensorLevels::RECONFIGURE_STOP: 
      this->driver_.goState(iri_base_driver::OPENED);
      break;
    case iri_base_driver::SensorLevels::RECONFIGURE_CLOSE:
      this->driver_.goState(iri_base_driver::CLOSED);
      break;
    case iri_base_driver::SensorLevels::RECONFIGURE_RUNNING:
      this->driver_.goState(iri_base_driver::RUNNING);
      break;
  }

  /* update the driver */
  this->driver_.config_update(config, level);
  /* update the node */
  this->node_config_update(config, level);

  /* return to the previous state */
  this->driver_.goState(original_state);
}

template <class Driver>
int IriBaseNodeDriver<Driver>::spin(void)
{
  ROS_DEBUG("IriBaseNodeDriver::spin");

  // initialize diagnostics
  this->addDiagnostics();

  // launch ros spin in different thread
  this->spin_thread_.reset(new boost::thread(boost::bind(&ros::spin)));
  assert(spin_thread_);

  // initial call of the reconfigure callback function
//  this->reconfigureCallback(this->driver_.config_,iri_base_driver::SensorLevels::RECONFIGURE_CLOSE);
  // assign callback to dynamic reconfigure server
  this->dsrv_.setCallback(boost::bind(&IriBaseNodeDriver<Driver>::reconfigureCallback, this, _1, _2));

  // create the status thread
  pthread_create(&this->main_thread,NULL,this->mainThread,this);

  // try to go to the running state
  this->driver_.goState(iri_base_driver::RUNNING);

  while(ros::ok())
  {
    if (!this->driver_.isRunning())
    {
      ros::WallDuration(1).sleep();
      this->driver_.goState(iri_base_driver::CLOSED);
      this->driver_.goState(iri_base_driver::RUNNING);
    }
    // update diagnostics
    this->diagnostic_.update();

    ros::WallDuration(this->diagnostic_.getPeriod()).sleep();
  }

  // try to go to the closed state
  this->driver_.goState(iri_base_driver::CLOSED);

  // stop ros
  ros::shutdown();

  if (this->spin_thread_ && !this->spin_thread_->timed_join((boost::posix_time::milliseconds) 2000))
  {
    ROS_ERROR("ROS thread did not die after two seconds. Pretending that it did. This is probably a bad sign.");
  }

  // kill ros spin thread
  this->spin_thread_.reset();

  return 0;
}

template <class Driver>
int IriBaseNodeDriver<Driver>::nodelet_spin(void)
{
  ROS_DEBUG("IriBaseNodeDriver::spin");

  // initialize diagnostics
  this->addDiagnostics();

  // initial call of the reconfigure callback function
//  this->reconfigureCallback(this->driver_.config_,iri_base_driver::SensorLevels::RECONFIGURE_CLOSE);
  // assign callback to dynamic reconfigure server
  this->dsrv_.setCallback(boost::bind(&IriBaseNodeDriver<Driver>::reconfigureCallback, this, _1, _2));

  // create the status thread
  pthread_create(&this->main_thread,NULL,this->mainThread,this);

  // try to go to the running state
  this->driver_.goState(iri_base_driver::RUNNING);

  while(ros::ok())
  {
    if (!this->driver_.isRunning())
    {
      ros::WallDuration(1).sleep();
      this->driver_.goState(iri_base_driver::CLOSED);
      this->driver_.goState(iri_base_driver::RUNNING);
    }
    // update diagnostics
    this->diagnostic_.update();

    ros::WallDuration(this->diagnostic_.getPeriod()).sleep();
  }

  // try to go to the closed state
  this->driver_.goState(iri_base_driver::CLOSED);

  // stop ros
  ros::shutdown();

  return 0;
}

template <class Driver>
void IriBaseNodeDriver<Driver>::hupCalled(int sig)
{
  ROS_WARN("Unexpected SIGHUP caught. Ignoring it.");
}

template <class Driver>
IriBaseNodeDriver<Driver>::~IriBaseNodeDriver()
{
  ROS_DEBUG("IriBaseNodeDriver::Destrcutor");
  //try access to driver to assert it is
  //unlock before its destruction
  
  this->driver_.goState(iri_base_driver::CLOSED);
  pthread_cancel(this->main_thread);
  pthread_join(this->main_thread,NULL);
}

/**
 * \brief base main
 *
 * This main is common for all the driver nodes. The DriverType class
 * refers to an specific implementation derived from a generic driver.
 * 
 * First, ros::init is called providing the node name. Ctrl+C control is 
 * activated for sercure and safe exit. Finally, a DriverType object is
 * defined and launched to spin for endless loop execution.
 * 
 * \param argc integer with number of input parameters
 * \param argv array with all input strings
 * \param node_name name of the node
 */
template <class DriverType>
int main(int argc, char **argv, std::string node_name)
{
  ROS_DEBUG("IriBaseDriver::%s Launched", node_name.c_str());

  // ROS initialization
  ros::init(argc, argv, node_name);

  // define and launch generic algorithm implementation object
  ros::NodeHandle nh;
  DriverType driver(nh);
  driver.spin();

  return 0;
}

}

#endif
