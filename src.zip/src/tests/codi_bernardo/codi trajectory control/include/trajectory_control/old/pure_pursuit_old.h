#ifndef PURE_PURSUIT
#define PURE_PURSUIT

#include "trajectory_controller.h"

#include <tf/transform_datatypes.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <algorithm>

class PurePursuit : public TrajectoryController
{
  protected:
	//class variables
	float radius;
	float velocity;

	//class publishers
	ros::Publisher pose_pub;
	ros::Publisher trajectory_marker_pub;
	ros::Publisher circle_marker_pub;
	ros::Publisher distance_marker_pub;

	//variable message for publishers
	geometry_msgs::PoseStamped pose_msg;
	visualization_msgs::Marker marker_point_msg;
	visualization_msgs::Marker marker_line_msg;
	visualization_msgs::Marker marker_circle_msg;
	visualization_msgs::Marker marker_distance_msg;

	//variables for visualization
	tf2::Vector3 reference_pt;
	tf2::Vector3 previous_reference_pt;
	tf2::Vector3 in_line_pt;
	tf2::Vector3 closest_pt_in_segment;

  public:
	PurePursuit();
	~PurePursuit();

	//funciones (virtuales en base)
	void getMoreParams();
	void setMoreVariables();
	void setMorePublishers();
	void setMoreSubscriptors();
	void publishMoreMessages();
	void applyAlgorithm();
	void stop();

	//funciones apoyo
	tf2::Vector3 changeToVehicleRF(tf2::Vector3 _point, tf2::Vector3 _vehicle_point, float _rot);
	tf2::Vector3 changeToWorldRF(tf2::Vector3 _point, tf2::Vector3 _vehicle_point, float _rot);
	bool isBetween(tf2::Vector3 _a, tf2::Vector3 _b, tf2::Vector3 _c);
	bool checkIfInLine(tf2::Vector3 _p1, tf2::Vector3 _p2, float _radius, tf2::Vector3 &_test);
	float shortestDistanceToInfiniteLine(tf2::Vector3 _p, tf2::Vector3 _p1, tf2::Vector3 _p2);
	float shortestDistanceToSegment(tf2::Vector3 _p, tf2::Vector3 _p1, tf2::Vector3 _p2);
	void findClosestPointInSegment(tf2::Vector3 _p, tf2::Vector3 _p1, tf2::Vector3 _p2, float &_x, float &_y);
	void visualizeMarkers(tf2::Vector3 _pt1, tf2::Vector3 _pt2, tf2::Vector3 _pt3, std::string _frame, visualization_msgs::Marker &_points, visualization_msgs::Marker &_line);
	void drawCircle(visualization_msgs::Marker &_circle);
	void drawLine(visualization_msgs::Marker &_line, tf2::Vector3 _pt1);

	//main functions
	float computeAlgorithm();
	void generateMessages(float _curvature);
};

#endif

