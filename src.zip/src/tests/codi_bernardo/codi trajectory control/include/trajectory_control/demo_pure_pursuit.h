#ifndef PURE_PURSUIT
#define PURE_PURSUIT

#include "trajectory_controller.h"

#include <tf/transform_datatypes.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <algorithm>
#include <geometry_msgs/Point.h>
#include <sensor_msgs/PointCloud.h>


class PurePursuit : public TrajectoryController
{
  protected:
	//class variables
	float radius;
	float velocity;
	int currentSegment;
	int segmentSearchWindow;
	bool reposition;

	//class publishers
	ros::Publisher pose_pub;
	ros::Publisher trajectory_marker_pub;
	ros::Publisher circle_marker_pub;
	ros::Publisher distance_marker_pub;
	ros::Publisher goal_pt_pub;

	//variable message for publishers
	geometry_msgs::PoseStamped pose_msg;
	visualization_msgs::Marker marker_point_msg;
	visualization_msgs::Marker marker_line_msg;
	visualization_msgs::Marker marker_circle_msg;
	visualization_msgs::Marker marker_distance_msg;
	sensor_msgs::PointCloud goal_pt_msg;

	//variables for visualization
	tf2::Vector3 reference_pt;
	tf2::Vector3 previous_reference_pt;
	tf2::Vector3 in_line_pt;
	tf2::Vector3 closest_pt_in_segment;

  public:
	PurePursuit();
	~PurePursuit();

	//funciones (virtuales en base)
	void getMoreParams();
	void setMoreVariables();
	void setMorePublishers();
	void setMoreSubscriptors();
	void publishMoreMessages();
	void applyAlgorithm();
	void stop();

	//funciones apoyo
	tf2::Vector3 changeToVehicleRF(tf2::Vector3 _point, tf2::Vector3 _vehicle_point, float _rot);
	void visualizeMarkers(tf2::Vector3 _pt1, tf2::Vector3 _pt2, tf2::Vector3 _pt3, std::string _frame, visualization_msgs::Marker &_points, visualization_msgs::Marker &_line);
	void drawCircle(visualization_msgs::Marker &_circle);
	void drawLine(visualization_msgs::Marker &_line, tf2::Vector3 _pt1);


	float findCurvature(geometry_msgs::Point _pt);
	float findClosestSegmentFromVehicle(float _yaw);
	void indexCorrection(int _i, int& _j, int& _k);
	int checkSegmentMovement(int _init, int _end, float _yaw);
	bool findTrajectoryGoalPoint(int _init, int _end, float _yaw, geometry_msgs::Point& _goal_pt);
	float shortestDistanceToSegment(geometry_msgs::Point _p, geometry_msgs::Point _p1, geometry_msgs::Point _p2);
	void findClosestPointInSegment(geometry_msgs::Point _p, geometry_msgs::Point _p1, geometry_msgs::Point _p2, float &_x, float &_y);
	geometry_msgs::Point changeToVehicleRF(geometry_msgs::Point _point, geometry_msgs::Point _vehicle_point, float _rot);
	bool checkIfInLine(geometry_msgs::Point _p1, geometry_msgs::Point _p2, float _radius, geometry_msgs::Point& _pt);
	bool isBetween(geometry_msgs::Point _a, geometry_msgs::Point _b, geometry_msgs::Point _c);






	//main functions
	float computeAlgorithm();
	void generateMessages(float _curvature);
};

#endif

