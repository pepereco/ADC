#ifndef TRAJECTORY_CONTROLLER
#define TRAJECTORY_CONTROLLER

//ros
#include <ros/ros.h>

//publishers
#include <std_msgs/Int16.h>
#include <std_msgs/UInt8.h>
#include <geometry_msgs/PoseStamped.h>
#include <visualization_msgs/Marker.h>

//subscriber
#include <nav_msgs/Odometry.h>
#include <std_msgs/Bool.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PointStamped.h>


class TrajectoryController 
{
  protected:
	//nodehandle
	ros::NodeHandle n;

	//class variables
	bool active;
	std::string odom_id;
	bool has_path;
	bool has_odom;
	bool has_point;

	//message variables for publishers
	std_msgs::Int16 speed_msg;
	std_msgs::UInt8 steering8_msg;
	std_msgs::Int16 steering16_msg;

	//message variables for subscribers
	nav_msgs::Path path;
	nav_msgs::Odometry odom;
	geometry_msgs::PointStamped reference_point;

	//publishers
	ros::Publisher speed_pub;
	ros::Publisher steering8_pub;
	ros::Publisher steering16_pub;

	//subscribers
	ros::Subscriber sub_odom;
	ros::Subscriber sub_active;
	ros::Subscriber sub_path;
	ros::Subscriber sub_point;

	//functions
	void setVariables(ros::NodeHandle _n);
	virtual void setMoreVariables();
	void getParams();
	virtual void getMoreParams();
	void setPublishers();
	virtual void setMorePublishers();
	void setSubscriptors();
	virtual void setMoreSubscriptors();
	void publishMessages();
	virtual void publishMoreMessages();
	virtual void applyAlgorithm() = 0;
	virtual void stop() = 0;

	//callbacks
	void clbk_active(const std_msgs::Bool::ConstPtr& msg);
	void clbk_odom(const nav_msgs::Odometry::ConstPtr& msg);
	void clbk_path(const nav_msgs::Path::ConstPtr& msg);
	void clbk_point(const geometry_msgs::PointStamped::ConstPtr& msg);

  public:
	//constructors
	TrajectoryController();
	~TrajectoryController();

	void initialize(ros::NodeHandle _n);
	virtual void loop();

};

#endif

