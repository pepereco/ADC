#include <ros/ros.h>
#include "pure_pursuit.h"


int main(int argc, char **argv) {

	ros::init(argc, argv, "trajectory_control");
	ros::NodeHandle n;  

	TrajectoryController *c = new PurePursuit();
	c->initialize(n);
	c->loop();

	return 0;
}
