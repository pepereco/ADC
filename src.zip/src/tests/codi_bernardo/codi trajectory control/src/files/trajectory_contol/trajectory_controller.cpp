#include "trajectory_controller.h"

//=================================================================================//
/* CONSTRUCTORS AND INITIALIZATION */

//contructors
TrajectoryController::TrajectoryController()
{
	std::cout << "TrajectoryController created" << std::endl;
}

TrajectoryController::~TrajectoryController() {}

void TrajectoryController::initialize(ros::NodeHandle _n)
{
	//variables
	setVariables(_n);

	//get Params
	getParams();

	//publishers
	setPublishers();

	//subscribers
	setSubscriptors();

	std::cout << "Trajectory Controller initialization complete" << std::endl;
}

//=================================================================================//
/* SETUP OF VARIABLES, PARAMETERS, ROS PUBLISHERS AND ROS SUBSCRIBERS */

//ros functions
void TrajectoryController::setVariables(ros::NodeHandle _n)
{
	//std::cout << "setVariables base" << std::endl;

	//nodehandle
	n = _n;

	//class variables
	active = false;
	has_path = false;
	has_odom = false;

	//set derived variables
	setMoreVariables();
}

void TrajectoryController::setMoreVariables()
{
	//std::cout << "setMoreVariables base" << std::endl;
}

void TrajectoryController::getParams()
{
	//std::cout << "getParams base" << std::endl;

	//base params
	n.getParam("vehicle_id", odom_id);

	//derived params
	getMoreParams();
}

void TrajectoryController::getMoreParams()
{
	//std::cout << "getMoreParams base" << std::endl;
}

void TrajectoryController::setPublishers()
{
	//std::cout << "setPublishers base" << std::endl;

	speed_pub = n.advertise<std_msgs::Int16>("speed", 1);
	steering8_pub = n.advertise<std_msgs::UInt8>("steering8", 1);
	steering16_pub = n.advertise<std_msgs::Int16>("steering16", 1);

	//set derived publishers
	setMorePublishers();
}

void TrajectoryController::setMorePublishers()
{
	//std::cout << "setMorePublishers base" << std::endl;
}

void TrajectoryController::setSubscriptors()
{
	//set derived subscriptors
	setMoreSubscriptors();

	//std::cout << "setSubscriptors base" << std::endl;
	sub_odom = n.subscribe("/odom", 1, &TrajectoryController::clbk_odom, this);
	sub_path = n.subscribe("/path", 1, &TrajectoryController::clbk_path, this);
	sub_point = n.subscribe("/reference_point", 1, &TrajectoryController::clbk_point, this);
	sub_active = n.subscribe("/active", 1, &TrajectoryController::clbk_active, this);
}

void TrajectoryController::setMoreSubscriptors()
{
	//std::cout << "setMoreSubscriptors base" << std::endl;
}

//=================================================================================//
/* CALLBACKS */

//callbacks for the subscribers
void TrajectoryController::clbk_odom(const nav_msgs::Odometry::ConstPtr& msg)
{
	if(active)
	{
		//if((*msg).header.frame_id == odom_id)
		//{
			odom = *msg;
			has_odom = true;
		//}
	}
}

void TrajectoryController::clbk_path(const nav_msgs::Path::ConstPtr& msg)
{
	if(active)
	{
		path = *msg;
		has_path = true;
	}
}

void TrajectoryController::clbk_point(const geometry_msgs::PointStamped::ConstPtr& msg)
{
	if(active)
	{
		reference_point = *msg;
		has_point = true;
	}
}

void TrajectoryController::clbk_active(const std_msgs::Bool::ConstPtr& msg)
{
	if(msg->data == true) { active = true; }
	else { active = false; }
}

//=================================================================================//
/* PUBLISH MESSAGES AND MAIN LOOP */

//publishMessages
void TrajectoryController::publishMessages()
{
	//algorithm
	speed_pub.publish(speed_msg);
	steering8_pub.publish(steering8_msg);
	steering16_pub.publish(steering16_msg);

	//publish derived messages
	publishMoreMessages();
}

void TrajectoryController::publishMoreMessages()
{
}

// main loop
void TrajectoryController::loop()
{
	ros::Rate loop_rate(10);
	while (ros::ok())
	{
		if(active && has_odom && (has_path || has_point))
		{
			getParams(); /* uncomment if you want updated params */
			applyAlgorithm();
			publishMessages();
		}
		if(!active && has_odom && (has_path || has_point))
		{
			stop();
			publishMessages();
		}

		//spin
		ros::spinOnce();
		loop_rate.sleep();
	}
}

